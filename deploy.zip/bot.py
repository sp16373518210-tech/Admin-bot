#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔════════════════════════════════════════════════════════════════════╗
║  🚀  TELEGRAM BOT & WEB HOSTING PANEL (Python 🐍 + Node.js 🟨 + Web 🌐)║
╠════════════════════════════════════════════════════════════════════╣
║  RUN :  pip install -r requirements.txt   →   python bot.py        ║
║  SETUP: edit BOT_TOKEN + ADMIN_IDS below (or use a .env file)      ║
╚════════════════════════════════════════════════════════════════════╝

Features & Upgrades:
  🚀 Deploy Bots    : upload .zip / .py / .js  → auto-install requirements & run
  🌐 Deploy Websites: upload .zip or index.html → live web preview link & share
  🤖 Bot Token Link : auto-detects Bot Token via Telegram getMe → direct @bot link button
  ⌨️ Persistent Keys: bottom keyboard (ReplyKeyboardMarkup) + inline action buttons
  🎲 Auto Coupons   : 1-click auto-generated coupon codes for instant creation
  🗂 Full Management: ▶️ Start / ⏹ Stop · 🔄 Restart · 📄 Logs · 🗑 Delete
  🔧 Auto-Fix Crash : auto-installs missing Python/Node packages on error
"""
from __future__ import annotations

import ast
import asyncio
import csv
import html
import io
import json
import logging
import os
import re
import secrets
import shutil
import signal
import sqlite3
import string
import subprocess
import sys
import threading
import time
import zipfile
from datetime import datetime
from pathlib import Path
from urllib.parse import quote
import urllib.request

from telegram import (
    BotCommand,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
    Update,
)
from telegram.constants import ParseMode
from telegram.error import BadRequest, RetryAfter, TelegramError
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    Defaults,
    MessageHandler,
    filters,
)

# ══════════════════════════════════════════════════════════════════════
# ⚙️  CONFIG
# ══════════════════════════════════════════════════════════════════════
BASE_DIR = Path(__file__).resolve().parent


def _load_dotenv(path: Path) -> None:
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
    except FileNotFoundError:
        pass


_load_dotenv(BASE_DIR / ".env")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8604012968:AAHmJuX581_U-0wWazD2hKCPFiLC1ayN7sg")
ADMIN_IDS = {int(x) for x in re.findall(r"\d+", os.getenv("ADMIN_IDS", "5960319648"))}
FORCE_CHANNEL = os.getenv("FORCE_CHANNEL", "-1003982704519").strip()
FORCE_CHANNEL_LINK = os.getenv("FORCE_CHANNEL_LINK", "https://t.me/modapkpro02").strip()
REFERRAL_REWARD = int(os.getenv("REFERRAL_REWARD", "1"))
FREE_TOKENS = int(os.getenv("FREE_TOKENS", "1"))  # 1 free trial slot
DEPLOY_COST = 1
REFUND_ON_DELETE = True
MAX_UPLOAD_MB = 25
MAX_UNZIPPED_MB = 350
MAX_AUTO_RESTARTS = 4
DATA_DIR = Path(os.getenv("DATA_DIR", str(BASE_DIR / "hosting_data")))
WEB_APP_URL = os.getenv("APP_URL", "http://localhost:3000").rstrip("/")

logging.basicConfig(format="%(asctime)s | %(levelname)s | %(message)s", level=logging.INFO)
logging.getLogger("httpx").setLevel(logging.WARNING)
LOG = logging.getLogger("panel")

DB: sqlite3.Connection = None  # type: ignore
DB_LOCK = threading.RLock()
PROCS: dict = {}
AUTOFIX_DONE: dict = {}
CRASHES: dict = {}
HANDLING: set = set()
BG_TASKS: set = set()
FORCE_WARNED = False
STARTED_AT = time.time()

SKIP_DIRS = {".venv", "venv", "node_modules", "__pycache__", ".git", "site-packages", "__MACOSX"}
SAFE_ENV_KEYS = (
    "PATH", "HOME", "LANG", "LC_ALL", "LC_CTYPE", "TZ", "TMPDIR", "TEMP", "TMP", "SYSTEMROOT",
    "COMSPEC", "PATHEXT", "USERPROFILE", "APPDATA", "LOCALAPPDATA", "SSL_CERT_FILE", "REQUESTS_CA_BUNDLE",
)
PY_ENTRIES = ["main.py", "bot.py", "app.py", "run.py", "start.py", "index.py", "server.py", "__main__.py"]
JS_ENTRIES = ["index.js", "bot.js", "main.js", "app.js", "server.js", "start.js", "index.mjs", "main.mjs"]
JS_EXTS = (".js", ".mjs", ".cjs")
PIP_MAP = {
    "telegram": "python-telegram-bot", "telebot": "pyTelegramBotAPI", "cv2": "opencv-python",
    "PIL": "Pillow", "yaml": "PyYAML", "bs4": "beautifulsoup4", "dotenv": "python-dotenv",
    "Crypto": "pycryptodome", "sklearn": "scikit-learn", "dateutil": "python-dateutil",
    "jwt": "PyJWT", "serial": "pyserial", "magic": "python-magic", "docx": "python-docx",
    "pptx": "python-pptx", "fitz": "PyMuPDF", "skimage": "scikit-image", "attr": "attrs",
    "OpenSSL": "pyOpenSSL", "psycopg2": "psycopg2-binary", "MySQLdb": "mysqlclient",
    "git": "GitPython", "usb": "pyusb", "zmq": "pyzmq", "socks": "PySocks", "nacl": "PyNaCl",
    "jose": "python-jose", "slugify": "python-slugify", "discord": "discord.py",
    "flask_cors": "flask-cors", "flask_sqlalchemy": "Flask-SQLAlchemy", "tgcrypto": "TgCrypto",
    "speech_recognition": "SpeechRecognition", "yt_dlp": "yt-dlp", "youtube_dl": "youtube-dl",
    "pyrogram": "pyrogram", "telethon": "telethon", "aiogram": "aiogram", "motor": "motor",
    "aiohttp": "aiohttp", "requests": "requests", "fastapi": "fastapi", "uvicorn": "uvicorn",
}
CHECK_SRC = (
    "import importlib.util, json, sys\n"
    "out = []\n"
    "for n in json.loads(sys.argv[1]):\n"
    "    try:\n"
    "        if importlib.util.find_spec(n) is None:\n"
    "            out.append(n)\n"
    "    except Exception:\n"
    "        out.append(n)\n"
    "print(json.dumps(out))\n"
)
JS_IMPORT = re.compile(r"""(?:require\(\s*|from\s+|import\s+|import\(\s*)['"]([^'"\n]+)['"]""")


# ══════════════════════════════════════════════════════════════════════
# 🗄  DATABASE
# ══════════════════════════════════════════════════════════════════════
def db_init() -> None:
    global DB
    for p in (DATA_DIR, DATA_DIR / "bots", DATA_DIR / "websites", DATA_DIR / "logs", DATA_DIR / "tmp"):
        p.mkdir(parents=True, exist_ok=True)
    DB = sqlite3.connect(str(DATA_DIR / "panel.db"), check_same_thread=False)
    DB.row_factory = sqlite3.Row
    DB.execute("PRAGMA journal_mode=WAL")
    DB.executescript(
        """
        CREATE TABLE IF NOT EXISTS users(
            user_id INTEGER PRIMARY KEY, email TEXT DEFAULT '', username TEXT DEFAULT '', first_name TEXT DEFAULT '',
            password_hash TEXT DEFAULT '', tokens INTEGER DEFAULT 1, referred_by INTEGER, ref_rewarded INTEGER DEFAULT 0,
            ref_earned INTEGER DEFAULT 0, verified INTEGER DEFAULT 0, banned INTEGER DEFAULT 0,
            joined_at INTEGER);
        CREATE TABLE IF NOT EXISTS bots(
            id INTEGER PRIMARY KEY AUTOINCREMENT, owner_id INTEGER, name TEXT, lang TEXT,
            entry TEXT DEFAULT '', path TEXT DEFAULT '', bot_token TEXT DEFAULT '',
            bot_username TEXT DEFAULT '', bot_title TEXT DEFAULT '',
            ready INTEGER DEFAULT 0, desired INTEGER DEFAULT 0, pid INTEGER DEFAULT 0,
            started_at INTEGER DEFAULT 0, created_at INTEGER);
        CREATE TABLE IF NOT EXISTS websites(
            id INTEGER PRIMARY KEY AUTOINCREMENT, owner_id INTEGER, name TEXT, slug TEXT UNIQUE,
            path TEXT DEFAULT '', entry TEXT DEFAULT 'index.html', created_at INTEGER);
        CREATE TABLE IF NOT EXISTS coupons(
            code TEXT PRIMARY KEY, tokens INTEGER, max_uses INTEGER, used INTEGER DEFAULT 0,
            created_at INTEGER);
        CREATE TABLE IF NOT EXISTS coupon_uses(
            code TEXT, user_id INTEGER, ts INTEGER, PRIMARY KEY(code, user_id));
        CREATE TABLE IF NOT EXISTS password_resets(
            email TEXT, user_id INTEGER, code TEXT, expires_at INTEGER, PRIMARY KEY(email, code));
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
        """
    )
    # Check and migrate columns if older db exists
    cols = {r["name"] for r in DB.execute("PRAGMA table_info(bots)").fetchall()}
    if "bot_token" not in cols:
        DB.execute("ALTER TABLE bots ADD COLUMN bot_token TEXT DEFAULT ''")
    if "bot_username" not in cols:
        DB.execute("ALTER TABLE bots ADD COLUMN bot_username TEXT DEFAULT ''")
    if "bot_title" not in cols:
        DB.execute("ALTER TABLE bots ADD COLUMN bot_title TEXT DEFAULT ''")
    u_cols = {r["name"] for r in DB.execute("PRAGMA table_info(users)").fetchall()}
    if "email" not in u_cols:
        DB.execute("ALTER TABLE users ADD COLUMN email TEXT DEFAULT ''")
    if "password_hash" not in u_cols:
        DB.execute("ALTER TABLE users ADD COLUMN password_hash TEXT DEFAULT ''")
    DB.commit()


def dbx(sql: str, args: tuple = ()):
    with DB_LOCK:
        cur = DB.execute(sql, args)
        DB.commit()
        return cur


def dbone(sql: str, args: tuple = ()):
    with DB_LOCK:
        return DB.execute(sql, args).fetchone()


def dball(sql: str, args: tuple = ()):
    with DB_LOCK:
        return DB.execute(sql, args).fetchall()


def get_setting(key: str, default=None):
    r = dbone("SELECT value FROM settings WHERE key=?", (key,))
    return r["value"] if r else default


def set_setting(key: str, value) -> None:
    dbx("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))


def get_ref_reward() -> int:
    try:
        return int(get_setting("ref_reward", REFERRAL_REWARD))
    except Exception:
        return REFERRAL_REWARD


def get_force():
    ch = get_setting("force_channel")
    if ch is None:
        ch = FORCE_CHANNEL
    link = get_setting("force_link")
    if link is None:
        link = FORCE_CHANNEL_LINK
    if ch and not link and str(ch).startswith("@"):
        link = "https://t.me/" + str(ch)[1:]
    return str(ch or ""), str(link or "")


# ── users ──
def get_user(uid: int):
    return dbone("SELECT * FROM users WHERE user_id=?", (uid,))


def register_user(tg_user, ref: int | None = None):
    row = get_user(tg_user.id)
    uname = tg_user.username or ""
    name = tg_user.full_name or ""
    if row is None:
        valid_ref = ref if (ref and ref != tg_user.id and get_user(ref)) else None
        dbx(
            "INSERT INTO users(user_id,username,first_name,tokens,referred_by,joined_at) VALUES(?,?,?,?,?,?)",
            (tg_user.id, uname, name, FREE_TOKENS, valid_ref, int(time.time())),
        )
    else:
        dbx("UPDATE users SET username=?, first_name=? WHERE user_id=?", (uname, name, tg_user.id))
    return get_user(tg_user.id)


def add_tokens(uid: int, n: int) -> None:
    dbx("UPDATE users SET tokens = MAX(0, tokens + ?) WHERE user_id=?", (n, uid))


def get_bot(bid: int):
    return dbone("SELECT * FROM bots WHERE id=?", (bid,))


def user_bots(uid: int):
    return dball("SELECT * FROM bots WHERE owner_id=? AND ready=1 ORDER BY id DESC", (uid,))


def user_websites(uid: int):
    return dball("SELECT * FROM websites WHERE owner_id=? ORDER BY id DESC", (uid,))


# ── coupons ──
def generate_coupon_code(prefix: str = "HOST") -> str:
    rnd = "".join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(6))
    return f"{prefix}-{rnd}"


def redeem_coupon(uid: int, code: str) -> str:
    code = code.strip().upper()
    c = dbone("SELECT * FROM coupons WHERE code=?", (code,))
    if not c:
        return "❌ <b>Invalid coupon code.</b>"
    if c["used"] >= c["max_uses"]:
        return "⌛ <b>This coupon has expired</b> (all uses are redeemed)."
    if dbone("SELECT 1 FROM coupon_uses WHERE code=? AND user_id=?", (code, uid)):
        return "⚠️ <b>You have already redeemed this coupon code.</b>"
    with DB_LOCK, DB:
        DB.execute("INSERT INTO coupon_uses(code,user_id,ts) VALUES(?,?,?)", (code, uid, int(time.time())))
        DB.execute("UPDATE coupons SET used = used + 1 WHERE code=?", (code,))
        DB.execute("UPDATE users SET tokens = tokens + ? WHERE user_id=?", (c["tokens"], uid))
    bal = get_user(uid)["tokens"]
    return f"🎉 <b>Coupon redeemed successfully!</b>\n\n🪙 Added <b>{c['tokens']}</b> token(s)!\n💰 Current Balance: <b>{bal}</b>"


# ══════════════════════════════════════════════════════════════════════
# 🔍 BOT TOKEN INSPECTOR (Telegram getMe)
# ══════════════════════════════════════════════════════════════════════
def inspect_bot_token(token: str) -> tuple[bool, str, str]:
    """Inspects bot token via Telegram Bot API getMe.
    Returns (ok, bot_name, bot_username)."""
    token = token.strip()
    if not token or ":" not in token:
        return False, "", ""
    url = f"https://api.telegram.org/bot{token}/getMe"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "TeleHost/1.0"})
        with urllib.request.urlopen(req, timeout=8) as res:
            data = json.loads(res.read().decode("utf-8"))
            if data.get("ok"):
                r = data.get("result", {})
                return True, r.get("first_name", "Telegram Bot"), r.get("username", "")
    except Exception as e:
        LOG.warning("Failed to inspect token: %s", e)
    return False, "", ""


def detect_token_in_dir(d: Path) -> str:
    """Scans code files and .env for bot token format: \d{8,11}:[A-Za-z0-9_-]{35}"""
    token_pattern = re.compile(r"\b(\d{8,11}:[A-Za-z0-9_-]{34,38})\b")
    for f in walk_files(d, (".py", ".js", ".env", ".json", ".txt")):
        try:
            txt = f.read_text(encoding="utf-8", errors="ignore")
            m = token_pattern.search(txt)
            if m:
                return m.group(1)
        except Exception:
            continue
    return ""


# ══════════════════════════════════════════════════════════════════════
# 🔧 SMALL HELPERS
# ══════════════════════════════════════════════════════════════════════
def esc(s) -> str:
    return html.escape(str(s), quote=False)


def is_admin(uid: int) -> bool:
    return uid in ADMIN_IDS


def fmt_dur(sec: float) -> str:
    sec = int(max(0, sec))
    d, r = divmod(sec, 86400)
    h, r = divmod(r, 3600)
    m, s = divmod(r, 60)
    parts = []
    if d:
        parts.append(f"{d}d")
    if h:
        parts.append(f"{h}h")
    if m:
        parts.append(f"{m}m")
    if not parts:
        parts.append(f"{s}s")
    return " ".join(parts)


def lang_icon(lang: str) -> str:
    if lang == "python":
        return "🐍"
    if lang == "node":
        return "🟨"
    return "🌐"


def lang_name(lang: str) -> str:
    if lang == "python":
        return "Python"
    if lang == "node":
        return "Node.js"
    return "Website"


def parse_int(s: str, lo: int, hi: int):
    try:
        n = int(str(s).strip())
        return n if lo <= n <= hi else None
    except Exception:
        return None


def fit_html_tail(text: str, limit: int = 800) -> str:
    t = text[-limit:]
    while len(esc(t)) > limit and t:
        t = t[max(1, len(t) // 10):]
    return esc(t)


def safe_filename(name: str, ext: str) -> str:
    s = re.sub(r"[^\w.\-]", "_", name).lstrip(".")
    if not s.lower().endswith(ext):
        s = (s or "main") + ext
    return s


def B(text: str, cb: str | None = None, url: str | None = None) -> InlineKeyboardButton:
    return InlineKeyboardButton(text, callback_data=cb, url=url)


def KB(rows) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(rows)


def log_path(bid: int) -> Path:
    return DATA_DIR / "logs" / f"bot_{bid}.log"


def append_log(bid: int, text: str) -> None:
    try:
        with open(log_path(bid), "ab") as f:
            f.write(text.encode("utf-8", "replace"))
    except Exception:
        pass


def read_tail(path: Path, n: int = 4000) -> str:
    try:
        with open(path, "rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            f.seek(max(0, size - n))
            return f.read().decode("utf-8", "replace")
    except Exception:
        return ""


def trim_log(p: Path, limit: int = 5 * 1024 * 1024, keep: int = 1024 * 1024) -> None:
    try:
        if p.exists() and p.stat().st_size > limit:
            tail = p.read_bytes()[-keep:]
            with open(p, "r+b") as f:
                f.seek(0)
                f.write(b"[panel] ...old log trimmed...\n" + tail)
                f.truncate()
    except Exception:
        pass


def walk_files(root: Path, exts: tuple):
    for dp, dns, fns in os.walk(root):
        dns[:] = [x for x in dns if x not in SKIP_DIRS]
        for fn in fns:
            if fn.lower().endswith(exts):
                yield Path(dp) / fn


def run_cmd(cmd, cwd, timeout: int = 900, env=None):
    try:
        p = subprocess.run(
            [str(c) for c in cmd], cwd=str(cwd), env=env, capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=timeout, stdin=subprocess.DEVNULL,
        )
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except subprocess.TimeoutExpired:
        return 124, "⏱ command timed out"
    except FileNotFoundError as e:
        return 127, str(e)
    except Exception as e:
        return 1, str(e)


# ══════════════════════════════════════════════════════════════════════
# ⌨️  BOTTOM PERSISTENT KEYBOARD (ReplyKeyboardMarkup)
# ══════════════════════════════════════════════════════════════════════
def get_reply_keyboard(uid: int) -> ReplyKeyboardMarkup:
    buttons = [
        [KeyboardButton("🚀 Deploy Bot"), KeyboardButton("🌐 Deploy Website")],
        [KeyboardButton("🗂 Manage Bots"), KeyboardButton("🌐 My Websites")],
        [KeyboardButton("🎟 Redeem Coupon"), KeyboardButton("🎁 Referral")],
        [KeyboardButton("🌐 Web Dashboard"), KeyboardButton("ℹ️ Help & Support")],
    ]
    if is_admin(uid):
        buttons.append([KeyboardButton("👑 Admin Panel")])
    return ReplyKeyboardMarkup(buttons, resize_keyboard=True)


# ══════════════════════════════════════════════════════════════════════
# 📦 PROJECT FILES & EXTRACTION
# ══════════════════════════════════════════════════════════════════════
def safe_extract(zp: Path, dest: Path) -> None:
    dest = dest.resolve()
    total = 0
    with zipfile.ZipFile(zp) as z:
        infos = z.infolist()
        if len(infos) > 20000:
            raise ValueError("Too many files inside the zip")
        for m in infos:
            total += m.file_size
        if total > MAX_UNZIPPED_MB * 1024 * 1024:
            raise ValueError(f"Zip is bigger than {MAX_UNZIPPED_MB} MB after extraction")
        for m in infos:
            name = m.filename.replace("\\", "/")
            if name.startswith("__MACOSX/") or name.endswith(".DS_Store"):
                continue
            target = (dest / name).resolve()
            if target != dest and dest not in target.parents:
                continue
            if m.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with z.open(m) as src, open(target, "wb") as out:
                shutil.copyfileobj(src, out)


def flatten_single_dir(d: Path) -> None:
    for _ in range(5):
        items = [p for p in d.iterdir() if p.name != "__MACOSX"]
        if len(items) == 1 and items[0].is_dir():
            sub = items[0]
            tmp = d / f".__flat_{secrets.token_hex(3)}"
            sub.rename(tmp)
            for c in list(tmp.iterdir()):
                shutil.move(str(c), str(d / c.name))
            tmp.rmdir()
        else:
            break


def detect_lang(d: Path):
    has_pkg = (d / "package.json").exists()
    has_req = (d / "requirements.txt").exists()
    if has_pkg and not has_req:
        return "node"
    if has_req and not has_pkg:
        return "python"
    pyc = sum(1 for _ in walk_files(d, (".py",)))
    jsc = sum(1 for _ in walk_files(d, JS_EXTS))
    if pyc == 0 and jsc == 0:
        return None
    return "python" if pyc >= jsc else "node"


def detect_entry(d: Path, lang: str):
    exts = (".py",) if lang == "python" else JS_EXTS
    if lang == "node":
        pj = d / "package.json"
        if pj.exists():
            try:
                j = json.loads(pj.read_text(encoding="utf-8-sig", errors="ignore"))
                m = j.get("main")
                if isinstance(m, str) and (d / m).is_file():
                    return m.replace("\\", "/")
                st = (j.get("scripts") or {}).get("start", "")
                mm = re.search(r"node\s+(?:--?\S+\s+)*([^\s&|;]+\.(?:js|mjs|cjs))", st)
                if mm and (d / mm.group(1)).is_file():
                    return mm.group(1)
            except Exception:
                pass
    for c in (PY_ENTRIES if lang == "python" else JS_ENTRIES):
        if (d / c).is_file():
            return c
    root_files = [f.name for f in d.iterdir() if f.is_file() and f.name.lower().endswith(exts)]
    if len(root_files) == 1:
        return root_files[0]
    allf = list(walk_files(d, exts))
    if len(allf) == 1:
        return str(allf[0].relative_to(d)).replace(os.sep, "/")
    return None


def list_code_files(d: Path, lang: str, limit: int = 25):
    exts = (".py",) if lang == "python" else JS_EXTS
    out = [str(f.relative_to(d)).replace(os.sep, "/") for f in walk_files(d, exts)]
    return sorted(out)[:limit]


def extract_project(src: Path, filename: str, lang: str, d: Path):
    try:
        d.mkdir(parents=True, exist_ok=True)
        if filename.lower().endswith(".zip"):
            safe_extract(src, d)
            flatten_single_dir(d)
        else:
            shutil.copy2(src, d / filename)
    except zipfile.BadZipFile:
        return False, "The zip file is corrupted or not a valid zip."
    except Exception as e:
        return False, f"Could not extract: {e}"
    found = detect_lang(d)
    if found is None:
        return False, "No .py or .js code files were found in your upload."
    if found != lang:
        return False, (
            f"You selected <b>{lang_name(lang)}</b> but this project looks like "
            f"<b>{lang_name(found)}</b>. Go back and choose the right language."
        )
    return True, ""


# ══════════════════════════════════════════════════════════════════════
# 📥 DEPENDENCY INSTALLER & ENV
# ══════════════════════════════════════════════════════════════════════
def venv_dir(d: Path) -> Path:
    return d / ".venv"


def venv_bin(d: Path) -> Path:
    return venv_dir(d) / ("Scripts" if os.name == "nt" else "bin")


def venv_python(d: Path) -> Path:
    return venv_bin(d) / ("python.exe" if os.name == "nt" else "python")


def get_py(d: Path) -> str:
    vp = venv_python(d)
    return str(vp) if vp.exists() else sys.executable


def child_env(d: Path, lang: str, run: bool = False) -> dict:
    env = {k: os.environ[k] for k in SAFE_ENV_KEYS if k in os.environ}
    env.setdefault("PATH", os.defpath)
    env["PYTHONUNBUFFERED"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    env["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"
    env["NPM_CONFIG_UPDATE_NOTIFIER"] = "false"
    if venv_python(d).exists():
        env["PATH"] = str(venv_bin(d)) + os.pathsep + env["PATH"]
        env["VIRTUAL_ENV"] = str(venv_dir(d))
    nb = d / "node_modules" / ".bin"
    if nb.exists():
        env["PATH"] = str(nb) + os.pathsep + env["PATH"]
    if run:
        env["HOME"] = str(d)
    return env


def valid_pip_name(n: str) -> bool:
    return bool(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._\-]*", n or ""))


def valid_npm_name(n: str) -> bool:
    return bool(re.fullmatch(r"(@[a-z0-9~][a-z0-9\-._~]*/)?[a-z0-9~][a-z0-9\-._~]*", n or ""))


def pip_install(py: str, d: Path, args: list):
    base = [py, "-m", "pip", "install", "--disable-pip-version-check", "--no-input"]
    env = child_env(d, "python")
    rc, out = run_cmd(base + args, d, 1500, env)
    if rc != 0 and "externally-managed-environment" in out:
        rc, out = run_cmd(base + ["--break-system-packages"] + args, d, 1500, env)
    return rc, out


def local_py_names(d: Path) -> set:
    names = set()
    for dp, dns, fns in os.walk(d):
        dns[:] = [x for x in dns if x not in SKIP_DIRS]
        names.update(dns)
        names.update(Path(f).stem for f in fns if f.endswith(".py"))
    return names


def scan_py_imports(d: Path) -> set:
    mods = set()
    for i, f in enumerate(walk_files(d, (".py",))):
        if i > 400:
            break
        try:
            tree = ast.parse(f.read_text(encoding="utf-8", errors="ignore"))
        except Exception:
            continue
        for n in ast.walk(tree):
            if isinstance(n, ast.Import):
                for a in n.names:
                    mods.add(a.name.split(".")[0])
            elif isinstance(n, ast.ImportFrom) and n.level == 0 and n.module:
                mods.add(n.module.split(".")[0])
    return {m for m in mods if m and m.isidentifier()} - local_py_names(d)


def prepare_python(d: Path, bid: int):
    notes = []
    vp = venv_python(d)
    if not vp.exists():
        run_cmd([sys.executable, "-m", "venv", str(venv_dir(d))], d, 300)
        if not vp.exists():
            shutil.rmtree(venv_dir(d), ignore_errors=True)
            notes.append("venv not available → using system Python")
    py = get_py(d)
    rc, _ = run_cmd([py, "-m", "pip", "--version"], d, 60)
    if rc != 0:
        run_cmd([py, "-m", "ensurepip", "--upgrade"], d, 180)
        rc, _ = run_cmd([py, "-m", "pip", "--version"], d, 60)
        if rc != 0 and py != sys.executable:
            shutil.rmtree(venv_dir(d), ignore_errors=True)
            py = sys.executable
            rc, _ = run_cmd([py, "-m", "pip", "--version"], d, 60)
        if rc != 0:
            return False, "pip is not installed on the server (run: apt install python3-pip python3-venv)"

    req = d / "requirements.txt"
    if req.exists():
        rc, out = pip_install(py, d, ["-r", "requirements.txt"])
        append_log(bid, "\n[panel] pip install -r requirements.txt\n" + out[-3000:] + "\n")
        if rc != 0:
            notes.append("some requirements retried individually")
            for line in req.read_text(encoding="utf-8", errors="ignore").splitlines():
                line = line.strip()
                if not line or line.startswith("#") or line.startswith("-"):
                    continue
                r1, o1 = pip_install(py, d, [line])
                if r1 != 0:
                    name = re.split(r"[=<>!~;@ ]", line, 1)[0]
                    if valid_pip_name(name.split("[")[0]):
                        pip_install(py, d, [name])

    mods = sorted(scan_py_imports(d))
    if mods:
        rc, out = run_cmd([py, "-c", CHECK_SRC, json.dumps(mods)], d, 120, child_env(d, "python"))
        try:
            missing = json.loads(out.strip().splitlines()[-1])
        except Exception:
            missing = []
        pkgs = [PIP_MAP.get(m, m) for m in missing if valid_pip_name(PIP_MAP.get(m, m))]
        if pkgs:
            rc, out = pip_install(py, d, pkgs)
            append_log(bid, "\n[panel] auto-installing detected imports: " + " ".join(pkgs) + "\n" + out[-2000:] + "\n")
            if rc != 0:
                for p in pkgs:
                    pip_install(py, d, [p])
    return True, "; ".join(notes)


def node_builtins(node: str) -> set:
    rc, out = run_cmd([node, "-p", "require('module').builtinModules.join(',')"], BASE_DIR, 30)
    if rc == 0 and out.strip():
        return set(out.strip().split(","))
    return {"fs", "path", "os", "http", "https", "crypto", "events", "util", "stream", "url", "child_process",
            "zlib", "net", "dns", "readline", "buffer", "assert", "querystring", "timers", "tls", "vm"}


def npm_pkg_name(spec: str):
    if spec.startswith((".", "/", "node:", "file:", "http", "data:")):
        return None
    parts = spec.split("/")
    name = "/".join(parts[:2]) if spec.startswith("@") else parts[0]
    return name if valid_npm_name(name) else None


def scan_js_imports(d: Path) -> tuple:
    names, esm, cjs = set(), False, False
    for i, f in enumerate(walk_files(d, JS_EXTS)):
        if i > 400:
            break
        try:
            txt = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        if re.search(r"^\s*import\s[^\n]*['\"]", txt, re.M) or re.search(r"^\s*export\s", txt, re.M):
            esm = True
        if "require(" in txt:
            cjs = True
        for m in JS_IMPORT.finditer(txt):
            n = npm_pkg_name(m.group(1))
            if n:
                names.add(n)
    return names, (esm and not cjs)


def prepare_node(d: Path, bid: int):
    node, npm = shutil.which("node"), shutil.which("npm")
    if not node or not npm:
        return False, "Node.js / npm is not installed on the server (run: apt install nodejs npm)"
    env = child_env(d, "node")
    pj = d / "package.json"
    names, esm = scan_js_imports(d)
    if pj.exists():
        try:
            json.loads(pj.read_text(encoding="utf-8-sig"))
        except Exception:
            pj.rename(d / "package.json.broken")
    if not pj.exists():
        pkg = {"name": "hosted-bot", "version": "1.0.0", "private": True}
        if esm:
            pkg["type"] = "module"
        pj.write_text(json.dumps(pkg, indent=2), encoding="utf-8")
    base = [npm, "install", "--no-audit", "--no-fund", "--loglevel=error"]
    rc, out = run_cmd(base, d, 1500, env)
    if rc != 0:
        rc, out = run_cmd(base + ["--legacy-peer-deps"], d, 1500, env)
    if rc != 0:
        rc, out = run_cmd(base + ["--force"], d, 1500, env)
    append_log(bid, "\n[panel] npm install\n" + out[-3000:] + "\n")
    builtins = {b.replace("node:", "") for b in node_builtins(node)}
    need = sorted(n for n in names if n not in builtins and not (d / "node_modules" / n).exists())
    if need:
        rc, out = run_cmd(base + need, d, 1500, env)
        append_log(bid, "\n[panel] auto-installing detected modules: " + " ".join(need) + "\n" + out[-2000:] + "\n")
        if rc != 0:
            for n in need:
                run_cmd(base + [n], d, 900, env)
    return True, ""


def prepare_env(d: Path, lang: str, bid: int):
    return prepare_python(d, bid) if lang == "python" else prepare_node(d, bid)


def install_single(row, pkg: str):
    d = Path(row["path"])
    if row["lang"] == "python":
        if pkg in local_py_names(d):
            return False
        name = PIP_MAP.get(pkg, pkg)
        if not valid_pip_name(name):
            return False
        rc, out = pip_install(get_py(d), d, [name])
    else:
        if not valid_npm_name(pkg) or not shutil.which("npm"):
            return False
        rc, out = run_cmd([shutil.which("npm"), "install", "--no-audit", "--no-fund", "--loglevel=error", pkg],
                          d, 900, child_env(d, "node"))
    append_log(row["id"], out[-1500:] + "\n")
    return rc == 0


def find_missing(text: str, lang: str):
    if lang == "python":
        m = re.findall(r"ModuleNotFoundError: No module named ['\"]([\w.\-]+)['\"]", text)
        if m:
            return m[-1].split(".")[0]
    else:
        for name in reversed(re.findall(r"Cannot find (?:module|package) ['\"]([^'\"]+)['\"]", text)):
            n = npm_pkg_name(name)
            if n:
                return n
    return None


# ══════════════════════════════════════════════════════════════════════
# ⚙️  PROCESS MANAGER
# ══════════════════════════════════════════════════════════════════════
def is_running(bid: int) -> bool:
    p = PROCS.get(bid)
    return p is not None and p.poll() is None


def start_process(row):
    bid = row["id"]
    if is_running(bid):
        return True, "Already running"
    d = Path(row["path"])
    if not d.is_dir():
        return False, "Project folder is missing"
    entry = row["entry"]
    if not entry or not (d / entry).is_file():
        return False, "Entry file not found"
    if row["lang"] == "python":
        cmd = [get_py(d), "-u", entry]
    else:
        node = shutil.which("node")
        if not node:
            return False, "Node.js is not installed on the server"
        cmd = [node, entry]
    lp = log_path(bid)
    lp.parent.mkdir(parents=True, exist_ok=True)
    trim_log(lp)
    kw = {"start_new_session": True} if os.name != "nt" else {"creationflags": getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)}
    try:
        with open(lp, "ab") as lf:
            lf.write(f"\n=== PANEL START {datetime.now():%Y-%m-%d %H:%M:%S} | {row['lang']} {entry} ===\n".encode())
            lf.flush()
            proc = subprocess.Popen(
                cmd, cwd=str(d), stdout=lf, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                env=child_env(d, row["lang"], run=True), **kw,
            )
    except Exception as e:
        return False, f"Could not start: {e}"
    PROCS[bid] = proc
    dbx("UPDATE bots SET desired=1, pid=?, started_at=? WHERE id=?", (proc.pid, int(time.time()), bid))
    return True, "Started"


def kill_proc(proc) -> None:
    if proc.poll() is not None:
        return
    try:
        if os.name == "nt":
            proc.terminate()
        else:
            os.killpg(proc.pid, signal.SIGTERM)
    except Exception:
        pass
    try:
        proc.wait(timeout=6)
    except Exception:
        try:
            if os.name == "nt":
                proc.kill()
            else:
                os.killpg(proc.pid, signal.SIGKILL)
        except Exception:
            pass
        try:
            proc.wait(timeout=3)
        except Exception:
            pass


def stop_process(bid: int, keep_desired: bool = False) -> None:
    proc = PROCS.pop(bid, None)
    if not keep_desired:
        dbx("UPDATE bots SET desired=0, pid=0 WHERE id=?", (bid,))
    if proc is not None:
        kill_proc(proc)


def kill_stale(row) -> None:
    pid = row["pid"] or 0
    if not pid or os.name == "nt":
        return
    try:
        if os.path.realpath(os.readlink(f"/proc/{pid}/cwd")) != os.path.realpath(row["path"]):
            return
        os.killpg(pid, signal.SIGTERM)
        time.sleep(1)
        os.killpg(pid, signal.SIGKILL)
    except Exception:
        pass


async def notify(app, uid: int, text: str) -> None:
    try:
        await app.bot.send_message(uid, text)
    except Exception:
        pass


async def handle_exit(app, bid: int, rc: int) -> None:
    try:
        row = get_bot(bid)
        if not row or not row["desired"]:
            return
        tail = read_tail(log_path(bid), 20000)
        if "=== PANEL START" in tail:
            tail = tail.rsplit("=== PANEL START", 1)[1]
        missing = find_missing(tail, row["lang"])
        tried = AUTOFIX_DONE.setdefault(bid, set())
        if missing and missing not in tried and len(tried) < 8:
            tried.add(missing)
            append_log(bid, f"\n[panel] 🔧 missing dependency '{missing}' → installing automatically...\n")
            ok = await asyncio.to_thread(install_single, row, missing)
            append_log(bid, f"[panel] install {'OK ✅' if ok else 'FAILED ❌'}\n")
            if ok:
                start_process(get_bot(bid))
                return
        name = esc(row["name"])
        if rc == 0:
            dbx("UPDATE bots SET desired=0, pid=0 WHERE id=?", (bid,))
            await notify(app, row["owner_id"], f"ℹ️ Your bot <b>{name}</b> stopped cleanly (exit code 0).")
            return
        now = time.time()
        lst = [t for t in CRASHES.get(bid, []) if now - t < 600] + [now]
        CRASHES[bid] = lst
        if len(lst) <= MAX_AUTO_RESTARTS:
            append_log(bid, f"\n[panel] 🔁 crashed (exit {rc}) → auto-restart {len(lst)}/{MAX_AUTO_RESTARTS}\n")
            await asyncio.sleep(3)
            r2 = get_bot(bid)
            if r2 and r2["desired"]:
                start_process(r2)
        else:
            dbx("UPDATE bots SET desired=0, pid=0 WHERE id=?", (bid,))
            await notify(app, row["owner_id"],
                         f"❌ Your bot <b>{name}</b> keeps crashing and was stopped.\nOpen 🗂 Manage Bots → 📄 Logs to view error.")
    except Exception:
        LOG.exception("handle_exit failed")
    finally:
        HANDLING.discard(bid)


async def monitor_loop(app) -> None:
    tick = 0
    while True:
        try:
            await asyncio.sleep(5)
            tick += 1
            for bid, proc in list(PROCS.items()):
                if proc.poll() is None or bid in HANDLING:
                    continue
                PROCS.pop(bid, None)
                HANDLING.add(bid)
                t = asyncio.create_task(handle_exit(app, bid, proc.returncode))
                BG_TASKS.add(t)
                t.add_done_callback(BG_TASKS.discard)
            if tick % 120 == 0:
                for bid in list(PROCS):
                    trim_log(log_path(bid), limit=20 * 1024 * 1024)
        except asyncio.CancelledError:
            return
        except Exception:
            LOG.exception("monitor loop error")


# ══════════════════════════════════════════════════════════════════════
# 💬 UI HELPERS
# ══════════════════════════════════════════════════════════════════════
async def show(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str, markup=None) -> None:
    q = update.callback_query
    if q and q.message:
        try:
            await q.edit_message_text(text, reply_markup=markup)
            return
        except BadRequest as e:
            if "not modified" in str(e).lower():
                return
        except TelegramError:
            pass
    await context.bot.send_message(update.effective_chat.id, text, reply_markup=markup)


async def say(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str, markup=None):
    return await context.bot.send_message(update.effective_chat.id, text, reply_markup=markup)


async def safe_edit(msg, text: str, markup=None) -> None:
    try:
        await msg.edit_text(text, reply_markup=markup)
    except TelegramError:
        pass


def clear_state(context) -> None:
    context.user_data.pop("state", None)
    context.user_data.pop("cc", None)
    p = context.user_data.pop("pending", None)
    if p:
        shutil.rmtree(Path(p["tmp"]).parent, ignore_errors=True)
    dep = context.user_data.pop("deploy", None)
    if dep:
        abort_deploy(dep["bid"], Path(dep["dir"]))


def abort_deploy(bid: int, d: Path) -> None:
    dbx("DELETE FROM bots WHERE id=? AND ready=0", (bid,))
    shutil.rmtree(d, ignore_errors=True)
    try:
        log_path(bid).unlink()
    except Exception:
        pass


CANCEL_KB = KB([[B("❌ Cancel", "home")]])


# ══════════════════════════════════════════════════════════════════════
# 🔒 FORCE-JOIN & GATE
# ══════════════════════════════════════════════════════════════════════
async def is_member(bot, uid: int) -> bool:
    global FORCE_WARNED
    ch, _ = get_force()
    if not ch:
        return True
    ref = int(ch) if re.fullmatch(r"-?\d+", ch) else ch
    try:
        m = await bot.get_chat_member(ref, uid)
        if m.status in ("member", "administrator", "creator"):
            return True
        if m.status == "restricted":
            return bool(getattr(m, "is_member", False))
        return False
    except TelegramError as e:
        LOG.warning("Force-join check failed: %s", e)
        if not FORCE_WARNED:
            FORCE_WARNED = True
            for a in ADMIN_IDS:
                try:
                    await bot.send_message(a, f"⚠️ <b>Force-join check error:</b>\n<code>{esc(e)}</code>\n"
                                              "Ensure bot is admin in channel.")
                except Exception:
                    pass
        return True


async def on_verified(context, row) -> None:
    uid = row["user_id"]
    row = get_user(uid)
    if not row or row["verified"]:
        return
    dbx("UPDATE users SET verified=1 WHERE user_id=?", (uid,))
    ref = row["referred_by"]
    if not ref or row["ref_rewarded"] or not get_user(ref):
        return
    reward = get_ref_reward()
    add_tokens(ref, reward)
    dbx("UPDATE users SET ref_rewarded=1 WHERE user_id=?", (uid,))
    dbx("UPDATE users SET ref_earned = ref_earned + ? WHERE user_id=?", (reward, ref))
    try:
        await context.bot.send_message(
            ref, f"🎉 <b>New referral!</b>\n\n👤 {esc(row['first_name'] or uid)} joined using your link.\n"
                 f"🪙 You earned <b>{reward}</b> token(s)!")
    except Exception:
        pass


async def gate(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    user = update.effective_user
    if user is None:
        return False
    row = register_user(user)
    if row["banned"] and not is_admin(user.id):
        await say(update, context, "🚫 <b>You are banned from using this hosting panel.</b>")
        return False
    if is_admin(user.id):
        await on_verified(context, row)
        return True
    if not await is_member(context.bot, user.id):
        _, link = get_force()
        rows = []
        if link:
            rows.append([B("📢 Join Channel", url=link)])
        rows.append([B("✅ I've Joined", "chk")])
        await say(update, context,
                  "🔒 <b>Access Locked</b>\n\nTo use this bot you must join our channel first.\n\n"
                  "1️⃣ Tap <b>Join Channel</b>\n2️⃣ Then tap <b>I've Joined</b>", KB(rows))
        return False
    await on_verified(context, row)
    return True


# ══════════════════════════════════════════════════════════════════════
# 🏠 SCREENS & KEYBOARDS
# ══════════════════════════════════════════════════════════════════════
def main_menu_kb(uid: int) -> InlineKeyboardMarkup:
    rows = [
        [B("🚀 Deploy Bot", "dep"), B("🌐 Deploy Website", "web_dep")],
        [B("🗂 Manage Bots", "mm"), B("🌐 My Websites", "web_mm")],
        [B("🎟 Redeem Coupon", "red"), B("🎁 Referral", "ref")],
        [B("🌐 3D Web Dashboard", url=WEB_APP_URL)],
    ]
    if is_admin(uid):
        rows.append([B("👑 Admin Panel", "adm")])
    return KB(rows)


def menu_text(uid: int, name: str) -> str:
    u = get_user(uid)
    n_bots = dbone("SELECT COUNT(*) c FROM bots WHERE owner_id=? AND ready=1", (uid,))["c"]
    n_sites = dbone("SELECT COUNT(*) c FROM websites WHERE owner_id=?", (uid,))["c"]
    n_run = sum(1 for b in user_bots(uid) if is_running(b["id"]))
    tok = "♾ Unlimited" if is_admin(uid) else str(u["tokens"])
    return (
        f"👋 <b>Welcome, {esc(name)}!</b>\n\n"
        "🚀 <b>TeleHost 3D Cloud Platform</b>\n"
        "Host your 🐍 Python &amp; 🟨 Node.js Telegram bots + 🌐 Websites 24/7.\n\n"
        f"🪙 Available Tokens: <b>{tok}</b>\n"
        f"🤖 Hosted Bots: <b>{n_bots}</b> (🟢 {n_run} online)\n"
        f"🌐 Hosted Websites: <b>{n_sites}</b>\n\n"
        "👇 <i>Select an option below or use the quick buttons:</i>"
    )


async def show_main(update, context) -> None:
    u = update.effective_user
    # Send bottom keyboard along with message
    rkb = get_reply_keyboard(u.id)
    await context.bot.send_message(
        update.effective_chat.id,
        menu_text(u.id, u.first_name or "there"),
        reply_markup=rkb
    )
    # Also show inline menu
    await show(update, context, "⚡ <b>Quick Actions:</b>", main_menu_kb(u.id))


async def show_manage_list(update, context) -> None:
    uid = update.effective_user.id
    rows_db = user_bots(uid)
    if not rows_db:
        await show(update, context, "📭 <b>You have no hosted bots yet.</b>\n\nTap Deploy to host your first bot!",
                   KB([[B("🚀 Deploy New Bot", "dep")], [B("🔙 Back", "home")]]))
        return
    rows = []
    for b in rows_db:
        st = "🟢" if is_running(b["id"]) else "🔴"
        title = b["bot_title"] or b["name"]
        rows.append([B(f"{st} {lang_icon(b['lang'])} {title}", f"m:{b['id']}")])
    rows.append([B("🔙 Back", "home")])
    await show(update, context, "🗂 <b>Manage Your Bots</b>\n\n🟢 Running   🔴 Stopped\n👇 Select a bot to control:", KB(rows))


async def show_bot_panel(update, context, bid: int, notice: str = "") -> None:
    uid = update.effective_user.id
    row = get_bot(bid)
    if not row or not row["ready"] or (row["owner_id"] != uid and not is_admin(uid)):
        await show(update, context, "❌ Bot not found.", KB([[B("🔙 Back", "mm")]]))
        return
    running = is_running(bid)
    status = f"🟢 <b>Running</b> • uptime {fmt_dur(time.time() - row['started_at'])}" if running else "🔴 <b>Stopped</b>"
    
    bot_info = ""
    if row["bot_username"]:
        bot_info = f"\n🤖 Bot: <b>@{esc(row['bot_username'])}</b>"
    
    text = (
        (f"{notice}\n\n" if notice else "")
        + f"🤖 <b>{esc(row['bot_title'] or row['name'])}</b>\n\n"
        f"🆔 ID: <code>{bid}</code>{bot_info}\n"
        f"{lang_icon(row['lang'])} Language: <b>{lang_name(row['lang'])}</b>\n"
        f"📄 Entry: <code>{esc(row['entry'])}</code>\n📡 Status: {status}\n"
        f"📅 Created: {datetime.fromtimestamp(row['created_at']):%d %b %Y}"
        + (f"\n👤 Owner: <code>{row['owner_id']}</code>" if row["owner_id"] != uid else "")
    )
    toggle = B("⏹ Stop", f"t:{bid}") if running else B("▶️ Start", f"t:{bid}")
    back = "mm" if row["owner_id"] == uid else "adm_bots"
    
    kb_rows = [
        [toggle, B("🔄 Restart", f"r:{bid}")],
        [B("📄 Logs", f"l:{bid}"), B("🔃 Refresh", f"m:{bid}")],
    ]
    # Direct redirect button to Telegram bot if username is available!
    if row["bot_username"]:
        kb_rows.append([B(f"🤖 Open Bot (@{row['bot_username']})", url=f"https://t.me/{row['bot_username']}")])
    kb_rows.append([B("🗑 Delete Bot", f"d:{bid}")])
    kb_rows.append([B("🔙 Back", back)])
    
    await show(update, context, text, KB(kb_rows))


# ── Web Hosting Screens ──
async def show_websites_list(update, context) -> None:
    uid = update.effective_user.id
    sites = user_websites(uid)
    if not sites:
        await show(update, context, "🌐 <b>No hosted websites yet.</b>\n\nUpload an <code>index.html</code> or <code>.zip</code> file to make it live instantly!",
                   KB([[B("🌐 Deploy Website", "web_dep")], [B("🔙 Back", "home")]]))
        return
    rows = []
    for s in sites:
        preview_url = f"{WEB_APP_URL}/sites/{s['slug']}/"
        rows.append([B(f"🌐 {s['name']}", url=preview_url), B("🗑", f"wd:{s['id']}")])
    rows.append([B("🌐 Deploy Another Website", "web_dep")])
    rows.append([B("🔙 Back", "home")])
    await show(update, context, "🌐 <b>Your Hosted Websites</b>\n\nTap to open live preview:", KB(rows))


async def show_referral(update, context) -> None:
    uid = update.effective_user.id
    u = get_user(uid)
    link = f"https://t.me/{context.bot.username}?start=ref_{uid}"
    done = dbone("SELECT COUNT(*) c FROM users WHERE referred_by=? AND ref_rewarded=1", (uid,))["c"]
    pend = dbone("SELECT COUNT(*) c FROM users WHERE referred_by=? AND ref_rewarded=0", (uid,))["c"]
    reward = get_ref_reward()
    share = f"https://t.me/share/url?url={quote(link)}&text={quote('🚀 Host your Telegram bots & Websites 24/7 for FREE! Join here 👇')}"
    text = (
        "🎁 <b>Referral Program</b>\n\n"
        f"Invite friends — when your friend <b>joins our channel &amp; starts the bot</b> you get "
        f"<b>{reward} 🪙 token(s)</b>.\n\n"
        f"🔗 <b>Your Referral Link:</b>\n<code>{link}</code>\n\n"
        f"✅ Successful referrals: <b>{done}</b>\n⏳ Pending: <b>{pend}</b>\n"
        f"🪙 Total Tokens Earned: <b>{u['ref_earned']}</b>"
    )
    await show(update, context, text, KB([[B("📤 Share Link", url=share)], [B("🔙 Back", "home")]]))


def admin_kb() -> InlineKeyboardMarkup:
    return KB([
        [B("📊 Full Stats", "adm_stats"), B("👥 Export CSV", "adm_users")],
        [B("🎲 1-Click Auto Coupon", "adm_cc_auto"), B("🎟 Custom Coupon", "adm_cc")],
        [B("📋 All Coupons", "adm_cl"), B("🪙 Give/Remove Tokens", "adm_give")],
        [B("📢 Broadcast Message", "adm_bc"), B("🖥 All Bots", "adm_bots")],
        [B("🌐 All Websites", "adm_sites"), B("🎁 Referral Reward", "adm_ref")],
        [B("🚫 Ban User", "adm_ban"), B("✅ Unban User", "adm_unban")],
        [B("📌 Force Channel", "adm_chan")],
        [B("🔙 Back", "home")],
    ])


def stats_text() -> str:
    c = lambda sql: dbone(sql)["c"]
    users = c("SELECT COUNT(*) c FROM users")
    verified = c("SELECT COUNT(*) c FROM users WHERE verified=1")
    today = dbone("SELECT COUNT(*) c FROM users WHERE joined_at >= ?", (int(time.time()) - 86400,))["c"]
    banned = c("SELECT COUNT(*) c FROM users WHERE banned=1")
    bots = c("SELECT COUNT(*) c FROM bots WHERE ready=1")
    sites = c("SELECT COUNT(*) c FROM websites")
    py = c("SELECT COUNT(*) c FROM bots WHERE ready=1 AND lang='python'")
    running = sum(1 for b in list(PROCS) if is_running(b))
    owners = c("SELECT COUNT(DISTINCT owner_id) c FROM bots WHERE ready=1")
    tokens = dbone("SELECT COALESCE(SUM(tokens),0) c FROM users")["c"]
    cp_all = c("SELECT COUNT(*) c FROM coupons")
    cp_act = c("SELECT COUNT(*) c FROM coupons WHERE used < max_uses")
    refs = c("SELECT COUNT(*) c FROM users WHERE ref_rewarded=1")
    try:
        du = shutil.disk_usage(str(DATA_DIR))
        disk = f"{du.free / 1e9:.1f} GB free of {du.total / 1e9:.1f} GB"
    except Exception:
        disk = "n/a"
    ch, _ = get_force()
    return (
        "📊 <b>Panel Real-Time Statistics</b>\n\n"
        f"👥 Total Users: <b>{users}</b> (✅ {verified} verified)\n"
        f"🆕 Joined in 24h: <b>{today}</b> | 🚫 Banned: <b>{banned}</b>\n\n"
        f"🤖 Hosted Bots: <b>{bots}</b> (🐍 {py} • 🟨 {bots - py})\n"
        f"🟢 Currently Running: <b>{running}</b> | 👤 Bot Owners: <b>{owners}</b>\n"
        f"🌐 Hosted Websites: <b>{sites}</b>\n\n"
        f"🪙 Total User Tokens: <b>{tokens}</b>\n"
        f"🎟 Coupons Created: <b>{cp_all}</b> (🟢 {cp_act} active)\n"
        f"🎁 Successful Referrals: <b>{refs}</b>\n\n"
        f"📌 Force-Join: <b>{esc(ch) if ch else 'OFF'}</b>\n"
        f"💾 Disk Space: {disk}\n"
        f"⏱ Server Uptime: {fmt_dur(time.time() - STARTED_AT)}"
    )


# ══════════════════════════════════════════════════════════════════════
# 🚀 DEPLOY LOGIC
# ══════════════════════════════════════════════════════════════════════
def can_deploy(uid: int) -> bool:
    return is_admin(uid) or get_user(uid)["tokens"] >= DEPLOY_COST


NO_TOKEN_TEXT = (
    "❌ <b>Not enough tokens!</b>\n\n"
    f"You need <b>{DEPLOY_COST} 🪙 token</b> to deploy.\n"
    "Claim free tokens with 🎁 <b>Referral</b> or 🎟 <b>Redeem Coupon</b>."
)
NO_TOKEN_KB = KB([[B("🎁 Referral", "ref"), B("🎟 Redeem Coupon", "red")], [B("🔙 Back", "home")]])


async def handle_document(update, context) -> None:
    msg = update.effective_message
    doc = msg.document
    uid = update.effective_user.id
    st = context.user_data.get("state")

    if st not in ("await_file", "await_web_file"):
        await say(update, context, "ℹ️ Use the bottom menu buttons to Deploy a Bot or Website.", main_menu_kb(uid))
        return

    # Website Deployment File Handler
    if st == "await_web_file":
        fname = doc.file_name or "site.zip"
        ext = Path(fname).suffix.lower()
        if ext not in (".zip", ".html", ".htm"):
            await say(update, context, "❌ Please send an <code>.html</code> file or a <code>.zip</code> archive of your website.", CANCEL_KB)
            return
        tmpdir = DATA_DIR / "tmp" / f"web_{uid}_{int(time.time())}"
        tmpdir.mkdir(parents=True, exist_ok=True)
        dest = tmpdir / safe_filename(fname, ext)
        note = await say(update, context, "⏬ Downloading website files...")
        try:
            f = await context.bot.get_file(doc.file_id)
            await f.download_to_drive(custom_path=dest)
        except Exception as e:
            shutil.rmtree(tmpdir, ignore_errors=True)
            await safe_edit(note, f"❌ Download failed: {esc(e)}", CANCEL_KB)
            return
        context.user_data["pending_web"] = {"tmp": str(dest), "filename": dest.name}
        context.user_data["state"] = "await_web_name"
        await safe_edit(note, "✅ <b>Website file received!</b>\n\n✏️ Send a <b>Title / Name</b> for this website:\n(example: <i>My Portfolio</i>)", CANCEL_KB)
        return

    # Bot Deployment File Handler
    lang = context.user_data.get("lang", "python")
    fname = doc.file_name or "file"
    ext = Path(fname).suffix.lower()
    allowed = (".zip", ".py") if lang == "python" else (".zip",) + JS_EXTS
    if ext not in allowed:
        await say(update, context, f"❌ Wrong file type. Please send {' / '.join(allowed)}", CANCEL_KB)
        return
    if doc.file_size and doc.file_size > MAX_UPLOAD_MB * 1024 * 1024:
        await say(update, context, f"❌ File too large. Max limit is {MAX_UPLOAD_MB} MB.", CANCEL_KB)
        return
    tmpdir = DATA_DIR / "tmp" / f"{uid}_{int(time.time())}"
    tmpdir.mkdir(parents=True, exist_ok=True)
    dest = tmpdir / safe_filename(fname, ext)
    note = await say(update, context, "⏬ Downloading your code...")
    try:
        f = await context.bot.get_file(doc.file_id)
        await f.download_to_drive(custom_path=dest)
    except Exception as e:
        shutil.rmtree(tmpdir, ignore_errors=True)
        await safe_edit(note, f"❌ Download failed: {esc(e)}", CANCEL_KB)
        return
    context.user_data["pending"] = {"tmp": str(dest), "filename": dest.name, "lang": lang}
    context.user_data["state"] = "await_name"
    await safe_edit(note, "✅ <b>Code file received!</b>\n\n✏️ Send a <b>Name / Title</b> for this bot\n(example: <i>Music Downloader</i>)", CANCEL_KB)


async def start_web_deploy(update, context, name: str) -> None:
    uid = update.effective_user.id
    pend = context.user_data.pop("pending_web", None)
    context.user_data.pop("state", None)
    if not pend:
        await say(update, context, "⚠️ Session expired. Please start again.", main_menu_kb(uid))
        return
    if not can_deploy(uid):
        shutil.rmtree(Path(pend["tmp"]).parent, ignore_errors=True)
        await say(update, context, NO_TOKEN_TEXT, NO_TOKEN_KB)
        return
    
    status = await say(update, context, "⏳ <b>Publishing your website online...</b>")
    slug = re.sub(r"[^\w\-]", "", name.lower().replace(" ", "-"))[:20] or f"site-{secrets.token_hex(3)}"
    slug = f"{slug}-{secrets.token_hex(3)}"
    dest_dir = DATA_DIR / "websites" / slug
    dest_dir.mkdir(parents=True, exist_ok=True)
    
    src = Path(pend["tmp"])
    try:
        if pend["filename"].lower().endswith(".zip"):
            safe_extract(src, dest_dir)
            flatten_single_dir(dest_dir)
        else:
            shutil.copy2(src, dest_dir / "index.html")
        shutil.rmtree(src.parent, ignore_errors=True)
    except Exception as e:
        shutil.rmtree(dest_dir, ignore_errors=True)
        await safe_edit(status, f"❌ <b>Extraction failed:</b> {esc(e)}", CANCEL_KB)
        return

    # Check for index.html or first html
    entry = "index.html"
    if not (dest_dir / "index.html").exists():
        htmls = list(dest_dir.glob("*.html"))
        if htmls:
            entry = htmls[0].name
        else:
            (dest_dir / "index.html").write_text("<h1>Hosted on TeleHost 3D</h1>", encoding="utf-8")

    dbx("INSERT INTO websites(owner_id, name, slug, path, entry, created_at) VALUES(?,?,?,?,?,?)",
        (uid, name, slug, str(dest_dir), entry, int(time.time())))
    if not is_admin(uid):
        add_tokens(uid, -DEPLOY_COST)

    live_url = f"{WEB_APP_URL}/sites/{slug}/"
    share_url = f"https://t.me/share/url?url={quote(live_url)}&text={quote(f'Check out my live website: {name}')}"
    
    kb = KB([
        [B("🌐 Live Preview", url=live_url), B("📤 Share Website", url=share_url)],
        [B("🌐 My Websites", "web_mm"), B("🏠 Menu", "home")],
    ])
    await safe_edit(
        status,
        f"🎉 <b>Website Published Online!</b>\n\n"
        f"🌐 <b>{esc(name)}</b>\n"
        f"🔗 <b>URL:</b> <code>{live_url}</code>\n\n"
        "Your website is live 24/7 on high-speed CDN servers!",
        kb
    )


async def start_deploy(update, context, name: str) -> None:
    uid = update.effective_user.id
    pend = context.user_data.pop("pending", None)
    context.user_data.pop("state", None)
    if not pend:
        await say(update, context, "⚠️ Session expired. Please start again.", main_menu_kb(uid))
        return
    if not can_deploy(uid):
        shutil.rmtree(Path(pend["tmp"]).parent, ignore_errors=True)
        await say(update, context, NO_TOKEN_TEXT, NO_TOKEN_KB)
        return
    lang = pend["lang"]
    status = await say(update, context, "⏳ <b>Step 1/3</b> • Extracting &amp; analyzing files...")
    cur = dbx("INSERT INTO bots(owner_id,name,lang,ready,created_at) VALUES(?,?,?,0,?)",
              (uid, name, lang, int(time.time())))
    bid = cur.lastrowid
    d = DATA_DIR / "bots" / str(uid) / str(bid)
    dbx("UPDATE bots SET path=? WHERE id=?", (str(d), bid))
    ok, err = await asyncio.to_thread(extract_project, Path(pend["tmp"]), pend["filename"], lang, d)
    shutil.rmtree(Path(pend["tmp"]).parent, ignore_errors=True)
    if not ok:
        abort_deploy(bid, d)
        await safe_edit(status, f"❌ <b>Deploy failed:</b>\n\n{err}", KB([[B("🚀 Try Again", "dep"), B("🏠 Menu", "home")]]))
        return
    
    # Auto-detect Bot Token & verify via Telegram getMe
    detected_token = detect_token_in_dir(d)
    bot_title = name
    bot_uname = ""
    if detected_token:
        tok_ok, t_title, t_uname = inspect_bot_token(detected_token)
        if tok_ok:
            bot_title = t_title
            bot_uname = t_uname
            dbx("UPDATE bots SET bot_token=?, bot_username=?, bot_title=? WHERE id=?",
                (detected_token, bot_uname, bot_title, bid))

    entry = detect_entry(d, lang)
    if not entry:
        files = list_code_files(d, lang)
        context.user_data["deploy"] = {"bid": bid, "dir": str(d), "lang": lang, "name": name, "uname": bot_uname, "title": bot_title}
        context.user_data["state"] = "await_entry"
        listing = "\n".join(f"• <code>{esc(f)}</code>" for f in files) or "—"
        await safe_edit(status, "❓ <b>Which file should be started?</b>\n\nSend the main file name:\n" + listing, CANCEL_KB)
        return
    await finish_deploy(update, context, status, bid, d, lang, bot_title, entry, bot_uname)


async def finish_deploy(update, context, status, bid: int, d: Path, lang: str, name: str, entry: str, bot_uname: str = "") -> None:
    uid = update.effective_user.id
    await safe_edit(status, "⏳ <b>Step 2/3</b> • Installing requirements in background...\n<i>Please wait a moment.</i>")
    try:
        ok, note = await asyncio.to_thread(prepare_env, d, lang, bid)
    except Exception as e:
        ok, note = False, str(e)
    if not ok:
        abort_deploy(bid, d)
        await safe_edit(status, f"❌ <b>Deploy failed:</b>\n\n{esc(note)}", KB([[B("🏠 Menu", "home")]]))
        return
    if not can_deploy(uid):
        abort_deploy(bid, d)
        await safe_edit(status, NO_TOKEN_TEXT, NO_TOKEN_KB)
        return
    if not is_admin(uid):
        add_tokens(uid, -DEPLOY_COST)
    dbx("UPDATE bots SET ready=1, entry=? WHERE id=?", (entry, bid))
    warn = f"\n\n⚠️ <i>{esc(note)}</i>" if note else ""
    
    kb_buttons = [
        [B("▶️ Start Bot Now", f"t:{bid}")],
        [B("🗂 Manage Bots", "mm"), B("🏠 Menu", "home")],
    ]
    bot_info_str = f"\n🤖 Telegram Bot: <b>@{bot_uname}</b>" if bot_uname else ""
    if bot_uname:
        kb_buttons.insert(0, [B(f"🤖 Open Bot (@{bot_uname})", url=f"https://t.me/{bot_uname}")])

    await safe_edit(
        status,
        f"✅ <b>Step 3/3 • Deployed Successfully!</b>\n\n"
        f"🤖 <b>{esc(name)}</b>{bot_info_str}\n"
        f"{lang_icon(lang)} {lang_name(lang)} • 📄 <code>{esc(entry)}</code>\n"
        f"🔴 Status: Stopped\n\n"
        f"Tap <b>▶️ Start Bot Now</b> below to turn it online!{warn}",
        KB(kb_buttons),
    )


# ══════════════════════════════════════════════════════════════════════
# 📢 BROADCAST
# ══════════════════════════════════════════════════════════════════════
async def do_broadcast(bot, admin_chat: int, src_chat: int, src_mid: int) -> None:
    uids = [r["user_id"] for r in dball("SELECT user_id FROM users WHERE banned=0")]
    ok = fail = 0
    for u in uids:
        for attempt in range(2):
            try:
                await bot.copy_message(u, src_chat, src_mid)
                ok += 1
                break
            except RetryAfter as e:
                await asyncio.sleep(e.retry_after + 1)
            except Exception:
                fail += 1
                break
        await asyncio.sleep(0.05)
    try:
        await bot.send_message(admin_chat, f"📢 <b>Broadcast Finished!</b>\n\n✅ Sent to: {ok} users\n❌ Failed: {fail}")
    except Exception:
        pass


def spawn(coro) -> None:
    t = asyncio.create_task(coro)
    BG_TASKS.add(t)
    t.add_done_callback(BG_TASKS.discard)


# ══════════════════════════════════════════════════════════════════════
# ⌨️  MESSAGE & CONVERSATION HANDLER
# ══════════════════════════════════════════════════════════════════════
async def handle_text(update, context) -> None:
    msg = update.effective_message
    text = (msg.text or "").strip()
    uid = update.effective_user.id
    st = context.user_data.get("state")
    adm_ok = is_admin(uid)

    # Handle Bottom ReplyKeyboardMarkup button clicks
    if text == "🚀 Deploy Bot":
        clear_state(context)
        context.user_data["state"] = None
        tok = "♾" if is_admin(uid) else get_user(uid)["tokens"]
        await say(update, context,
                  f"🚀 <b>Deploy New Bot</b>\n\n💰 Cost: <b>{DEPLOY_COST} 🪙</b> token • Balance: <b>{tok}</b>\n\n"
                  "Choose your bot language:",
                  KB([[B("🐍 Python", "dl:python"), B("🟨 JavaScript (Node.js)", "dl:node")], [B("🔙 Back", "home")]]))
        return
    elif text == "🌐 Deploy Website":
        clear_state(context)
        tok = "♾" if is_admin(uid) else get_user(uid)["tokens"]
        context.user_data["state"] = "await_web_file"
        await say(update, context,
                  f"🌐 <b>Deploy Website Online</b>\n\n💰 Cost: <b>{DEPLOY_COST} 🪙</b> token • Balance: <b>{tok}</b>\n\n"
                  "📤 Send your website file: <b>index.html</b> or a <b>.zip</b> archive containing HTML/CSS/JS files.",
                  CANCEL_KB)
        return
    elif text == "🗂 Manage Bots":
        clear_state(context)
        await show_manage_list(update, context)
        return
    elif text == "🌐 My Websites":
        clear_state(context)
        await show_websites_list(update, context)
        return
    elif text == "🎟 Redeem Coupon":
        clear_state(context)
        context.user_data["state"] = "redeem"
        await say(update, context, "🎟 <b>Redeem Coupon</b>\n\nSend your coupon code now 👇", CANCEL_KB)
        return
    elif text == "🎁 Referral":
        clear_state(context)
        await show_referral(update, context)
        return
    elif text == "🌐 Web Dashboard":
        await say(update, context, f"🌐 <b>TeleHost 3D Web Dashboard:</b>\n\nControl bots and websites from your browser:\n🔗 {WEB_APP_URL}",
                  KB([[B("Open 3D Web Panel", url=WEB_APP_URL)]]))
        return
    elif text == "👑 Admin Panel" and adm_ok:
        clear_state(context)
        await say(update, context, "👑 <b>Admin Control Panel</b>", admin_kb())
        return
    elif text == "ℹ️ Help & Support":
        ch, link = get_force()
        await say(update, context,
                  f"ℹ️ <b>TeleHost 3D Support</b>\n\n"
                  f"Need help or free tokens? Contact us on Telegram:\n"
                  f"📢 Channel: {link or '@modapkpro02'}\n"
                  f"🌐 Website: {WEB_APP_URL}",
                  KB([[B("📢 Support Channel", url=link or 'https://t.me/modapkpro02')]]))
        return

    # Handle Active State Inputs
    if st == "await_file":
        await say(update, context, "📤 Please send your bot file (.zip / .py / .js) or tap Cancel.", CANCEL_KB)
    elif st == "await_web_file":
        await say(update, context, "📤 Please send your website file (index.html or .zip) or tap Cancel.", CANCEL_KB)
    elif st == "await_name":
        name = re.sub(r"\s+", " ", text).strip()[:40]
        if not name:
            await say(update, context, "❌ Please enter a valid name.", CANCEL_KB)
            return
        await start_deploy(update, context, name)
    elif st == "await_web_name":
        name = re.sub(r"\s+", " ", text).strip()[:40]
        if not name:
            await say(update, context, "❌ Please enter a valid name.", CANCEL_KB)
            return
        await start_web_deploy(update, context, name)
    elif st == "await_entry":
        dep = context.user_data.get("deploy")
        if not dep:
            context.user_data.pop("state", None)
            return
        d = Path(dep["dir"])
        entry = text.replace("\\", "/").lstrip("./")
        exts = (".py",) if dep["lang"] == "python" else JS_EXTS
        target = (d / entry).resolve()
        if not entry.lower().endswith(exts) or not target.is_file() or d.resolve() not in target.parents:
            await say(update, context, "❌ File does not exist. Please send exact name from the list.", CANCEL_KB)
            return
        context.user_data.pop("deploy", None)
        context.user_data.pop("state", None)
        status = await say(update, context, "⏳ Finishing deployment...")
        await finish_deploy(update, context, status, dep["bid"], d, dep["lang"], dep.get("title", dep["name"]), entry, dep.get("uname", ""))
    elif st == "redeem":
        context.user_data.pop("state", None)
        res = redeem_coupon(uid, text)
        await say(update, context, res, KB([[B("🚀 Deploy Bot", "dep")], [B("🏠 Main Menu", "home")]]))
    elif st == "cc_tokens" and adm_ok:
        n = parse_int(text, 1, 100000)
        if n is None:
            await say(update, context, "❌ Enter a valid number (1 - 100000).", CANCEL_KB)
            return
        context.user_data["cc"] = {"tokens": n}
        context.user_data["state"] = "cc_max"
        await say(update, context, f"✅ Tokens per user: <b>{n}</b>\n\n👥 For how many users?\n(example: 20)", CANCEL_KB)
    elif st == "cc_max" and adm_ok:
        n = parse_int(text, 1, 10_000_000)
        if n is None:
            await say(update, context, "❌ Enter a valid number.", CANCEL_KB)
            return
        context.user_data["cc"]["max"] = n
        context.user_data["state"] = "cc_code"
        auto_code = generate_coupon_code()
        await say(update, context,
                  f"✅ Max users: <b>{n}</b>\n\n🔤 Send a custom code or tap below to use auto-generated code <code>{auto_code}</code>:",
                  KB([[B(f"🎲 Use {auto_code}", f"use_code:{auto_code}")], [B("❌ Cancel", "home")]]))
    elif st == "cc_code" and adm_ok:
        code = text.upper().replace(" ", "")
        if not re.fullmatch(r"[A-Z0-9_\-]{3,24}", code):
            await say(update, context, "❌ Invalid code format (use A-Z, 0-9, -, _).", CANCEL_KB)
            return
        if dbone("SELECT 1 FROM coupons WHERE code=?", (code,)):
            await say(update, context, "❌ This coupon code already exists.", CANCEL_KB)
            return
        cc = context.user_data.pop("cc", {})
        context.user_data.pop("state", None)
        dbx("INSERT INTO coupons(code,tokens,max_uses,created_at) VALUES(?,?,?,?)",
            (code, cc.get("tokens", 1), cc.get("max", 1), int(time.time())))
        await say(update, context,
                  f"🎟 <b>Coupon Created!</b>\n\n🔑 Code: <code>{code}</code>\n🪙 Tokens: <b>{cc.get('tokens')}</b>\n"
                  f"👥 Max Users: <b>{cc.get('max')}</b>",
                  KB([[B("🎟 Create Another", "adm_cc")], [B("👑 Admin Panel", "adm")]]))
    elif st == "give" and adm_ok:
        p = text.split()
        target = parse_int(p[0], 1, 10 ** 15) if p else None
        amount = parse_int(p[1], -100000, 100000) if len(p) > 1 else None
        if target is None or amount is None or not get_user(target):
            await say(update, context, "❌ Format: <code>user_id amount</code>", CANCEL_KB)
            return
        add_tokens(target, amount)
        context.user_data.pop("state", None)
        await notify(context.application, target, f"🪙 Admin added/removed <b>{amount}</b> tokens to your account.")
        await say(update, context, f"✅ Balance of <code>{target}</code> is now: <b>{get_user(target)['tokens']}</b>",
                  KB([[B("👑 Admin Panel", "adm")]]))
    elif st in ("ban", "unban") and adm_ok:
        target = parse_int(text, 1, 10 ** 15)
        if target is None or not get_user(target):
            await say(update, context, "❌ Valid User ID required.", CANCEL_KB)
            return
        dbx("UPDATE users SET banned=? WHERE user_id=?", (1 if st == "ban" else 0, target))
        context.user_data.pop("state", None)
        if st == "ban":
            for b in dball("SELECT id FROM bots WHERE owner_id=?", (target,)):
                await asyncio.to_thread(stop_process, b["id"])
        await say(update, context, f"✅ User <code>{target}</code> {'banned 🚫' if st == 'ban' else 'unbanned ✅'}.",
                  KB([[B("👑 Admin Panel", "adm")]]))
    elif st == "ref_reward" and adm_ok:
        n = parse_int(text, 0, 1000)
        if n is None:
            await say(update, context, "❌ Send a number between 0 and 1000.", CANCEL_KB)
            return
        set_setting("ref_reward", n)
        context.user_data.pop("state", None)
        await say(update, context, f"✅ Referral reward updated to <b>{n}</b> tokens.", KB([[B("👑 Admin Panel", "adm")]]))
    else:
        await show_main(update, context)


async def on_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    msg = update.effective_message
    if msg is None or update.effective_user is None:
        return
    if not await gate(update, context):
        return
    uid = update.effective_user.id
    if context.user_data.get("state") == "bc" and is_admin(uid):
        context.user_data.pop("state", None)
        await say(update, context, "📢 Broadcast started in background...")
        spawn(do_broadcast(context.bot, update.effective_chat.id, msg.chat_id, msg.message_id))
        return
    if msg.document:
        await handle_document(update, context)
    elif msg.text:
        await handle_text(update, context)
    else:
        await show_main(update, context)


# ══════════════════════════════════════════════════════════════════════
# 🎛  CALLBACK ROUTER
# ══════════════════════════════════════════════════════════════════════
async def on_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    data = q.data or ""
    uid = q.from_user.id

    if data == "chk":
        row = register_user(q.from_user)
        if row["banned"] and not is_admin(uid):
            await q.answer("🚫 You are banned.", show_alert=True)
            return
        if is_admin(uid) or await is_member(context.bot, uid):
            await q.answer("✅ Verified!")
            await on_verified(context, get_user(uid))
            await show_main(update, context)
        else:
            await q.answer("❌ You have not joined the channel yet!", show_alert=True)
        return

    if not await gate(update, context):
        try:
            await q.answer()
        except TelegramError:
            pass
        return
    try:
        await q.answer()
    except TelegramError:
        pass

    clear_state(context)

    if data == "home":
        await show_main(update, context)

    # ── Bot Deployment ──
    elif data == "dep":
        tok = "♾" if is_admin(uid) else get_user(uid)["tokens"]
        await show(update, context,
                   f"🚀 <b>Deploy New Bot</b>\n\n💰 Cost: <b>{DEPLOY_COST} 🪙</b> token • Balance: <b>{tok}</b>\n\n"
                   "Which language is your bot written in?",
                   KB([[B("🐍 Python", "dl:python"), B("🟨 JavaScript (Node.js)", "dl:node")], [B("🔙 Back", "home")]]))
    elif data.startswith("dl:"):
        lang = "python" if data.endswith("python") else "node"
        if not can_deploy(uid):
            await show(update, context, NO_TOKEN_TEXT, NO_TOKEN_KB)
            return
        context.user_data["state"] = "await_file"
        context.user_data["lang"] = lang
        kinds = ".zip or .py" if lang == "python" else ".zip or .js"
        reqs = "requirements.txt" if lang == "python" else "package.json"
        await show(update, context,
                   f"📤 <b>Send your {lang_icon(lang)} {lang_name(lang)} code</b>\n\n"
                   f"Upload your <b>{kinds}</b> file.\n"
                   f"• 📦 <code>{reqs}</code> installed automatically\n"
                   f"• 🤖 Bot Token auto-detected for direct @link\n"
                   f"• 🔧 Missing modules auto-installed\n"
                   f"• 📏 Max size: {MAX_UPLOAD_MB} MB", CANCEL_KB)

    # ── Website Deployment ──
    elif data == "web_dep":
        if not can_deploy(uid):
            await show(update, context, NO_TOKEN_TEXT, NO_TOKEN_KB)
            return
        context.user_data["state"] = "await_web_file"
        await show(update, context,
                   "🌐 <b>Deploy Website Online</b>\n\n"
                   "Send an <b>index.html</b> file or a <b>.zip</b> archive containing static web files.\n"
                   "We will host it with a high-speed live preview URL!", CANCEL_KB)
    elif data == "web_mm":
        await show_websites_list(update, context)
    elif data.startswith("wd:"):
        sid = int(data.split(":")[1])
        s = dbone("SELECT * FROM websites WHERE id=?", (sid,))
        if s and (s["owner_id"] == uid or is_admin(uid)):
            shutil.rmtree(s["path"], ignore_errors=True)
            dbx("DELETE FROM websites WHERE id=?", (sid,))
            if REFUND_ON_DELETE and not is_admin(s["owner_id"]):
                add_tokens(s["owner_id"], DEPLOY_COST)
            await show(update, context, "🗑 <b>Website deleted.</b> Token refunded.", KB([[B("🌐 My Websites", "web_mm"), B("🏠 Menu", "home")]]))

    # ── Bot Management ──
    elif data == "mm":
        await show_manage_list(update, context)
    elif re.fullmatch(r"(m|t|r|l|d|dy):\d+", data):
        action, bid = data.split(":")
        bid = int(bid)
        row = get_bot(bid)
        if not row or not row["ready"] or (row["owner_id"] != uid and not is_admin(uid)):
            await show(update, context, "❌ Bot not found.", KB([[B("🔙 Back", "mm")]]))
            return
        if action == "m":
            await show_bot_panel(update, context, bid)
        elif action == "t":
            if is_running(bid):
                await asyncio.to_thread(stop_process, bid)
                notice = "⏹ <b>Bot stopped.</b>"
            else:
                AUTOFIX_DONE.pop(bid, None)
                CRASHES.pop(bid, None)
                ok, m = start_process(row)
                await asyncio.sleep(1.5)
                notice = "▶️ <b>Bot started.</b>" if ok else f"❌ <b>{esc(m)}</b>"
            await show_bot_panel(update, context, bid, notice)
        elif action == "r":
            await asyncio.to_thread(stop_process, bid)
            AUTOFIX_DONE.pop(bid, None)
            CRASHES.pop(bid, None)
            ok, m = start_process(get_bot(bid))
            await asyncio.sleep(1.5)
            notice = "🔄 <b>Bot restarted.</b>" if ok else f"❌ <b>{esc(m)}</b>"
            await show_bot_panel(update, context, bid, notice)
        elif action == "l":
            lp = log_path(bid)
            if not lp.exists() or lp.stat().st_size == 0:
                await say(update, context, "📭 No output yet. Start the bot first.")
                return
            tail = read_tail(lp, 1500)
            cap = f"📄 <b>Logs • {esc(row['name'])}</b>\n<pre>{fit_html_tail(tail, 700)}</pre>"
            try:
                with open(lp, "rb") as f:
                    await context.bot.send_document(update.effective_chat.id, document=f,
                                                    filename=f"{row['name']}_logs.txt", caption=cap)
            except TelegramError as e:
                await say(update, context, f"❌ Could not send logs: {esc(e)}")
        elif action == "d":
            await show(update, context, f"⚠️ <b>Delete {esc(row['name'])}?</b>\n\nAll files will be removed permanently.",
                       KB([[B("✅ Yes, Delete", f"dy:{bid}"), B("❌ Cancel", f"m:{bid}")]]))
        elif action == "dy":
            await asyncio.to_thread(stop_process, bid)
            await asyncio.to_thread(shutil.rmtree, row["path"], True)
            try:
                log_path(bid).unlink()
            except Exception:
                pass
            dbx("DELETE FROM bots WHERE id=?", (bid,))
            if REFUND_ON_DELETE and not is_admin(row["owner_id"]):
                add_tokens(row["owner_id"], DEPLOY_COST)
            await show(update, context, "🗑 <b>Bot deleted.</b> Token refunded.", KB([[B("🗂 Manage Bots", "mm"), B("🏠 Menu", "home")]]))

    # ── Redeem & Referral ──
    elif data == "red":
        context.user_data["state"] = "redeem"
        await show(update, context, "🎟 <b>Redeem Coupon</b>\n\nSend your coupon code now 👇", CANCEL_KB)
    elif data == "ref":
        await show_referral(update, context)

    # ── Auto Code Coupon Helper ──
    elif data.startswith("use_code:") and is_admin(uid):
        code = data.split(":", 1)[1]
        cc = context.user_data.pop("cc", {})
        dbx("INSERT INTO coupons(code,tokens,max_uses,created_at) VALUES(?,?,?,?)",
            (code, cc.get("tokens", 1), cc.get("max", 1), int(time.time())))
        await show(update, context,
                   f"🎟 <b>Coupon Created!</b>\n\n🔑 Code: <code>{code}</code>\n🪙 Tokens: <b>{cc.get('tokens')}</b>\n👥 Max Users: <b>{cc.get('max')}</b>",
                   KB([[B("🎟 Create Another", "adm_cc")], [B("👑 Admin Panel", "adm")]]))

    # ── Admin Panel ──
    elif data.startswith("adm"):
        if not is_admin(uid):
            await say(update, context, "⛔ Admins only.")
            return
        if data == "adm":
            await show(update, context, "👑 <b>Admin Control Panel</b>", admin_kb())
        elif data == "adm_stats":
            await show(update, context, stats_text(), KB([[B("🔃 Refresh", "adm_stats")], [B("🔙 Back", "adm")]]))
        elif data == "adm_cc_auto":
            # 1-Click Auto coupon generator (adds 2 tokens for 25 users)
            code = generate_coupon_code("VIP")
            dbx("INSERT INTO coupons(code,tokens,max_uses,created_at) VALUES(?,?,?,?)", (code, 2, 25, int(time.time())))
            await show(update, context,
                       f"🎲 <b>1-Click Auto Coupon Created!</b>\n\n"
                       f"🔑 Code: <code>{code}</code>\n🪙 Tokens per user: <b>2</b>\n👥 Valid for: <b>25</b> users\n\n"
                       "Tap to copy code and share with users!",
                       KB([[B("🎲 Generate Another", "adm_cc_auto")], [B("👑 Admin Panel", "adm")]]))
        elif data == "adm_cc":
            context.user_data["state"] = "cc_tokens"
            await show(update, context, "🎟 <b>Create Custom Coupon</b>\n\n🪙 How many tokens should each user receive?\n(example: 3)", CANCEL_KB)
        elif data == "adm_cl":
            rows = dball("SELECT * FROM coupons ORDER BY created_at DESC LIMIT 25")
            txt = "📋 <b>Active Coupons</b>\n\n" + "\n".join(
                f"{'🟢' if r['used'] < r['max_uses'] else '🔴 expired'} <code>{esc(r['code'])}</code> — "
                f"{r['tokens']}🪙 ({r['used']}/{r['max_uses']} used)" for r in rows
            ) if rows else "No coupons yet."
            await show(update, context, txt, KB([[B("🔙 Back", "adm")]]))
        elif data == "adm_give":
            context.user_data["state"] = "give"
            await show(update, context, "🪙 <b>Give / Remove Tokens:</b>\n\nSend: <code>user_id amount</code>\nExample: <code>5960319648 5</code>", CANCEL_KB)
        elif data == "adm_bc":
            context.user_data["state"] = "bc"
            await show(update, context, "📢 <b>Broadcast to All Users:</b>\n\nSend the message (text, photo, etc.) to broadcast.", CANCEL_KB)
        elif data == "adm_bots":
            bots_db = dball("SELECT * FROM bots WHERE ready=1 ORDER BY id DESC LIMIT 40")
            rows = [[B(f"{'🟢' if is_running(b['id']) else '🔴'} #{b['id']} {b['bot_title'] or b['name']} (👤{b['owner_id']})", f"m:{b['id']}")] for b in bots_db]
            rows.append([B("🔙 Back", "adm")])
            await show(update, context, f"🖥 <b>All Hosted Bots</b> ({len(bots_db)})", KB(rows))
        elif data == "adm_sites":
            sites_db = dball("SELECT * FROM websites ORDER BY id DESC LIMIT 40")
            rows = [[B(f"🌐 #{s['id']} {s['name']} (👤{s['owner_id']})", url=f"{WEB_APP_URL}/sites/{s['slug']}/")] for s in sites_db]
            rows.append([B("🔙 Back", "adm")])
            await show(update, context, f"🌐 <b>All Hosted Websites</b> ({len(sites_db)})", KB(rows))
        elif data in ("adm_ban", "adm_unban"):
            context.user_data["state"] = "ban" if data == "adm_ban" else "unban"
            await show(update, context, f"Send User ID to {'ban 🚫' if data == 'adm_ban' else 'unban ✅'}:", CANCEL_KB)


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    ref = None
    if context.args:
        m = re.match(r"(?:ref_)?(\d+)$", context.args[0])
        if m:
            ref = int(m.group(1))
    register_user(user, ref)
    clear_state(context)
    if not await gate(update, context):
        return
    await show_main(update, context)


async def cmd_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    clear_state(context)
    if await gate(update, context):
        await say(update, context, "✅ Action cancelled.", main_menu_kb(update.effective_user.id))


async def post_init(app: Application) -> None:
    try:
        await app.bot.set_my_commands([
            BotCommand("start", "🏠 Open main menu"),
            BotCommand("cancel", "❌ Cancel action")
        ])
    except TelegramError:
        pass
    for r in dball("SELECT id, path FROM bots WHERE ready=0"):
        shutil.rmtree(r["path"] or "", ignore_errors=True)
    dbx("DELETE FROM bots WHERE ready=0")
    for row in dball("SELECT * FROM bots WHERE ready=1 AND desired=1"):
        kill_stale(row)
        ok, m = start_process(row)
        LOG.info("Auto-start bot #%s (%s): %s", row["id"], row["name"], m)
    app.bot_data["monitor"] = asyncio.create_task(monitor_loop(app))
    me = await app.bot.get_me()
    LOG.info("✅ TeleHost online as @%s", me.username)


async def post_shutdown(app: Application) -> None:
    t = app.bot_data.get("monitor")
    if t:
        t.cancel()
    for bid in list(PROCS):
        stop_process(bid, keep_desired=True)


def main() -> None:
    if BOT_TOKEN.startswith("PASTE") or ":" not in BOT_TOKEN:
        sys.exit("❌ Set BOT_TOKEN before running.")
    db_init()
    try:
        from telegram import LinkPreviewOptions
        defaults = Defaults(parse_mode=ParseMode.HTML, link_preview_options=LinkPreviewOptions(is_disabled=True))
    except Exception:
        defaults = Defaults(parse_mode=ParseMode.HTML)
    app = (
        Application.builder()
        .token(BOT_TOKEN)
        .defaults(defaults)
        .concurrent_updates(True)
        .read_timeout(60)
        .write_timeout(60)
        .connect_timeout(30)
        .post_init(post_init)
        .post_shutdown(post_shutdown)
        .build()
    )
    private = filters.ChatType.PRIVATE
    app.add_handler(CommandHandler(["start", "menu"], cmd_start, filters=private))
    app.add_handler(CommandHandler("cancel", cmd_cancel, filters=private))
    app.add_handler(CallbackQueryHandler(on_callback))
    app.add_handler(MessageHandler(private & ~filters.COMMAND, on_message))
    LOG.info("Starting polling...")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
