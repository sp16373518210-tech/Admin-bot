import fs from 'fs';
import path from 'path';

export interface User {
  id: number;
  email: string;
  password_hash: string;
  chat_id: number;
  first_name: string;
  last_name?: string;
  tokens: number;
  referred_by?: number | null;
  ref_rewarded?: number;
  ref_earned?: number;
  verified: number;
  banned: number;
  joined_at: number;
  bot_token?: string;
}

export interface BotRecord {
  id: number;
  owner_id: number;
  name: string;
  lang: 'python' | 'node';
  entry: string;
  path: string;
  bot_token?: string;
  bot_username?: string;
  bot_title?: string;
  ready: number;
  desired: number;
  pid: number;
  started_at: number;
  created_at: number;
  code_snippet?: string;
  logs?: string[];
}

export interface WebsiteRecord {
  id: number;
  owner_id: number;
  name: string;
  slug: string;
  path: string;
  entry: string;
  created_at: number;
  files_count?: number;
}

export interface CouponRecord {
  code: string;
  tokens: number;
  max_uses: number;
  used: number;
  created_at: number;
}

export interface CouponUse {
  code: string;
  user_id: number;
  ts: number;
}

export interface PasswordReset {
  email: string;
  chat_id: number;
  code: string;
  expires_at: number;
}

export interface DBData {
  users: User[];
  bots: BotRecord[];
  websites: WebsiteRecord[];
  coupons: CouponRecord[];
  coupon_uses: CouponUse[];
  password_resets: PasswordReset[];
  settings: Record<string, string>;
}

const DATA_DIR = path.resolve(process.cwd(), 'hosting_data');
const DB_PATH = path.join(DATA_DIR, 'cloud_db.json');

// Ensure directories exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
['bots', 'websites', 'logs', 'tmp'].forEach((sub) => {
  const p = path.join(DATA_DIR, sub);
  if (!fs.existsSync(p)) {
    fs.mkdirSync(p, { recursive: true });
  }
});

const ADMIN_EMAIL = 'sp16373518210@gmail.com';
const ADMIN_CHAT_ID = 5960319648;
export const DEFAULT_BOT_TOKEN = '8604012968:AAHmJuX581_U-0wWazD2hKCPFiLC1ayN7sg';

function getInitialData(): DBData {
  return {
    users: [
      {
        id: ADMIN_CHAT_ID,
        email: ADMIN_EMAIL,
        password_hash: '5960319648', // Admin password matches chat_id per user instructions
        chat_id: ADMIN_CHAT_ID,
        first_name: 'Admin',
        last_name: 'Owner',
        tokens: 999999, // Unlimited tokens for admin
        verified: 1,
        banned: 0,
        joined_at: Math.floor(Date.now() / 1000),
      },
    ],
    bots: [
      {
        id: 101,
        owner_id: ADMIN_CHAT_ID,
        name: 'TeleHost Official Bot',
        lang: 'python',
        entry: 'bot.py',
        path: path.join(DATA_DIR, 'bots', `${ADMIN_CHAT_ID}`, '101'),
        bot_token: '8604012968:AAHmJuX581_U-0wWazD2hKCPFiLC1ayN7sg',
        bot_username: 'telehost_master_bot',
        bot_title: 'TeleHost Master Bot',
        ready: 1,
        desired: 1,
        pid: 4321,
        started_at: Math.floor(Date.now() / 1000) - 3600,
        created_at: Math.floor(Date.now() / 1000) - 86400,
        code_snippet: 'import telebot\n\nbot = telebot.TeleBot("...")\n@bot.message_handler(commands=["start"])\ndef send_welcome(m):\n    bot.reply_to(m, "Hello from TeleHost 3D!")\n\nbot.infinity_polling()',
        logs: [
          '=== PANEL START 2026-10-17 12:00:00 | python bot.py ===',
          '[panel] auto-installing detected imports: pyTelegramBotAPI',
          '[panel] dependencies up to date',
          '2026-10-17 12:00:05 | INFO | Bot @tele_demo_bot started successfully and listening...',
          '2026-10-17 12:15:30 | INFO | Message received from user 5960319648: /start',
          '2026-10-17 12:15:31 | INFO | Replied to 5960319648 with welcome card',
        ],
      },
    ],
    websites: [
      {
        id: 1,
        owner_id: ADMIN_CHAT_ID,
        name: 'Glass Cyber Showcase',
        slug: 'glass-demo',
        path: path.join(DATA_DIR, 'websites', 'glass-demo'),
        entry: 'index.html',
        created_at: Math.floor(Date.now() / 1000) - 7200,
        files_count: 3,
      },
    ],
    coupons: [
      {
        code: 'WELCOME5',
        tokens: 5,
        max_uses: 100,
        used: 8,
        created_at: Math.floor(Date.now() / 1000) - 86400,
      },
      {
        code: 'TELEHOST2026',
        tokens: 3,
        max_uses: 50,
        used: 12,
        created_at: Math.floor(Date.now() / 1000) - 43200,
      },
    ],
    coupon_uses: [],
    password_resets: [],
    settings: {
      ref_reward: '1',
      free_tokens: '1',
      force_channel: '-1003982704519',
      force_link: 'https://t.me/modapkpro02',
    },
  };
}

class Store {
  private data: DBData;

  constructor() {
    this.data = this.load();
    this.ensureSampleWebsite();
  }

  private load(): DBData {
    try {
      if (fs.existsSync(DB_PATH)) {
        const raw = fs.readFileSync(DB_PATH, 'utf-8');
        const parsed = JSON.parse(raw);
        // Ensure admin user exists with requested email
        const adminExists = parsed.users?.some((u: User) => u.email.toLowerCase() === ADMIN_EMAIL.toLowerCase());
        if (!adminExists) {
          parsed.users = parsed.users || [];
          parsed.users.unshift(getInitialData().users[0]);
        }
        return {
          users: parsed.users || [],
          bots: parsed.bots || [],
          websites: parsed.websites || [],
          coupons: parsed.coupons || [],
          coupon_uses: parsed.coupon_uses || [],
          password_resets: parsed.password_resets || [],
          settings: parsed.settings || getInitialData().settings,
        };
      }
    } catch (e) {
      console.error('Error loading DB from disk:', e);
    }
    const init = getInitialData();
    this.saveData(init);
    return init;
  }

  private ensureSampleWebsite() {
    const siteDir = path.join(DATA_DIR, 'websites', 'glass-demo');
    if (!fs.existsSync(siteDir)) {
      fs.mkdirSync(siteDir, { recursive: true });
      const sampleHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Live Web Showcase - TeleHost</title>
  <style>
    body {
      margin: 0;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      background: radial-gradient(circle at 50% 20%, #1e1b4b, #0f172a 80%);
      color: #f8fafc;
      font-family: system-ui, sans-serif;
      text-align: center;
      padding: 20px;
    }
    .card {
      background: rgba(255, 255, 255, 0.08);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 24px;
      padding: 40px;
      max-width: 500px;
      box-shadow: 0 20px 50px rgba(0,0,0,0.5);
    }
    h1 {
      font-size: 2.2rem;
      margin-bottom: 10px;
      background: linear-gradient(135deg, #38bdf8, #818cf8, #c084fc);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    p { color: #94a3b8; font-size: 1.1rem; line-height: 1.6; }
    .badge {
      display: inline-block;
      padding: 6px 14px;
      background: rgba(16, 185, 129, 0.2);
      border: 1px solid rgba(16, 185, 129, 0.4);
      color: #34d399;
      border-radius: 9999px;
      font-weight: 600;
      font-size: 0.9rem;
      margin-bottom: 16px;
    }
    .pulse {
      display: inline-block;
      width: 8px;
      height: 8px;
      background: #10b981;
      border-radius: 50%;
      margin-right: 6px;
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="badge"><span class="pulse"></span> 24/7 Live Online</div>
    <h1>TeleHost 3D Website</h1>
    <p>This is a live static website hosted directly through TeleHost 3D. You can upload any HTML or ZIP website file!</p>
  </div>
</body>
</html>`;
      fs.writeFileSync(path.join(siteDir, 'index.html'), sampleHtml, 'utf-8');
    }
  }

  private saveData(data: DBData) {
    try {
      fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf-8');
    } catch (e) {
      console.error('Failed to write db to disk:', e);
    }
  }

  public getSnapshot(): DBData {
    return this.data;
  }

  public update(updater: (data: DBData) => void) {
    updater(this.data);
    this.saveData(this.data);
  }

  public isAdmin(emailOrId: string | number): boolean {
    if (typeof emailOrId === 'string' && emailOrId.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
      return true;
    }
    if (typeof emailOrId === 'number' && emailOrId === ADMIN_CHAT_ID) {
      return true;
    }
    const u = this.data.users.find(
      (user) => user.email.toLowerCase() === String(emailOrId).toLowerCase() || user.chat_id === Number(emailOrId)
    );
    if (u && (u.email.toLowerCase() === ADMIN_EMAIL.toLowerCase() || u.chat_id === ADMIN_CHAT_ID)) {
      return true;
    }
    return false;
  }
}

export const db = new Store();
export { ADMIN_EMAIL, ADMIN_CHAT_ID, DATA_DIR };
