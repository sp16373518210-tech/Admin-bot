/**
 * Pure helper rules and validations for TeleHost
 */

export function sanitizeSlug(input: string): string {
  return input
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 30);
}

export function generateCouponCode(prefix = 'HOST'): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let out = '';
  for (let i = 0; i < 6; i++) {
    out += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `${prefix}-${out}`;
}

export function isValidTelegramToken(token: string): boolean {
  if (!token) return false;
  return /^\d{8,11}:[A-Za-z0-9_-]{34,38}$/.test(token.trim());
}

export function checkIsAdmin(email?: string, chatId?: number | string): boolean {
  const adminEmail = 'sp16373518210@gmail.com';
  const adminChatId = 5960319648;
  if (email && email.trim().toLowerCase() === adminEmail.toLowerCase()) {
    return true;
  }
  if (chatId && Number(chatId) === adminChatId) {
    return true;
  }
  return false;
}

export function calculateNewTokenBalance(currentTokens: number, delta: number, isUnlimited = false): number {
  if (isUnlimited) return 9999;
  return Math.max(0, currentTokens + delta);
}

export function isCodeExpired(expiresAt: number, nowSeconds = Math.floor(Date.now() / 1000)): boolean {
  return nowSeconds > expiresAt;
}

export function calculateAverageUptime(bots: Array<{ uptimePercentage: number; status: string }>): number {
  if (!bots || bots.length === 0) return 100;
  const running = bots.filter((b) => b.status === 'healthy');
  if (running.length === 0) return 0;
  const sum = running.reduce((acc, b) => acc + b.uptimePercentage, 0);
  return +(sum / bots.length).toFixed(2);
}

export function getHealthBadgeStatus(uptimePercentage: number, isRunning: boolean): { label: string; color: string } {
  if (!isRunning) return { label: 'STOPPED', color: 'rose' };
  if (uptimePercentage >= 99.5) return { label: 'EXCELLENT', color: 'emerald' };
  if (uptimePercentage >= 98.0) return { label: 'DEGRADED', color: 'amber' };
  return { label: 'CRITICAL', color: 'rose' };
}
