import test from 'node:test';
import assert from 'node:assert/strict';
import {
  sanitizeSlug,
  generateCouponCode,
  isValidTelegramToken,
  checkIsAdmin,
  calculateNewTokenBalance,
  isCodeExpired,
  calculateAverageUptime,
  getHealthBadgeStatus,
} from './rules.ts';

test('sanitizeSlug creates URL-friendly slugs', () => {
  assert.equal(sanitizeSlug('My Awesome Website!'), 'my-awesome-website');
  assert.equal(sanitizeSlug('3D Glass --- Showcase 2026'), '3d-glass-showcase-2026');
  assert.equal(sanitizeSlug(''), '');
});

test('generateCouponCode produces valid coupon codes', () => {
  const code = generateCouponCode('VIP');
  assert.equal(code.startsWith('VIP-'), true);
  assert.equal(code.length, 10);
});

test('isValidTelegramToken verifies standard Telegram bot tokens', () => {
  assert.equal(isValidTelegramToken('8604012968:AAG1tZe1ZbXhgRUyqWqNe03uQbnf-Ug-hS0'), true);
  assert.equal(isValidTelegramToken('invalid-token'), false);
  assert.equal(isValidTelegramToken(''), false);
});

test('checkIsAdmin correctly identifies super-admin', () => {
  assert.equal(checkIsAdmin('sp16373518210@gmail.com'), true);
  assert.equal(checkIsAdmin('SP16373518210@GMAIL.COM'), true);
  assert.equal(checkIsAdmin('other@gmail.com', 5960319648), true);
  assert.equal(checkIsAdmin('regular@user.com', 123456789), false);
});

test('calculateNewTokenBalance accurately calculates tokens', () => {
  assert.equal(calculateNewTokenBalance(3, -1), 2);
  assert.equal(calculateNewTokenBalance(0, -1), 0);
  assert.equal(calculateNewTokenBalance(2, 5), 7);
  assert.equal(calculateNewTokenBalance(1, -1, true), 9999);
});

test('isCodeExpired checks expiration timestamps', () => {
  const now = 1000;
  assert.equal(isCodeExpired(999, now), true);
  assert.equal(isCodeExpired(1001, now), false);
});

test('calculateAverageUptime correctly computes aggregate uptime', () => {
  assert.equal(calculateAverageUptime([]), 100);
  assert.equal(calculateAverageUptime([{ uptimePercentage: 99.8, status: 'healthy' }]), 99.8);
  assert.equal(
    calculateAverageUptime([
      { uptimePercentage: 99.8, status: 'healthy' },
      { uptimePercentage: 0, status: 'stopped' },
    ]),
    49.9
  );
  assert.equal(calculateAverageUptime([{ uptimePercentage: 0, status: 'stopped' }]), 0);
});

test('getHealthBadgeStatus returns appropriate badge category', () => {
  assert.equal(getHealthBadgeStatus(99.9, true).label, 'EXCELLENT');
  assert.equal(getHealthBadgeStatus(98.5, true).label, 'DEGRADED');
  assert.equal(getHealthBadgeStatus(95.0, true).label, 'CRITICAL');
  assert.equal(getHealthBadgeStatus(99.9, false).label, 'STOPPED');
});
