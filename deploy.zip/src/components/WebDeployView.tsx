import React, { useState } from 'react';
import { User, WebsiteRecord, ViewType } from '../types.ts';
import {
  Globe,
  Upload,
  ExternalLink,
  Share2,
  Copy,
  Check,
  AlertCircle,
  Loader2,
  FileCode,
  Eye,
  CheckCircle2,
} from 'lucide-react';

interface WebDeployViewProps {
  user: User | null;
  onDeploySuccess: (site: WebsiteRecord) => void;
  setCurrentView: (view: ViewType) => void;
  onOpenAuth: () => void;
}

export const WebDeployView: React.FC<WebDeployViewProps> = ({
  user,
  onDeploySuccess,
  setCurrentView,
  onOpenAuth,
}) => {
  const [siteName, setSiteName] = useState('');
  const [slugInput, setSlugInput] = useState('');
  const [uploadType, setUploadType] = useState<'html' | 'zip'>('html');
  const [htmlCode, setHtmlCode] = useState(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My 3D Glass Website</title>
  <style>
    body {
      margin: 0;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background: radial-gradient(circle at 50% 30%, #0f172a, #020617);
      color: #f8fafc;
      font-family: system-ui, sans-serif;
      text-align: center;
      padding: 20px;
    }
    .card {
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(16px);
      border-radius: 24px;
      padding: 40px;
      max-width: 480px;
      box-shadow: 0 20px 40px rgba(0,0,0,0.5);
    }
    h1 {
      background: linear-gradient(135deg, #38bdf8, #818cf8);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      margin-bottom: 12px;
    }
    p { color: #94a3b8; line-height: 1.6; }
    .badge {
      display: inline-block;
      padding: 4px 12px;
      background: rgba(56, 189, 248, 0.15);
      color: #38bdf8;
      border-radius: 999px;
      font-size: 12px;
      font-weight: bold;
      margin-bottom: 15px;
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="badge">🚀 Hosted Online 24/7</div>
    <h1>Welcome to My Website</h1>
    <p>This static website was hosted instantly using TeleHost 3D Web Hosting!</p>
  </div>
</body>
</html>`);

  const [zipBase64, setZipBase64] = useState<string | null>(null);
  const [zipName, setZipName] = useState('');
  const [deploying, setDeploying] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Result popup modal
  const [deployedSite, setDeployedSite] = useState<WebsiteRecord | null>(null);
  const [copied, setCopied] = useState(false);

  const handleZipUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setZipName(file.name);
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const res = reader.result as string;
      setZipBase64(res.split(',')[1]);
    };
  };

  const handleHtmlFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.readAsText(file);
    reader.onload = () => {
      setHtmlCode(reader.result as string);
    };
  };

  const handleDeploy = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      onOpenAuth();
      return;
    }

    if (!user.is_admin && user.tokens < 1) {
      setError('Not enough tokens! You need 1 token to deploy. Please claim a coupon.');
      return;
    }

    setError(null);
    setDeploying(true);

    try {
      const payload: any = {
        user_id: user.id,
        name: siteName,
        slug_input: slugInput,
      };

      if (uploadType === 'zip' && zipBase64) {
        payload.zip_base64 = zipBase64;
      } else {
        payload.html_content = htmlCode;
      }

      const res = await fetch('/api/websites/deploy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Website deployment failed.');
      }

      setDeployedSite(data.website);
      onDeploySuccess(data.website);
    } catch (err: any) {
      setError(err.message || 'Failed to deploy website.');
    } finally {
      setDeploying(false);
    }
  };

  const copyUrl = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const liveUrl = deployedSite ? `${window.location.origin}/sites/${deployedSite.slug}/` : '';

  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-fadeIn">
      {/* Title Card */}
      <div className="liquid-glass rounded-3xl p-6 sm:p-8 border border-white/15">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center text-white shadow-lg shadow-emerald-500/25">
            <Globe className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-white">Deploy Website Online</h1>
            <p className="text-xs text-slate-400">
              Host static HTML websites or ZIP archives 24/7 with instant live preview and shareable link.
            </p>
          </div>
        </div>

        <div className="mt-4 p-3 rounded-2xl bg-white/[0.03] border border-white/10 flex items-center justify-between text-xs">
          <span className="text-slate-300">
            Deployment Cost: <b className="text-amber-300">1 🪙 Token</b>
          </span>
          <span className="text-slate-400">
            Your Balance:{' '}
            <b className="text-amber-300">{user?.is_admin ? 'Unlimited' : user ? user.tokens : 1}</b>
          </span>
        </div>
      </div>

      {/* Main Deploy Form */}
      <form onSubmit={handleDeploy} className="liquid-glass rounded-3xl p-6 sm:p-8 border border-white/15 space-y-6">
        {error && (
          <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/30 flex items-start gap-3 text-xs text-red-300">
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-red-400" />
            <div>
              <p className="font-bold">Error</p>
              <p>{error}</p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Website Name / Title <span className="text-emerald-400">*</span>
            </label>
            <input
              type="text"
              required
              value={siteName}
              onChange={(e) => setSiteName(e.target.value)}
              placeholder="e.g. My Portfolio"
              className="w-full px-4 py-2.5 rounded-xl text-sm text-white liquid-glass-input placeholder-slate-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Custom Slug / Subpath <span className="text-slate-400 font-normal">(Optional)</span>
            </label>
            <input
              type="text"
              value={slugInput}
              onChange={(e) => setSlugInput(e.target.value)}
              placeholder="e.g. portfolio"
              className="w-full px-4 py-2.5 rounded-xl text-sm text-white liquid-glass-input placeholder-slate-500 font-mono text-xs"
            />
          </div>
        </div>

        {/* Upload Mode Selector */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-semibold text-slate-300">Website Content Source</label>
            <div className="flex items-center p-1 rounded-xl bg-white/5 border border-white/10 text-xs">
              <button
                type="button"
                onClick={() => setUploadType('html')}
                className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                  uploadType === 'html' ? 'bg-emerald-500/30 text-emerald-300' : 'text-slate-400'
                }`}
              >
                HTML Code Editor / File
              </button>
              <button
                type="button"
                onClick={() => setUploadType('zip')}
                className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                  uploadType === 'zip' ? 'bg-emerald-500/30 text-emerald-300' : 'text-slate-400'
                }`}
              >
                Upload ZIP Archive
              </button>
            </div>
          </div>

          {uploadType === 'html' ? (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">Entry file: <code>index.html</code></span>
                <label className="px-3 py-1 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-slate-300 cursor-pointer flex items-center gap-1.5">
                  <Upload className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Import .html File</span>
                  <input type="file" accept=".html,.htm" onChange={handleHtmlFileUpload} className="hidden" />
                </label>
              </div>

              <textarea
                rows={11}
                value={htmlCode}
                onChange={(e) => setHtmlCode(e.target.value)}
                className="w-full p-4 rounded-2xl font-mono text-xs text-emerald-100 bg-black/40 border border-white/15 focus:border-emerald-400 focus:outline-none"
              />
            </div>
          ) : (
            <div className="p-8 rounded-2xl border-2 border-dashed border-white/20 bg-white/[0.02] text-center hover:border-emerald-400/50 transition-colors">
              <input
                type="file"
                id="site-zip"
                accept=".zip"
                onChange={handleZipUpload}
                className="hidden"
              />
              <label htmlFor="site-zip" className="cursor-pointer block">
                <Upload className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                <p className="text-sm font-bold text-white mb-1">
                  {zipName ? `Selected: ${zipName}` : 'Choose .ZIP Website Archive'}
                </p>
                <p className="text-xs text-slate-400">
                  Include <code>index.html</code> inside the ZIP root or subfolder with your CSS, JS, and assets.
                </p>
              </label>
            </div>
          )}
        </div>

        {/* Submit */}
        <button
          type="submit"
          disabled={deploying}
          className="w-full py-3.5 rounded-2xl text-sm font-bold text-white bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:opacity-95 shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 cursor-pointer transition-all"
        >
          {deploying ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Publishing Website Online...</span>
            </>
          ) : (
            <>
              <Globe className="w-4 h-4" />
              <span>🌐 Publish Website Live 24/7</span>
            </>
          )}
        </button>
      </form>

      {/* Deployed Success Modal / Card */}
      {deployedSite && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            onClick={() => setDeployedSite(null)}
            className="fixed inset-0 bg-black/70 backdrop-blur-md"
          />
          <div className="relative w-full max-w-lg liquid-glass border border-white/20 rounded-3xl p-6 sm:p-8 z-10 animate-scaleUp">
            <div className="text-center mb-6">
              <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mx-auto mb-3">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h2 className="text-2xl font-extrabold text-white">Website Live Online!</h2>
              <p className="text-xs text-slate-300 mt-1">
                Your static website is hosted and accessible across the internet.
              </p>
            </div>

            {/* Live URL box */}
            <div className="p-4 rounded-2xl bg-black/40 border border-white/10 mb-6">
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                Live Website URL:
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={liveUrl}
                  className="w-full px-3 py-2 rounded-xl text-xs font-mono text-emerald-300 bg-white/5 border border-white/10"
                />
                <button
                  onClick={() => copyUrl(liveUrl)}
                  className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold flex items-center gap-1.5 transition-colors flex-shrink-0 cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>

            {/* Live Actions */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              <a
                href={liveUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="py-2.5 rounded-xl text-xs font-bold text-white liquid-btn-primary flex items-center justify-center gap-1.5"
              >
                <Eye className="w-4 h-4" />
                <span>Live Preview</span>
              </a>

              <a
                href={`https://t.me/share/url?url=${encodeURIComponent(liveUrl)}&text=${encodeURIComponent(
                  `Check out my website on TeleHost 3D: ${deployedSite.name}`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="py-2.5 rounded-xl text-xs font-bold text-white bg-blue-500/20 hover:bg-blue-500/30 border border-blue-500/30 flex items-center justify-center gap-1.5 transition-colors"
              >
                <Share2 className="w-4 h-4 text-blue-400" />
                <span>Share Link</span>
              </a>
            </div>

            <button
              onClick={() => {
                setDeployedSite(null);
                setCurrentView('manage_web');
              }}
              className="w-full py-2.5 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 transition-colors"
            >
              Go to My Websites Manager
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
