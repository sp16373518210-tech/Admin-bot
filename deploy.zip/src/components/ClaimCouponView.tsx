import React, { useState } from 'react';
import { User, ViewType } from '../types.ts';
import confetti from 'canvas-confetti';
import {
  Sparkles,
  Ticket,
  CheckCircle2,
  AlertCircle,
  Coins,
  Send,
  ExternalLink,
  Gift,
} from 'lucide-react';

interface ClaimCouponViewProps {
  user: User | null;
  onTokenUpdate: (newTokens: number) => void;
  setCurrentView: (view: ViewType) => void;
  onOpenAuth: () => void;
}

export const ClaimCouponView: React.FC<ClaimCouponViewProps> = ({
  user,
  onTokenUpdate,
  setCurrentView,
  onOpenAuth,
}) => {
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleRedeem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      onOpenAuth();
      return;
    }

    if (!code.trim()) return;

    setError(null);
    setMessage(null);
    setLoading(true);

    try {
      const res = await fetch('/api/coupons/redeem', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: user.id, code }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to redeem coupon.');
      }

      setMessage(data.message);
      onTokenUpdate(data.balance);
      setCode('');

      // Confetti burst
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });
    } catch (err: any) {
      setError(err.message || 'Redemption failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-xl mx-auto space-y-8 animate-fadeIn">
      {/* Title Card */}
      <div className="liquid-glass rounded-3xl p-6 sm:p-8 border border-white/15 text-center">
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-400 via-orange-500 to-yellow-500 flex items-center justify-center text-white mx-auto shadow-xl shadow-amber-500/25 mb-4">
          <Gift className="w-7 h-7" />
        </div>

        <h1 className="text-2xl sm:text-3xl font-extrabold text-white mb-2">
          Claim Coupon Code
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 max-w-md mx-auto">
          Enter an admin-generated coupon code below to unlock additional hosting tokens for your bots & websites.
        </p>

        {/* User Balance Chip */}
        <div className="mt-5 inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-500/10 border border-amber-400/30 text-amber-300 text-sm font-bold">
          <span>🪙 Current Balance:</span>
          <span className="text-base text-amber-200">
            {user?.is_admin ? 'Unlimited' : user ? user.tokens : 1}
          </span>
          <span className="text-xs text-amber-400/80 font-normal">Tokens</span>
        </div>
      </div>

      {/* Redemption Form */}
      <form onSubmit={handleRedeem} className="liquid-glass rounded-3xl p-6 sm:p-8 border border-white/15 space-y-5">
        {error && (
          <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/30 flex items-start gap-3 text-xs text-red-300">
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-red-400" />
            <div>
              <p className="font-bold">Invalid Coupon</p>
              <p>{error}</p>
            </div>
          </div>
        )}

        {message && (
          <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-start gap-3 text-xs text-emerald-300 animate-fadeIn">
            <CheckCircle2 className="w-5 h-5 flex-shrink-0 mt-0.5 text-emerald-400" />
            <div>
              <p className="font-bold">Tokens Added!</p>
              <p>{message}</p>
            </div>
          </div>
        )}

        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-2">
            Enter Coupon Code
          </label>
          <div className="relative">
            <input
              type="text"
              required
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder="e.g. WELCOME5 or HOST-XXXX"
              className="w-full px-4 py-3 pl-11 rounded-2xl text-base font-mono font-bold tracking-wider text-amber-300 liquid-glass-input placeholder-slate-500 uppercase"
            />
            <Ticket className="w-5 h-5 text-amber-400 absolute left-3.5 top-3.5" />
          </div>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full py-3.5 rounded-2xl text-sm font-bold text-white bg-gradient-to-r from-amber-500 via-orange-500 to-yellow-500 hover:opacity-95 shadow-lg shadow-amber-500/25 flex items-center justify-center gap-2 cursor-pointer transition-all"
        >
          {loading ? (
            <span>Redeeming Code...</span>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              <span>Redeem & Add Tokens</span>
            </>
          )}
        </button>

        {/* Demo Tip */}
        <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/10 text-center">
          <p className="text-xs text-slate-400">
            Need free coupons? Try code: <button type="button" onClick={() => setCode('WELCOME5')} className="font-mono font-bold text-amber-300 underline mx-1">WELCOME5</button> or <button type="button" onClick={() => setCode('TELEHOST2026')} className="font-mono font-bold text-amber-300 underline">TELEHOST2026</button>
          </p>
        </div>
      </form>

      {/* Support / Contact Telegram Card */}
      <div className="liquid-glass rounded-3xl p-6 border border-white/15 flex items-center justify-between gap-4">
        <div>
          <h3 className="font-extrabold text-sm text-white mb-0.5">Need More Hosting Tokens?</h3>
          <p className="text-xs text-slate-400">
            Contact admin on Telegram for custom token packages and coupons.
          </p>
        </div>
        <a
          href="https://t.me/modapkpro02"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-white liquid-btn-primary flex-shrink-0"
        >
          <span>Telegram Support</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </a>
      </div>
    </div>
  );
};
