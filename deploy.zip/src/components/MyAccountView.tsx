import React, { useState } from 'react';
import { User, ViewType } from '../types.ts';
import {
  User as UserIcon,
  Mail,
  KeyRound,
  ShieldAlert,
  LogOut,
  ExternalLink,
  CheckCircle2,
  AlertCircle,
  Coins,
  Send,
  Lock,
} from 'lucide-react';

interface MyAccountViewProps {
  user: User | null;
  onLogout: () => void;
  onOpenAuth: () => void;
  setCurrentView: (view: ViewType) => void;
}

export const MyAccountView: React.FC<MyAccountViewProps> = ({
  user,
  onLogout,
  onOpenAuth,
  setCurrentView,
}) => {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  if (!user) {
    return (
      <div className="max-w-md mx-auto text-center liquid-glass rounded-3xl p-10 border border-white/15">
        <UserIcon className="w-12 h-12 text-slate-500 mx-auto mb-3" />
        <h2 className="text-xl font-bold text-white mb-2">Account Not Signed In</h2>
        <p className="text-xs text-slate-400 mb-6">
          Sign in or create an account to view your profile details and change password.
        </p>
        <button onClick={onOpenAuth} className="px-6 py-2.5 rounded-xl text-xs font-bold text-white liquid-btn-primary">
          Login / Sign Up
        </button>
      </div>
    );
  }

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    setMsg(null);

    if (newPassword !== confirmPassword) {
      setErr('New passwords do not match.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/auth/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: user.id,
          current_password: currentPassword,
          new_password: newPassword,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to update password.');
      }

      setMsg('🎉 Password updated successfully!');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (e: any) {
      setErr(e.message || 'Could not change password.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-fadeIn">
      {/* Title Card */}
      <div className="liquid-glass rounded-3xl p-6 sm:p-8 border border-white/15 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-3xl bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-white text-xl font-extrabold shadow-xl shadow-cyan-500/25">
            {user.first_name ? user.first_name[0].toUpperCase() : 'U'}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-extrabold text-white">
                {user.first_name} {user.last_name || ''}
              </h1>
              {user.is_admin && (
                <span className="text-[10px] font-extrabold px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/40">
                  ADMINISTRATOR
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400 font-medium">{user.email}</p>
          </div>
        </div>

        <button
          onClick={onLogout}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold text-red-400 hover:text-red-300 bg-red-500/10 hover:bg-red-500/20 border border-red-500/25 transition-all cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          <span>Logout</span>
        </button>
      </div>

      {/* Account Info Details */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="liquid-glass-card rounded-2xl p-5 border border-white/10">
          <span className="text-xs text-slate-400 block mb-1">Registered Email</span>
          <div className="flex items-center gap-2">
            <Mail className="w-4 h-4 text-cyan-400 flex-shrink-0" />
            <span className="text-xs sm:text-sm font-bold text-white truncate block">
              {user.email}
            </span>
          </div>
        </div>

        <div className="liquid-glass-card rounded-2xl p-5 border border-white/10">
          <span className="text-xs text-slate-400 block mb-1">Telegram Chat ID</span>
          <div className="flex items-center gap-2">
            <Send className="w-4 h-4 text-indigo-400 flex-shrink-0" />
            <span className="text-sm font-mono font-bold text-indigo-300">
              {user.chat_id}
            </span>
          </div>
        </div>

        <div className="liquid-glass-card rounded-2xl p-5 border border-white/10">
          <span className="text-xs text-slate-400 block mb-1">Hosting Token Balance</span>
          <div className="flex items-center gap-2">
            <span className="text-base">🪙</span>
            <span className="text-base font-extrabold text-amber-300">
              {user.is_admin ? 'Unlimited' : `${user.tokens} Tokens`}
            </span>
          </div>
        </div>
      </div>

      {/* Change Password Card */}
      <div className="liquid-glass rounded-3xl p-6 sm:p-8 border border-white/15">
        <div className="flex items-center gap-2.5 pb-4 border-b border-white/10 mb-5">
          <KeyRound className="w-5 h-5 text-cyan-400" />
          <div>
            <h2 className="text-base font-extrabold text-white">Change Password</h2>
            <p className="text-xs text-slate-400">Update your account login password.</p>
          </div>
        </div>

        {err && (
          <div className="mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center gap-2 text-xs text-red-300">
            <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
            <span>{err}</span>
          </div>
        )}

        {msg && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center gap-2 text-xs text-emerald-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>{msg}</span>
          </div>
        )}

        <form onSubmit={handleChangePassword} className="space-y-4 max-w-md">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Current Password
            </label>
            <input
              type="password"
              required
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-3.5 py-2 rounded-xl text-sm text-white liquid-glass-input"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              New Password
            </label>
            <input
              type="password"
              required
              minLength={4}
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-3.5 py-2 rounded-xl text-sm text-white liquid-glass-input"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Confirm New Password
            </label>
            <input
              type="password"
              required
              minLength={4}
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-3.5 py-2 rounded-xl text-sm text-white liquid-glass-input"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="px-5 py-2.5 rounded-xl text-xs font-bold text-white liquid-btn-primary flex items-center gap-2 cursor-pointer"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>{loading ? 'Updating Password...' : 'Save New Password'}</span>
          </button>
        </form>
      </div>

      {/* Support Card */}
      <div className="liquid-glass rounded-3xl p-6 border border-white/15 flex items-center justify-between">
        <div>
          <h3 className="font-extrabold text-sm text-white mb-0.5">Contact Support Channel</h3>
          <p className="text-xs text-slate-400">Join our Telegram channel for help, coupons, and bot updates.</p>
        </div>
        <a
          href="https://t.me/modapkpro02"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-cyan-300 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 transition-colors"
        >
          <span>Telegram</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </a>
      </div>
    </div>
  );
};
