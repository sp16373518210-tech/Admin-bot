import React, { useState } from 'react';
import { User, BotRecord, ViewType } from '../types.ts';
import {
  Bot,
  Play,
  Square,
  RotateCw,
  Terminal,
  Trash2,
  ExternalLink,
  Edit3,
  ShieldCheck,
  CheckCircle2,
  X,
  FileCode,
  Users,
  Clock,
  KeyRound,
} from 'lucide-react';

interface ManageBotsViewProps {
  user: User | null;
  bots: BotRecord[];
  onBotAction: (botId: number, action: 'start' | 'stop' | 'restart') => void;
  onDeleteBot: (botId: number) => void;
  onUpdateBot: (botId: number, data: { name?: string; entry?: string; bot_token?: string }) => void;
  setCurrentView: (view: ViewType) => void;
}

export const ManageBotsView: React.FC<ManageBotsViewProps> = ({
  user,
  bots,
  onBotAction,
  onDeleteBot,
  onUpdateBot,
  setCurrentView,
}) => {
  const [selectedLogsBot, setSelectedLogsBot] = useState<BotRecord | null>(null);
  const [botLogs, setBotLogs] = useState<string[]>([]);
  const [loadingLogs, setLoadingLogs] = useState(false);

  // Edit Token Modal State
  const [editBot, setEditBot] = useState<BotRecord | null>(null);
  const [newBotToken, setNewBotToken] = useState('');
  const [newBotName, setNewBotName] = useState('');
  const [newEntry, setNewEntry] = useState('');

  const fetchLogs = async (bot: BotRecord) => {
    setSelectedLogsBot(bot);
    setLoadingLogs(true);
    try {
      const res = await fetch(`/api/bots/${bot.id}/logs`);
      const data = await res.json();
      setBotLogs(data.logs || []);
    } catch (e) {
      setBotLogs(['Could not retrieve logs from server.']);
    } finally {
      setLoadingLogs(false);
    }
  };

  const handleOpenEdit = (bot: BotRecord) => {
    setEditBot(bot);
    setNewBotToken(bot.bot_token || '');
    setNewBotName(bot.bot_title || bot.name);
    setNewEntry(bot.entry);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editBot) return;
    onUpdateBot(editBot.id, {
      name: newBotName,
      bot_token: newBotToken,
      entry: newEntry,
    });
    setEditBot(null);
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Title */}
      <div className="liquid-glass rounded-3xl p-6 sm:p-8 border border-white/15 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/25">
              <Bot className="w-5 h-5" />
            </div>
            <h1 className="text-2xl font-extrabold text-white">Manage Telegram Bots</h1>
          </div>
          <p className="text-xs text-slate-400">
            Control, restart, monitor live console logs, and configure your running Telegram bots.
          </p>
        </div>

        <button
          onClick={() => setCurrentView('deploy_bot')}
          className="px-4 py-2.5 rounded-xl text-xs font-bold text-white liquid-btn-primary flex items-center gap-2 cursor-pointer"
        >
          <span>+ Deploy New Bot</span>
        </button>
      </div>

      {/* Bots Grid */}
      {bots.length === 0 ? (
        <div className="liquid-glass rounded-3xl p-12 text-center border border-white/10">
          <Bot className="w-16 h-16 text-slate-600 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-white mb-1">No bots hosted yet</h3>
          <p className="text-xs text-slate-400 mb-6 max-w-sm mx-auto">
            You haven't hosted any Telegram bots yet. Use your free trial token to launch one now.
          </p>
          <button
            onClick={() => setCurrentView('deploy_bot')}
            className="px-5 py-2.5 rounded-xl text-xs font-bold text-white liquid-btn-primary"
          >
            Deploy Bot Now
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {bots.map((bot) => {
            const isRunning = bot.desired === 1;
            return (
              <div
                key={bot.id}
                className="liquid-glass-card rounded-3xl p-6 border border-white/15 flex flex-col justify-between space-y-5"
              >
                <div>
                  {/* Header Row */}
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-xl">
                        {bot.lang === 'python' ? '🐍' : '🟨'}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-extrabold text-base text-white">
                            {bot.bot_title || bot.name}
                          </h3>
                        </div>
                        <span className="text-[11px] text-slate-400 font-mono">
                          ID: #{bot.id} • {bot.lang === 'python' ? 'Python' : 'Node.js'}
                        </span>
                      </div>
                    </div>

                    {/* Status Pill */}
                    <div
                      className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 ${
                        isRunning
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                          : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                      }`}
                    >
                      <span
                        className={`w-2 h-2 rounded-full ${
                          isRunning ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'
                        }`}
                      />
                      <span>{isRunning ? 'RUNNING' : 'STOPPED'}</span>
                    </div>
                  </div>

                  {/* Bot Username Link Button (as requested by user) */}
                  {bot.bot_username ? (
                    <div className="p-3 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-between mb-4">
                      <div className="min-w-0">
                        <span className="text-[11px] text-slate-400 block">Telegram Username</span>
                        <span className="text-xs font-bold text-cyan-300 font-mono truncate block">
                          @{bot.bot_username}
                        </span>
                      </div>
                      <a
                        href={`https://t.me/${bot.bot_username}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold text-white liquid-btn-primary flex-shrink-0"
                      >
                        <span>Open on Telegram</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  ) : (
                    <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/10 flex items-center justify-between text-xs text-slate-400 mb-4">
                      <span>No token username linked</span>
                      <button
                        onClick={() => handleOpenEdit(bot)}
                        className="text-cyan-400 hover:underline font-semibold"
                      >
                        + Add Token
                      </button>
                    </div>
                  )}

                  {/* Metadata Info */}
                  <div className="grid grid-cols-2 gap-2 text-xs text-slate-400">
                    <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/10">
                      <span className="text-[10px] text-slate-500 uppercase block">Entry Point</span>
                      <code className="text-slate-200 font-mono text-[11px] truncate block">
                        {bot.entry}
                      </code>
                    </div>

                    <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/10">
                      <span className="text-[10px] text-slate-500 uppercase block">PID / Users</span>
                      <span className="text-slate-200 font-semibold text-[11px] flex items-center gap-1">
                        <Users className="w-3 h-3 text-cyan-400" />
                        {isRunning ? `PID: ${bot.pid}` : 'Inactive'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Action Buttons Row */}
                <div className="pt-4 border-t border-white/10 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    {isRunning ? (
                      <button
                        onClick={() => onBotAction(bot.id, 'stop')}
                        className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-red-300 bg-red-500/15 hover:bg-red-500/30 border border-red-500/30 transition-all cursor-pointer"
                      >
                        <Square className="w-3.5 h-3.5" />
                        <span>Stop</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => onBotAction(bot.id, 'start')}
                        className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-emerald-300 bg-emerald-500/15 hover:bg-emerald-500/30 border border-emerald-500/30 transition-all cursor-pointer"
                      >
                        <Play className="w-3.5 h-3.5" />
                        <span>Start</span>
                      </button>
                    )}

                    <button
                      onClick={() => onBotAction(bot.id, 'restart')}
                      title="Restart Process"
                      className="p-2 rounded-xl text-slate-300 bg-white/5 hover:bg-white/15 border border-white/10 transition-all cursor-pointer"
                    >
                      <RotateCw className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => fetchLogs(bot)}
                      title="View Live Logs"
                      className="flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-semibold text-cyan-300 bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 transition-all cursor-pointer"
                    >
                      <Terminal className="w-3.5 h-3.5" />
                      <span>Logs</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleOpenEdit(bot)}
                      title="Edit Token & Config"
                      className="p-2 rounded-xl text-slate-300 hover:text-white bg-white/5 hover:bg-white/15 border border-white/10 transition-all cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => {
                        if (confirm(`Delete bot "${bot.name}" and refund token?`)) {
                          onDeleteBot(bot.id);
                        }
                      }}
                      title="Delete Bot"
                      className="p-2 rounded-xl text-rose-400 hover:text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/25 transition-all cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Terminal Logs Modal */}
      {selectedLogsBot && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            onClick={() => setSelectedLogsBot(null)}
            className="fixed inset-0 bg-black/75 backdrop-blur-md"
          />

          <div className="relative w-full max-w-3xl liquid-glass border border-white/20 rounded-3xl p-6 z-10 shadow-2xl animate-scaleUp">
            <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-4">
              <div className="flex items-center gap-2.5">
                <Terminal className="w-5 h-5 text-cyan-400" />
                <div>
                  <h3 className="font-extrabold text-base text-white">
                    Console Logs: {selectedLogsBot.name}
                  </h3>
                  <span className="text-[11px] text-slate-400">
                    Live process output and background auto-installation logs
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => fetchLogs(selectedLogsBot)}
                  className="px-3 py-1 rounded-xl bg-white/10 hover:bg-white/20 text-xs text-white font-semibold flex items-center gap-1"
                >
                  <RotateCw className="w-3 h-3" /> Refresh
                </button>
                <button
                  onClick={() => setSelectedLogsBot(null)}
                  className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/15 flex items-center justify-center text-slate-300 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="bg-[#050711] border border-white/10 rounded-2xl p-4 font-mono text-xs text-cyan-300 h-96 overflow-y-auto space-y-1">
              {loadingLogs ? (
                <p className="text-slate-500">Loading live logs from server...</p>
              ) : botLogs.length === 0 ? (
                <p className="text-slate-500">No log records found for this process.</p>
              ) : (
                botLogs.map((line, idx) => (
                  <div key={idx} className="whitespace-pre-wrap leading-relaxed">
                    {line}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Edit Bot Token & Config Modal */}
      {editBot && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div onClick={() => setEditBot(null)} className="fixed inset-0 bg-black/75 backdrop-blur-md" />
          <div className="relative w-full max-w-md liquid-glass border border-white/20 rounded-3xl p-6 sm:p-8 z-10 animate-scaleUp">
            <button
              onClick={() => setEditBot(null)}
              className="absolute top-5 right-5 w-8 h-8 rounded-full bg-white/5 hover:bg-white/15 flex items-center justify-center text-slate-300"
            >
              <X className="w-4 h-4" />
            </button>

            <h3 className="font-extrabold text-lg text-white mb-1">Update Bot Configuration</h3>
            <p className="text-xs text-slate-400 mb-5">Change bot token or update entry script.</p>

            <form onSubmit={handleSaveEdit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Bot Name</label>
                <input
                  type="text"
                  value={newBotName}
                  onChange={(e) => setNewBotName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl text-sm text-white liquid-glass-input"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Bot Token</label>
                <input
                  type="text"
                  value={newBotToken}
                  onChange={(e) => setNewBotToken(e.target.value)}
                  placeholder="8604012968:AAG1tZe1..."
                  className="w-full px-3.5 py-2.5 rounded-xl text-sm text-white liquid-glass-input font-mono text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Entry File</label>
                <input
                  type="text"
                  value={newEntry}
                  onChange={(e) => setNewEntry(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl text-sm text-white liquid-glass-input font-mono text-xs"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditBot(null)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold text-white liquid-btn-primary"
                >
                  Save & Apply
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
