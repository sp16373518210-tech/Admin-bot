import React from 'react';
import { User, BotRecord, WebsiteRecord, ViewType } from '../types.ts';
import { ServiceMonitor } from './ServiceMonitor.tsx';
import {
  Bot,
  Globe,
  Sparkles,
  Play,
  Square,
  RotateCw,
  ExternalLink,
  PlusCircle,
  FileText,
  ShieldCheck,
  TrendingUp,
  Cpu,
  Server,
  Layers,
} from 'lucide-react';

interface DashboardViewProps {
  user: User | null;
  bots: BotRecord[];
  websites: WebsiteRecord[];
  setCurrentView: (view: ViewType) => void;
  onBotAction: (botId: number, action: 'start' | 'stop' | 'restart') => void;
  onOpenAuth: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  user,
  bots,
  websites,
  setCurrentView,
  onBotAction,
  onOpenAuth,
}) => {
  const runningBotsCount = bots.filter((b) => b.desired === 1).length;

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Hero Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl liquid-glass p-6 sm:p-10 border border-white/15">
        {/* Glow ambient background circles */}
        <div className="absolute -right-10 -top-10 w-64 h-64 rounded-full bg-cyan-500/15 blur-3xl pointer-events-none"></div>
        <div className="absolute -left-10 -bottom-10 w-64 h-64 rounded-full bg-indigo-500/15 blur-3xl pointer-events-none"></div>

        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-semibold mb-4">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
            Cloud Hosting 24/7 Platform Online
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white mb-4 leading-tight">
            Host Telegram Bots &{' '}
            <span className="bg-gradient-to-r from-cyan-400 via-sky-300 to-indigo-300 bg-clip-text text-transparent">
              Websites in 3D Cloud
            </span>
          </h1>

          <p className="text-sm sm:text-base text-slate-300 mb-6 leading-relaxed">
            Deploy your 🐍 <b>Python</b> & 🟨 <b>Node.js</b> Telegram bots with auto-requirements installation and crash auto-fix, or host 🌐 <b>HTML/ZIP static websites</b> with instant live preview links.
          </p>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setCurrentView('deploy_bot')}
              className="flex items-center gap-2 px-5 py-3 rounded-2xl text-xs sm:text-sm font-bold text-white liquid-btn-primary cursor-pointer shadow-lg shadow-cyan-500/20"
            >
              <Bot className="w-4 h-4" />
              <span>🚀 Deploy Telegram Bot</span>
            </button>

            <button
              onClick={() => setCurrentView('deploy_web')}
              className="flex items-center gap-2 px-5 py-3 rounded-2xl text-xs sm:text-sm font-bold text-white liquid-btn-secondary cursor-pointer hover:border-emerald-500/40"
            >
              <Globe className="w-4 h-4 text-emerald-400" />
              <span>🌐 Deploy Website Online</span>
            </button>

            <button
              onClick={() => setCurrentView('claim_coupon')}
              className="flex items-center gap-2 px-4 py-3 rounded-2xl text-xs sm:text-sm font-semibold text-amber-300 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 transition-all cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Redeem Coupon</span>
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        <div className="liquid-glass-card rounded-2xl p-5 border border-white/10">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-xs font-semibold uppercase tracking-wider">Active Bots</span>
            <div className="w-8 h-8 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
              <Bot className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-white">{bots.length}</span>
            <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              {runningBotsCount} running
            </span>
          </div>
        </div>

        <div className="liquid-glass-card rounded-2xl p-5 border border-white/10">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-xs font-semibold uppercase tracking-wider">Hosted Websites</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Globe className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-white">{websites.length}</span>
            <span className="text-xs font-semibold text-cyan-400">live URLs</span>
          </div>
        </div>

        <div className="liquid-glass-card rounded-2xl p-5 border border-white/10">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-xs font-semibold uppercase tracking-wider">Available Tokens</span>
            <div className="w-8 h-8 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 text-sm">
              🪙
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-amber-300">
              {user?.is_admin ? 'Unlimited' : user ? user.tokens : 1}
            </span>
            <span className="text-xs font-semibold text-amber-400/80">slots</span>
          </div>
        </div>

        <div className="liquid-glass-card rounded-2xl p-5 border border-white/10">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-xs font-semibold uppercase tracking-wider">Server Status</span>
            <div className="w-8 h-8 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
              <Server className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-sm sm:text-base font-extrabold text-white flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
              Online 99.9%
            </span>
          </div>
        </div>
      </div>

      {/* Real-time Service Health & Uptime Monitor */}
      <ServiceMonitor userId={user?.chat_id} />

      {/* Main Grid: Your Bots & Your Websites */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Active Bots Column */}
        <div className="liquid-glass rounded-3xl p-6 border border-white/15 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div className="flex items-center gap-2">
              <Bot className="w-5 h-5 text-cyan-400" />
              <h2 className="font-extrabold text-lg text-white">Your Hosted Bots</h2>
            </div>
            <button
              onClick={() => setCurrentView('manage_bots')}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold"
            >
              View All ({bots.length}) →
            </button>
          </div>

          {bots.length === 0 ? (
            <div className="text-center py-10 px-4 rounded-2xl bg-white/[0.02] border border-dashed border-white/15">
              <Bot className="w-10 h-10 text-slate-500 mx-auto mb-2" />
              <p className="text-sm font-medium text-slate-300">No bots deployed yet</p>
              <p className="text-xs text-slate-400 mb-4">Deploy your first Python or Node.js Telegram bot in 60 seconds.</p>
              <button
                onClick={() => setCurrentView('deploy_bot')}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white liquid-btn-primary"
              >
                + Deploy New Bot
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {bots.slice(0, 3).map((bot) => (
                <div
                  key={bot.id}
                  className="p-4 rounded-2xl liquid-glass-card border border-white/10 flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-3 h-3 rounded-full flex-shrink-0 ${
                        bot.desired === 1 ? 'bg-emerald-400 animate-pulse shadow-sm shadow-emerald-400' : 'bg-rose-500'
                      }`}
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-white truncate">
                          {bot.bot_title || bot.name}
                        </span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/10 text-slate-300 uppercase font-mono">
                          {bot.lang}
                        </span>
                      </div>
                      {bot.bot_username ? (
                        <a
                          href={`https://t.me/${bot.bot_username}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs text-cyan-400 hover:underline flex items-center gap-1 mt-0.5"
                        >
                          @{bot.bot_username} <ExternalLink className="w-3 h-3" />
                        </a>
                      ) : (
                        <span className="text-xs text-slate-400">Entry: {bot.entry}</span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    {bot.desired === 1 ? (
                      <button
                        onClick={() => onBotAction(bot.id, 'stop')}
                        title="Stop Bot"
                        className="p-2 rounded-xl bg-red-500/15 hover:bg-red-500/30 text-red-400 border border-red-500/30 transition-all cursor-pointer"
                      >
                        <Square className="w-3.5 h-3.5" />
                      </button>
                    ) : (
                      <button
                        onClick={() => onBotAction(bot.id, 'start')}
                        title="Start Bot"
                        className="p-2 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/30 text-emerald-400 border border-emerald-500/30 transition-all cursor-pointer"
                      >
                        <Play className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button
                      onClick={() => onBotAction(bot.id, 'restart')}
                      title="Restart Bot"
                      className="p-2 rounded-xl bg-white/5 hover:bg-white/15 text-slate-300 border border-white/10 transition-all cursor-pointer"
                    >
                      <RotateCw className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Hosted Websites Column */}
        <div className="liquid-glass rounded-3xl p-6 border border-white/15 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div className="flex items-center gap-2">
              <Globe className="w-5 h-5 text-emerald-400" />
              <h2 className="font-extrabold text-lg text-white">Your Hosted Websites</h2>
            </div>
            <button
              onClick={() => setCurrentView('manage_web')}
              className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold"
            >
              View All ({websites.length}) →
            </button>
          </div>

          {websites.length === 0 ? (
            <div className="text-center py-10 px-4 rounded-2xl bg-white/[0.02] border border-dashed border-white/15">
              <Globe className="w-10 h-10 text-slate-500 mx-auto mb-2" />
              <p className="text-sm font-medium text-slate-300">No websites hosted yet</p>
              <p className="text-xs text-slate-400 mb-4">Upload an index.html or ZIP archive to launch online.</p>
              <button
                onClick={() => setCurrentView('deploy_web')}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white liquid-btn-primary"
              >
                + Deploy Website
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {websites.slice(0, 3).map((site) => (
                <div
                  key={site.id}
                  className="p-4 rounded-2xl liquid-glass-card border border-white/10 flex items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-white truncate">{site.name}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono">
                        ONLINE
                      </span>
                    </div>
                    <code className="text-xs text-slate-400 truncate block mt-0.5 font-mono">
                      /sites/{site.slug}/
                    </code>
                  </div>

                  <a
                    href={`/sites/${site.slug}/`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-emerald-300 bg-emerald-500/15 hover:bg-emerald-500/30 border border-emerald-500/30 transition-all flex-shrink-0"
                  >
                    <span>Preview</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
