import React, { useState, useEffect } from 'react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from 'recharts';
import {
  Activity,
  CheckCircle2,
  AlertTriangle,
  RotateCw,
  Cpu,
  Clock,
  Radio,
  Server,
  Zap,
  BarChart3,
  TrendingUp,
  HardDrive,
  Bot,
} from 'lucide-react';
import { getHealthBadgeStatus } from '../utils/rules.ts';

export interface BotHealthItem {
  id: number;
  name: string;
  lang: 'python' | 'node';
  status: 'healthy' | 'stopped';
  uptimePercentage: number;
  uptimeSeconds: number;
  pingMs: number;
  memoryMb: number;
  cpuPercent: number;
  bot_username?: string;
  history: Array<{ time: string; uptime: number; latency: number; memory: number }>;
}

export interface HealthResponse {
  bots: BotHealthItem[];
  overallUptime: number;
  avgLatency: number;
  healthyCount: number;
  totalCount: number;
  lastPolled: string;
  aggregateHistory: Array<{ time: string; uptime: number; latency: number; activeBots?: number; memory: number }>;
}

interface ServiceMonitorProps {
  userId?: number;
}

export const ServiceMonitor: React.FC<ServiceMonitorProps> = ({ userId }) => {
  const [data, setData] = useState<HealthResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [pollingActive, setPollingActive] = useState(true);
  const [pollIntervalMs, setPollIntervalMs] = useState(6000);
  const [activeMetric, setActiveMetric] = useState<'uptime' | 'latency' | 'memory'>('uptime');
  const [chartType, setChartType] = useState<'area' | 'bar'>('area');
  const [selectedBotId, setSelectedBotId] = useState<number | 'all'>('all');

  const fetchHealth = async (showLoading = false) => {
    if (showLoading) setLoading(true);
    try {
      const url = userId ? `/api/bots/health?user_id=${userId}` : '/api/bots/health';
      const res = await fetch(url);
      const json: HealthResponse = await res.json();
      setData(json);
    } catch (e) {
      console.warn('Failed to poll bot health:', e);
    } finally {
      if (showLoading) setLoading(false);
    }
  };

  useEffect(() => {
    fetchHealth(true);
    if (!pollingActive) return;
    const interval = setInterval(() => {
      fetchHealth(false);
    }, pollIntervalMs);

    return () => clearInterval(interval);
  }, [userId, pollingActive, pollIntervalMs]);

  // Determine which telemetry dataset to graph
  const selectedBot =
    selectedBotId !== 'all' && data?.bots ? data.bots.find((b) => b.id === selectedBotId) : null;

  const chartData = selectedBot
    ? selectedBot.history
    : data?.aggregateHistory || [
        { time: '00:00', uptime: 99.8, latency: 25, activeBots: 1, memory: 52 },
        { time: '04:00', uptime: 99.9, latency: 28, activeBots: 1, memory: 54 },
        { time: '08:00', uptime: 99.7, latency: 32, activeBots: 1, memory: 53 },
        { time: '12:00', uptime: 100.0, latency: 26, activeBots: 1, memory: 56 },
        { time: '16:00', uptime: 99.9, latency: 24, activeBots: 1, memory: 55 },
        { time: '20:00', uptime: 99.8, latency: 27, activeBots: 1, memory: 54 },
        { time: 'Now', uptime: 99.9, latency: 25, activeBots: 1, memory: 55 },
      ];

  // Bar chart comparison dataset across all bots
  const comparativeBotData =
    data?.bots.map((b) => ({
      name: b.name.length > 12 ? b.name.slice(0, 10) + '...' : b.name,
      uptime: b.uptimePercentage,
      latency: b.pingMs,
      memory: b.memoryMb,
    })) || [];

  const overallBadge = getHealthBadgeStatus(data?.overallUptime || 99.9, (data?.healthyCount || 0) > 0);

  return (
    <div className="liquid-glass rounded-3xl p-6 sm:p-8 border border-white/15 space-y-6 animate-fadeIn">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="relative w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-cyan-500 flex items-center justify-center text-white shadow-lg shadow-emerald-500/25">
            <Activity className="w-5 h-5 text-white" />
            {pollingActive && (
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-400 rounded-full border-2 border-[#0a0f24] animate-ping" />
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-extrabold text-white">Bot Service Monitor</h2>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 uppercase tracking-wider flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                Live Polling
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Real-time uptime status, ping latency telemetry, and process health checks.
            </p>
          </div>
        </div>

        {/* Controls */}
        <div className="flex flex-wrap items-center gap-2 self-end sm:self-auto">
          {data?.lastPolled && (
            <span className="text-[11px] text-slate-400 font-mono hidden md:inline">
              Polled: {data.lastPolled}
            </span>
          )}

          {/* Polling Interval Selector */}
          <select
            value={pollIntervalMs}
            onChange={(e) => setPollIntervalMs(Number(e.target.value))}
            className="px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-white/5 border border-white/10 text-slate-300 focus:outline-none"
          >
            <option value={3000} className="bg-slate-900 text-white">Fast (3s)</option>
            <option value={6000} className="bg-slate-900 text-white">Normal (6s)</option>
            <option value={15000} className="bg-slate-900 text-white">Eco (15s)</option>
          </select>

          <button
            onClick={() => setPollingActive(!pollingActive)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
              pollingActive
                ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300'
                : 'bg-white/5 border-white/10 text-slate-400'
            }`}
          >
            {pollingActive ? 'Live ON' : 'PAUSED'}
          </button>

          <button
            onClick={() => fetchHealth(true)}
            disabled={loading}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/15 border border-white/10 text-slate-300 hover:text-white transition-colors"
            title="Refresh Health Now"
          >
            <RotateCw className={`w-4 h-4 ${loading ? 'animate-spin text-cyan-400' : ''}`} />
          </button>
        </div>
      </div>

      {/* KPI Stats Overview Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Real-time Uptime Percentage */}
        <div className="liquid-glass-card rounded-2xl p-4 border border-white/10">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider">Overall Uptime</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl sm:text-3xl font-extrabold text-emerald-300">
              {data ? `${data.overallUptime}%` : '99.9%'}
            </span>
          </div>
          <div className="flex items-center gap-1.5 mt-1">
            <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30`}>
              {overallBadge.label}
            </span>
            <span className="text-[10px] text-slate-400">Target: 99.5%</span>
          </div>
        </div>

        {/* Avg Ping Latency */}
        <div className="liquid-glass-card rounded-2xl p-4 border border-white/10">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider">Gateway Latency</span>
            <Zap className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl sm:text-3xl font-extrabold text-cyan-300">
              {data ? `${data.avgLatency}ms` : '28ms'}
            </span>
          </div>
          <p className="text-[10px] text-cyan-400/80 mt-1">Telegram MTProto Ping</p>
        </div>

        {/* Healthy Bots Ratio */}
        <div className="liquid-glass-card rounded-2xl p-4 border border-white/10">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider">Health Status</span>
            <Radio className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl sm:text-3xl font-extrabold text-white">
              {data ? `${data.healthyCount}/${data.totalCount}` : '1/1'}
            </span>
            <span className="text-xs text-slate-400">Online</span>
          </div>
          <p className="text-[10px] text-slate-400 mt-1">Active process supervisor</p>
        </div>

        {/* Server Node Status */}
        <div className="liquid-glass-card rounded-2xl p-4 border border-white/10">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider">Cluster Node</span>
            <Server className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-sm font-extrabold text-indigo-300 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              Node-Asia-01
            </span>
          </div>
          <p className="text-[10px] text-slate-400 mt-1">Crash Auto-Restart Ready</p>
        </div>
      </div>

      {/* Real-time Uptime Percentage Chart (Recharts) */}
      <div className="p-5 rounded-2xl bg-black/40 border border-white/10 space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-sm text-white">
                {selectedBot ? `Bot Telemetry: ${selectedBot.name}` : 'Real-Time Telemetry Trend'}
              </h3>
              {selectedBot && (
                <button
                  onClick={() => setSelectedBotId('all')}
                  className="text-[10px] text-cyan-400 hover:underline cursor-pointer"
                >
                  (Back to Aggregate)
                </button>
              )}
            </div>
            <p className="text-xs text-slate-400">
              {activeMetric === 'uptime'
                ? 'Real-time Uptime Percentage (%)'
                : activeMetric === 'latency'
                ? 'Gateway Latency (ms)'
                : 'Resident Memory Usage (MB)'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Metric Selector */}
            <div className="flex items-center p-1 rounded-xl bg-white/5 border border-white/10 text-xs">
              <button
                type="button"
                onClick={() => setActiveMetric('uptime')}
                className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                  activeMetric === 'uptime' ? 'bg-emerald-500/30 text-emerald-300' : 'text-slate-400'
                }`}
              >
                Uptime %
              </button>
              <button
                type="button"
                onClick={() => setActiveMetric('latency')}
                className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                  activeMetric === 'latency' ? 'bg-cyan-500/30 text-cyan-300' : 'text-slate-400'
                }`}
              >
                Latency
              </button>
              <button
                type="button"
                onClick={() => setActiveMetric('memory')}
                className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                  activeMetric === 'memory' ? 'bg-indigo-500/30 text-indigo-300' : 'text-slate-400'
                }`}
              >
                Memory
              </button>
            </div>

            {/* Chart Type Toggle */}
            <div className="flex items-center p-1 rounded-xl bg-white/5 border border-white/10 text-xs">
              <button
                type="button"
                onClick={() => setChartType('area')}
                title="Area Chart Timeline"
                className={`p-1.5 rounded-lg transition-all ${
                  chartType === 'area' ? 'bg-white/15 text-white' : 'text-slate-400'
                }`}
              >
                <TrendingUp className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setChartType('bar')}
                title="Bar Chart Comparison"
                className={`p-1.5 rounded-lg transition-all ${
                  chartType === 'bar' ? 'bg-white/15 text-white' : 'text-slate-400'
                }`}
              >
                <BarChart3 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Recharts Chart Viewport */}
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            {chartType === 'area' ? (
              <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="uptimeGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="latencyGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="memoryGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#818cf8" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#818cf8" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
                <XAxis dataKey="time" stroke="#64748b" tick={{ fontSize: 11 }} />
                <YAxis
                  domain={
                    activeMetric === 'uptime'
                      ? [98.5, 100]
                      : activeMetric === 'latency'
                      ? [0, 60]
                      : [40, 90]
                  }
                  stroke="#64748b"
                  tick={{ fontSize: 11 }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(10, 15, 30, 0.95)',
                    borderColor: 'rgba(255, 255, 255, 0.15)',
                    borderRadius: '12px',
                    boxShadow: '0 10px 25px rgba(0,0,0,0.5)',
                    fontSize: '12px',
                  }}
                  labelStyle={{ color: '#94a3b8' }}
                />
                {activeMetric === 'uptime' && (
                  <Area
                    type="monotone"
                    dataKey="uptime"
                    name="Uptime %"
                    stroke="#10b981"
                    strokeWidth={2.5}
                    fillOpacity={1}
                    fill="url(#uptimeGrad)"
                  />
                )}
                {activeMetric === 'latency' && (
                  <Area
                    type="monotone"
                    dataKey="latency"
                    name="Latency (ms)"
                    stroke="#06b6d4"
                    strokeWidth={2.5}
                    fillOpacity={1}
                    fill="url(#latencyGrad)"
                  />
                )}
                {activeMetric === 'memory' && (
                  <Area
                    type="monotone"
                    dataKey="memory"
                    name="Memory (MB)"
                    stroke="#818cf8"
                    strokeWidth={2.5}
                    fillOpacity={1}
                    fill="url(#memoryGrad)"
                  />
                )}
              </AreaChart>
            ) : (
              <BarChart data={comparativeBotData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
                <XAxis dataKey="name" stroke="#64748b" tick={{ fontSize: 11 }} />
                <YAxis
                  domain={activeMetric === 'uptime' ? [90, 100] : [0, 60]}
                  stroke="#64748b"
                  tick={{ fontSize: 11 }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(10, 15, 30, 0.95)',
                    borderColor: 'rgba(255, 255, 255, 0.15)',
                    borderRadius: '12px',
                    fontSize: '12px',
                  }}
                  labelStyle={{ color: '#94a3b8' }}
                />
                <Bar
                  dataKey={activeMetric}
                  name={activeMetric === 'uptime' ? 'Uptime %' : activeMetric === 'latency' ? 'Latency (ms)' : 'Memory (MB)'}
                  fill={activeMetric === 'uptime' ? '#10b981' : activeMetric === 'latency' ? '#06b6d4' : '#818cf8'}
                  radius={[6, 6, 0, 0]}
                />
              </BarChart>
            )}
          </ResponsiveContainer>
        </div>
      </div>

      {/* Per-bot Health Breakdown with Quick Filter Clicking */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-extrabold text-sm text-white">Bot Health Breakdown (Click to Inspect)</h3>
          <span className="text-[11px] text-slate-400">Click any card to zoom telemetry chart</span>
        </div>

        {data?.bots && data.bots.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {data.bots.map((bot) => {
              const isSelected = selectedBotId === bot.id;
              const badge = getHealthBadgeStatus(bot.uptimePercentage, bot.status === 'healthy');
              return (
                <div
                  key={bot.id}
                  onClick={() => setSelectedBotId(isSelected ? 'all' : bot.id)}
                  className={`p-4 rounded-2xl liquid-glass-card border cursor-pointer transition-all ${
                    isSelected
                      ? 'border-cyan-400 bg-cyan-950/20 shadow-lg shadow-cyan-500/20 scale-[1.01]'
                      : 'border-white/10 hover:border-white/25'
                  } flex items-center justify-between gap-3`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="text-xl flex-shrink-0">{bot.lang === 'python' ? '🐍' : '🟨'}</div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <p className="font-bold text-sm text-white truncate">{bot.name}</p>
                        <span
                          className={`text-[9px] font-bold px-1.5 py-0.2 rounded ${
                            badge.color === 'emerald'
                              ? 'bg-emerald-500/20 text-emerald-300'
                              : 'bg-rose-500/20 text-rose-300'
                          }`}
                        >
                          {badge.label}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                        <span className="font-mono">ID: #{bot.id}</span>
                        {bot.status === 'healthy' ? (
                          <span className="text-emerald-400 font-semibold flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                            {bot.pingMs}ms
                          </span>
                        ) : (
                          <span className="text-rose-400 font-semibold">Offline</span>
                        )}
                        {bot.status === 'healthy' && (
                          <span className="text-indigo-300 flex items-center gap-0.5">
                            <HardDrive className="w-3 h-3" /> {bot.memoryMb}MB
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="text-right flex-shrink-0">
                    <span
                      className={`text-base font-extrabold block ${
                        bot.status === 'healthy' ? 'text-emerald-300' : 'text-slate-500'
                      }`}
                    >
                      {bot.status === 'healthy' ? `${bot.uptimePercentage}%` : '0%'}
                    </span>
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider">
                      Uptime
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <p className="text-xs text-slate-500 italic">No bots currently deployed to monitor.</p>
        )}
      </div>
    </div>
  );
};
