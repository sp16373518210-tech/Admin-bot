import React from 'react';
import { User, ViewType } from '../types.ts';
import {
  X,
  LayoutDashboard,
  Bot,
  Globe,
  Sparkles,
  User as UserIcon,
  ShieldAlert,
  LogOut,
  Coins,
  ExternalLink,
  Sliders,
  FolderGit2,
  FileCode,
} from 'lucide-react';

interface SidebarDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  user: User | null;
  currentView: ViewType;
  setCurrentView: (view: ViewType) => void;
  onLogout: () => void;
  onOpenAuth: () => void;
}

export const SidebarDrawer: React.FC<SidebarDrawerProps> = ({
  isOpen,
  onClose,
  user,
  currentView,
  setCurrentView,
  onLogout,
  onOpenAuth,
}) => {
  if (!isOpen) return null;

  const navigateTo = (view: ViewType) => {
    setCurrentView(view);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-black/60 backdrop-blur-md transition-opacity duration-300 animate-fadeIn"
      />

      {/* Drawer Container */}
      <div className="relative w-full max-w-sm h-full liquid-glass border-l border-white/15 p-6 flex flex-col justify-between overflow-y-auto z-10 shadow-2xl shadow-cyan-950/50 animate-slideLeft">
        {/* Header */}
        <div>
          <div className="flex items-center justify-between pb-5 border-b border-white/10">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-cyan-500/30">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-base text-white tracking-wide">
                  TeleHost Navigation
                </h3>
                <p className="text-[11px] text-cyan-400 font-medium">3D Liquid Control</p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/15 border border-white/10 flex items-center justify-center text-slate-300 hover:text-white transition-all"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* User Profile Summary Card */}
          {user ? (
            <div className="my-5 p-3.5 rounded-2xl bg-white/[0.04] border border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-cyan-400 to-indigo-600 flex items-center justify-center text-white font-bold text-sm shadow-md">
                  {user.first_name ? user.first_name[0].toUpperCase() : 'U'}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-sm text-white truncate block">
                      {user.first_name} {user.last_name || ''}
                    </span>
                    {user.is_admin && (
                      <span className="text-[9px] font-extrabold px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 border border-purple-500/40">
                        ADMIN
                      </span>
                    )}
                  </div>
                  <span className="text-xs text-slate-400 truncate block">{user.email}</span>
                </div>
              </div>

              <div className="mt-3 pt-2.5 border-t border-white/10 flex items-center justify-between text-xs">
                <span className="text-slate-400 flex items-center gap-1">
                  Telegram Chat ID:
                </span>
                <span className="font-mono font-semibold text-cyan-300">
                  {user.chat_id}
                </span>
              </div>

              <div className="mt-1 flex items-center justify-between text-xs">
                <span className="text-slate-400">Available Slots:</span>
                <span className="font-bold text-amber-300 flex items-center gap-1">
                  <span>🪙</span> {user.is_admin ? 'Unlimited' : `${user.tokens} Tokens`}
                </span>
              </div>
            </div>
          ) : (
            <div className="my-5 p-4 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-center">
              <p className="text-xs text-cyan-200 mb-2.5">
                Sign in to manage and deploy your bots & websites.
              </p>
              <button
                onClick={() => {
                  onClose();
                  onOpenAuth();
                }}
                className="w-full py-2 rounded-xl text-xs font-bold text-white liquid-btn-primary"
              >
                Login / Create Account
              </button>
            </div>
          )}

          {/* Nav Items List */}
          <div className="space-y-1.5">
            <button
              onClick={() => navigateTo('dashboard')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                currentView === 'dashboard'
                  ? 'bg-gradient-to-r from-cyan-500/30 to-blue-500/20 text-cyan-200 border border-cyan-400/40 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <LayoutDashboard className="w-4 h-4 text-cyan-400" />
              <span>📊 Dashboard</span>
            </button>

            <button
              onClick={() => navigateTo('deploy_bot')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                currentView === 'deploy_bot'
                  ? 'bg-gradient-to-r from-cyan-500/30 to-blue-500/20 text-cyan-200 border border-cyan-400/40 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Bot className="w-4 h-4 text-cyan-400" />
              <span>🚀 Bot Hosting</span>
            </button>

            <button
              onClick={() => navigateTo('deploy_web')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                currentView === 'deploy_web'
                  ? 'bg-gradient-to-r from-cyan-500/30 to-blue-500/20 text-cyan-200 border border-cyan-400/40 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Globe className="w-4 h-4 text-emerald-400" />
              <span>🌐 Web Hosting</span>
            </button>

            <button
              onClick={() => navigateTo('manage_bots')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                currentView === 'manage_bots'
                  ? 'bg-gradient-to-r from-cyan-500/30 to-blue-500/20 text-cyan-200 border border-cyan-400/40 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Sliders className="w-4 h-4 text-blue-400" />
              <span>🗂 Manage Bots</span>
            </button>

            <button
              onClick={() => navigateTo('manage_web')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                currentView === 'manage_web'
                  ? 'bg-gradient-to-r from-cyan-500/30 to-blue-500/20 text-cyan-200 border border-cyan-400/40 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <FolderGit2 className="w-4 h-4 text-teal-400" />
              <span>🌐 My Websites</span>
            </button>

            <button
              onClick={() => navigateTo('claim_coupon')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                currentView === 'claim_coupon'
                  ? 'bg-gradient-to-r from-amber-500/30 to-orange-500/20 text-amber-200 border border-amber-400/40 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>🎟 Claim Coupon</span>
            </button>

            <button
              onClick={() => navigateTo('account')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                currentView === 'account'
                  ? 'bg-gradient-to-r from-cyan-500/30 to-blue-500/20 text-cyan-200 border border-cyan-400/40 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <UserIcon className="w-4 h-4 text-indigo-400" />
              <span>👤 My Account</span>
            </button>

            {/* Admin Panel button - ONLY visible for Admin */}
            {user?.is_admin && (
              <button
                onClick={() => navigateTo('admin')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-bold transition-all ${
                  currentView === 'admin'
                    ? 'bg-gradient-to-r from-purple-500/40 to-pink-500/30 text-pink-200 border border-purple-400/50 shadow-md shadow-purple-500/20'
                    : 'text-purple-300 hover:text-white hover:bg-purple-500/15 border border-purple-500/20'
                }`}
              >
                <ShieldAlert className="w-4 h-4 text-pink-400" />
                <span>👑 Admin Panel</span>
              </button>
            )}
          </div>
        </div>

        {/* Footer Area with Telegram link and Logout */}
        <div className="pt-6 border-t border-white/10 space-y-2.5">
          <a
            href="https://t.me/modapkpro02"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between w-full px-3.5 py-2 rounded-xl bg-white/[0.04] hover:bg-white/10 text-xs font-semibold text-slate-300 border border-white/10 transition-colors"
          >
            <span className="flex items-center gap-2">
              <span>💬</span> Telegram Channel Support
            </span>
            <ExternalLink className="w-3.5 h-3.5 text-cyan-400" />
          </a>

          {user && (
            <button
              onClick={() => {
                onClose();
                onLogout();
              }}
              className="w-full flex items-center justify-center gap-2 py-2 rounded-xl text-xs font-bold text-red-400 hover:text-red-300 bg-red-500/10 hover:bg-red-500/20 border border-red-500/25 transition-all"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Logout</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
