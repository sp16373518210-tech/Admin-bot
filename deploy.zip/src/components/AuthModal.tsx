import React, { useState } from 'react';
import { User } from '../types.ts';
import { X, Mail, Lock, KeyRound, User as UserIcon, Send, CheckCircle2, AlertCircle, ArrowLeft, Bot } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: User) => void;
}

type AuthMode = 'login' | 'signup' | 'forgot_request' | 'forgot_verify';

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const [mode, setMode] = useState<AuthMode>('login');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Form Fields
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [chatId, setChatId] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [botToken, setBotToken] = useState('');
  const [resetCode, setResetCode] = useState('');
  const [newPassword, setNewPassword] = useState('');

  if (!isOpen) return null;

  const resetState = () => {
    setError(null);
    setSuccessMsg(null);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Login failed.');
      }
      onSuccess(data.user);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Could not log in.');
    } finally {
      setLoading(false);
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          password,
          chat_id: chatId,
          first_name: firstName,
          last_name: lastName,
          bot_token: botToken,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Registration failed.');
      }
      onSuccess(data.user);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Registration failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    setLoading(true);
    try {
      const res = await fetch('/api/auth/forgot-password/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, chat_id: chatId }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to request reset code.');
      }
      setSuccessMsg(
        `✅ Reset Code Generated! Sent to your Telegram Chat ID: ${chatId}. (Demo Code: ${data.preview_code || 'Sent'})`
      );
      if (data.preview_code) {
        setResetCode(data.preview_code);
      }
      setMode('forgot_verify');
    } catch (err: any) {
      setError(err.message || 'Failed to generate reset code.');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch('/api/auth/forgot-password/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          chat_id: chatId,
          code: resetCode,
          new_password: newPassword,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Verification failed.');
      }
      setSuccessMsg('🎉 Password changed successfully! You can now log in.');
      setMode('login');
      setPassword(newPassword);
    } catch (err: any) {
      setError(err.message || 'Password reset failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-black/70 backdrop-blur-md transition-opacity duration-300"
      />

      {/* Modal Card */}
      <div className="relative w-full max-w-md liquid-glass border border-white/20 rounded-3xl p-6 sm:p-8 z-10 shadow-2xl shadow-cyan-950/60 animate-scaleUp">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 w-8 h-8 rounded-full bg-white/5 hover:bg-white/15 border border-white/10 flex items-center justify-center text-slate-300 hover:text-white transition-all"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="text-center mb-6">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 mx-auto flex items-center justify-center text-white shadow-lg shadow-cyan-500/30 mb-3">
            <KeyRound className="w-6 h-6" />
          </div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
            {mode === 'login' && 'Welcome Back'}
            {mode === 'signup' && 'Create TeleHost Account'}
            {mode === 'forgot_request' && 'Forgot Password'}
            {mode === 'forgot_verify' && 'Verify & Reset Password'}
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {mode === 'login' && 'Sign in to access your hosted bots, websites, and tokens.'}
            {mode === 'signup' && 'Get 1 free trial hosting slot immediately upon registration.'}
            {mode === 'forgot_request' && 'Enter your Email & Telegram Chat ID to receive a recovery code.'}
            {mode === 'forgot_verify' && 'Enter the 6-digit code sent to your Telegram chat to set new password.'}
          </p>
        </div>

        {/* Messages */}
        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/30 flex items-start gap-2.5 text-xs text-red-300">
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-red-400" />
            <span>{error}</span>
          </div>
        )}
        {successMsg && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-start gap-2.5 text-xs text-emerald-300">
            <CheckCircle2 className="w-4 h-4 flex-shrink-0 mt-0.5 text-emerald-400" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Quick Demo Admin Credential Tip */}
        {mode === 'login' && (
          <div className="mb-4 p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-[11px] text-cyan-300 flex items-center justify-between">
            <span>
              💡 <b>Admin Email:</b> <code className="bg-black/30 px-1 py-0.5 rounded text-cyan-200">sp16373518210@gmail.com</code> (pass: <code className="bg-black/30 px-1 py-0.5 rounded">admin123</code>)
            </span>
            <button
              type="button"
              onClick={() => {
                setEmail('sp16373518210@gmail.com');
                setPassword('admin123');
              }}
              className="text-[10px] font-bold text-white px-2 py-0.5 rounded bg-cyan-500/30 hover:bg-cyan-500/50"
            >
              Autofill
            </button>
          </div>
        )}

        {/* ── MODE 1: LOGIN ── */}
        {mode === 'login' && (
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Email Address or Telegram Chat ID
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@gmail.com or 5960319648"
                  className="w-full px-3.5 py-2.5 pl-10 rounded-xl text-sm text-white liquid-glass-input placeholder-slate-500"
                />
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-slate-300">Password</label>
                <button
                  type="button"
                  onClick={() => {
                    resetState();
                    setMode('forgot_request');
                  }}
                  className="text-xs text-cyan-400 hover:text-cyan-300 transition-colors"
                >
                  Forgot password?
                </button>
              </div>
              <div className="relative">
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3.5 py-2.5 pl-10 rounded-xl text-sm text-white liquid-glass-input placeholder-slate-500"
                />
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 rounded-xl text-sm font-bold text-white liquid-btn-primary mt-2 flex items-center justify-center gap-2 cursor-pointer"
            >
              {loading ? 'Signing in...' : 'Sign In'}
            </button>

            <div className="text-center pt-3 border-t border-white/10 text-xs text-slate-400">
              Don't have an account?{' '}
              <button
                type="button"
                onClick={() => {
                  resetState();
                  setMode('signup');
                }}
                className="font-bold text-cyan-400 hover:text-cyan-300 transition-colors ml-1"
              >
                Create Account
              </button>
            </div>
          </form>
        )}

        {/* ── MODE 2: SIGNUP ── */}
        {mode === 'signup' && (
          <form onSubmit={handleSignup} className="space-y-3.5 max-h-[70vh] overflow-y-auto pr-1">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">First Name</label>
                <input
                  type="text"
                  required
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  placeholder="Rahul"
                  className="w-full px-3 py-2 rounded-xl text-sm text-white liquid-glass-input placeholder-slate-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Last Name</label>
                <input
                  type="text"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  placeholder="Sharma"
                  className="w-full px-3 py-2 rounded-xl text-sm text-white liquid-glass-input placeholder-slate-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Telegram Chat ID <span className="text-cyan-400">*</span>
              </label>
              <div className="relative">
                <input
                  type="number"
                  required
                  value={chatId}
                  onChange={(e) => setChatId(e.target.value)}
                  placeholder="e.g. 5960319648"
                  className="w-full px-3.5 py-2 pl-9 rounded-xl text-sm text-white liquid-glass-input placeholder-slate-500"
                />
                <UserIcon className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              </div>
              <p className="text-[10px] text-slate-400 mt-0.5">
                (Get your Telegram Chat ID by messaging @userinfobot on Telegram)
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Email Address</label>
              <div className="relative">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="sp16373518210@gmail.com"
                  className="w-full px-3.5 py-2 pl-9 rounded-xl text-sm text-white liquid-glass-input placeholder-slate-500"
                />
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Telegram Bot Token <span className="text-slate-400 font-normal">(Optional)</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={botToken}
                  onChange={(e) => setBotToken(e.target.value)}
                  placeholder="e.g. 123456789:ABCdefGHI..."
                  className="w-full px-3.5 py-2 pl-9 rounded-xl text-sm text-white liquid-glass-input placeholder-slate-500 font-mono text-xs"
                />
                <Bot className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Set Password</label>
              <div className="relative">
                <input
                  type="password"
                  required
                  minLength={4}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Choose secure password"
                  className="w-full px-3.5 py-2 pl-9 rounded-xl text-sm text-white liquid-glass-input placeholder-slate-500"
                />
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 rounded-xl text-sm font-bold text-white liquid-btn-primary mt-3 flex items-center justify-center gap-2 cursor-pointer"
            >
              {loading ? 'Creating Account...' : 'Register & Claim 1 Free Trial Slot'}
            </button>

            <div className="text-center pt-2 text-xs text-slate-400">
              Already have an account?{' '}
              <button
                type="button"
                onClick={() => {
                  resetState();
                  setMode('login');
                }}
                className="font-bold text-cyan-400 hover:text-cyan-300 ml-1"
              >
                Log In
              </button>
            </div>
          </form>
        )}

        {/* ── MODE 3: FORGOT PASSWORD REQUEST ── */}
        {mode === 'forgot_request' && (
          <form onSubmit={handleForgotRequest} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Registered Email
              </label>
              <div className="relative">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="sp16373518210@gmail.com"
                  className="w-full px-3.5 py-2.5 pl-10 rounded-xl text-sm text-white liquid-glass-input placeholder-slate-500"
                />
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Telegram Chat ID
              </label>
              <div className="relative">
                <input
                  type="number"
                  required
                  value={chatId}
                  onChange={(e) => setChatId(e.target.value)}
                  placeholder="e.g. 5960319648"
                  className="w-full px-3.5 py-2.5 pl-10 rounded-xl text-sm text-white liquid-glass-input placeholder-slate-500"
                />
                <UserIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              </div>
              <p className="text-[10px] text-slate-400 mt-1">
                A 6-digit recovery OTP will be sent to this Telegram Chat ID.
              </p>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 rounded-xl text-sm font-bold text-white liquid-btn-primary mt-2 flex items-center justify-center gap-2 cursor-pointer"
            >
              <Send className="w-4 h-4" />
              {loading ? 'Sending Code...' : 'Send Recovery Code to Telegram'}
            </button>

            <button
              type="button"
              onClick={() => {
                resetState();
                setMode('login');
              }}
              className="w-full text-center text-xs text-slate-400 hover:text-white flex items-center justify-center gap-1.5 pt-2"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Back to Login
            </button>
          </form>
        )}

        {/* ── MODE 4: FORGOT PASSWORD VERIFY ── */}
        {mode === 'forgot_verify' && (
          <form onSubmit={handleForgotVerify} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                6-Digit Recovery Code
              </label>
              <input
                type="text"
                required
                maxLength={6}
                value={resetCode}
                onChange={(e) => setResetCode(e.target.value)}
                placeholder="123456"
                className="w-full px-3.5 py-2.5 rounded-xl text-center text-lg font-mono font-bold tracking-widest text-cyan-300 liquid-glass-input"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                New Password
              </label>
              <div className="relative">
                <input
                  type="password"
                  required
                  minLength={4}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Enter new password"
                  className="w-full px-3.5 py-2.5 pl-10 rounded-xl text-sm text-white liquid-glass-input"
                />
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 rounded-xl text-sm font-bold text-white liquid-btn-primary mt-2 cursor-pointer"
            >
              {loading ? 'Resetting Password...' : 'Save New Password & Login'}
            </button>

            <button
              type="button"
              onClick={() => {
                resetState();
                setMode('forgot_request');
              }}
              className="w-full text-center text-xs text-slate-400 hover:text-white flex items-center justify-center gap-1.5 pt-2"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Request a different code
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
