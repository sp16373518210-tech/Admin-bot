import React, { useState, useEffect } from 'react';
import { User, AdminStats, CouponRecord, BotRecord, WebsiteRecord } from '../types.ts';
import {
  ShieldAlert,
  Users,
  Bot,
  Globe,
  Sparkles,
  Ticket,
  Send,
  Download,
  Trash2,
  Ban,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  RotateCw,
  Plus,
  Coins,
  Search,
  Eye,
  X,
  FileCode,
  Terminal,
} from 'lucide-react';

interface AdminPanelViewProps {
  currentUser: User | null;
}

export const AdminPanelView: React.FC<AdminPanelViewProps> = ({ currentUser }) => {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [usersList, setUsersList] = useState<User[]>([]);
  const [couponsList, setCouponsList] = useState<CouponRecord[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  // User Inspection Modal State (as requested: click on email to inspect bots and websites for illegal activity)
  const [inspectUser, setInspectUser] = useState<User | null>(null);
  const [inspectBots, setInspectBots] = useState<BotRecord[]>([]);
  const [inspectWebsites, setInspectWebsites] = useState<WebsiteRecord[]>([]);
  const [tokenAdjustAmount, setTokenAdjustAmount] = useState('5');

  // Coupon Creation State
  const [customCode, setCustomCode] = useState('');
  const [couponTokens, setCouponTokens] = useState('2');
  const [couponMaxUses, setCouponMaxUses] = useState('20');

  // Broadcast State
  const [broadcastMsg, setBroadcastMsg] = useState('');
  const [broadcasting, setBroadcasting] = useState(false);

  const fetchAdminData = async () => {
    setLoading(true);
    try {
      const [resStats, resUsers, resCoupons] = await Promise.all([
        fetch('/api/admin/stats'),
        fetch('/api/admin/users'),
        fetch('/api/admin/coupons'),
      ]);
      const dataStats = await resStats.json();
      const dataUsers = await resUsers.json();
      const dataCoupons = await resCoupons.json();

      setStats(dataStats.stats);
      setUsersList(dataUsers.users || []);
      setCouponsList(dataCoupons.coupons || []);
    } catch (e) {
      console.error('Failed to load admin data:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, []);

  const handleInspectUser = async (targetUser: User) => {
    try {
      const res = await fetch(`/api/admin/users/${targetUser.id}/inspect`);
      const data = await res.json();
      setInspectUser(data.user);
      setInspectBots(data.bots || []);
      setInspectWebsites(data.websites || []);
    } catch (e) {
      console.error(e);
    }
  };

  const handleToggleBan = async (targetId: number) => {
    try {
      const res = await fetch(`/api/admin/users/${targetId}/ban`, { method: 'POST' });
      const data = await res.json();
      setMessage(`User ban status updated to: ${data.banned ? 'BANNED 🚫' : 'ACTIVE ✅'}`);
      fetchAdminData();
      if (inspectUser && inspectUser.id === targetId) {
        setInspectUser({ ...inspectUser, banned: data.banned });
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleAdjustTokens = async (targetId: number, amount: number) => {
    try {
      const res = await fetch(`/api/admin/users/${targetId}/tokens`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount }),
      });
      const data = await res.json();
      setMessage(`Updated tokens! New balance: ${data.tokens}`);
      fetchAdminData();
      if (inspectUser && inspectUser.id === targetId) {
        setInspectUser({ ...inspectUser, tokens: data.tokens });
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleCreateCoupon = async (autoGen: boolean) => {
    try {
      const res = await fetch('/api/admin/coupons/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: customCode,
          auto_generate: autoGen,
          tokens: couponTokens,
          max_uses: couponMaxUses,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setMessage(`🎉 Coupon created! Code: ${data.coupon.code}`);
      setCustomCode('');
      fetchAdminData();
    } catch (err: any) {
      setMessage(`❌ ${err.message || 'Error creating coupon'}`);
    }
  };

  const handleDeleteCoupon = async (code: string) => {
    try {
      await fetch(`/api/admin/coupons/${code}`, { method: 'DELETE' });
      setMessage(`Coupon ${code} deleted.`);
      fetchAdminData();
    } catch (e) {
      console.error(e);
    }
  };

  const handleBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastMsg.trim()) return;
    setBroadcasting(true);
    try {
      const res = await fetch('/api/admin/broadcast', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: broadcastMsg }),
      });
      const data = await res.json();
      setMessage(data.message || 'Broadcast sent successfully!');
      setBroadcastMsg('');
    } catch (e) {
      setMessage('Broadcast failed.');
    } finally {
      setBroadcasting(false);
    }
  };

  const filteredUsers = usersList.filter((u) => {
    const q = searchQuery.toLowerCase();
    return (
      u.email.toLowerCase().includes(q) ||
      String(u.chat_id).includes(q) ||
      u.first_name.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="liquid-glass rounded-3xl p-6 sm:p-8 border border-white/15 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-500 via-pink-500 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-purple-500/25">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <h1 className="text-2xl font-extrabold text-white">Master Admin Control Panel</h1>
          </div>
          <p className="text-xs text-slate-400">
            Exclusive super-admin room for <span className="text-pink-300 font-mono">sp16373518210@gmail.com</span> (Chat ID: 5960319648)
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* 1-Click Download Updated bot.py */}
          <a
            href="/api/download/bot.py"
            download="bot.py"
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-white bg-white/10 hover:bg-white/20 border border-white/15 transition-all shadow-sm"
          >
            <Download className="w-4 h-4 text-cyan-400" />
            <span>Download bot.py</span>
          </a>

          {/* 1-Click Download deploy.zip for JustRunMy.App & Cloud */}
          <a
            href="/api/download/deploy.zip"
            download="deploy.zip"
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-cyan-500/20 to-blue-500/20 hover:from-cyan-500/30 hover:to-blue-500/30 border border-cyan-400/40 transition-all shadow-sm shadow-cyan-500/20"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Download deploy.zip (Cloud Ready)</span>
          </a>

          <button
            onClick={fetchAdminData}
            title="Refresh Admin Data"
            className="p-2 rounded-xl bg-white/5 hover:bg-white/15 border border-white/10 text-slate-300 transition-colors"
          >
            <RotateCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Alert Notice */}
      {message && (
        <div className="p-4 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-between text-xs text-cyan-300 animate-fadeIn">
          <span>{message}</span>
          <button onClick={() => setMessage(null)} className="text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Statistics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="liquid-glass-card rounded-2xl p-4 border border-white/10">
          <span className="text-[11px] font-semibold text-slate-400 uppercase">Total Users</span>
          <p className="text-2xl font-extrabold text-white mt-1">
            {stats ? stats.totalUsers : usersList.length}
          </p>
        </div>

        <div className="liquid-glass-card rounded-2xl p-4 border border-white/10">
          <span className="text-[11px] font-semibold text-slate-400 uppercase">Hosted Bots</span>
          <p className="text-2xl font-extrabold text-cyan-300 mt-1">
            {stats ? stats.totalBots : 0} <span className="text-xs font-normal text-slate-400">({stats?.runningBots || 0} live)</span>
          </p>
        </div>

        <div className="liquid-glass-card rounded-2xl p-4 border border-white/10">
          <span className="text-[11px] font-semibold text-slate-400 uppercase">Hosted Websites</span>
          <p className="text-2xl font-extrabold text-emerald-300 mt-1">
            {stats ? stats.totalWebsites : 0}
          </p>
        </div>

        <div className="liquid-glass-card rounded-2xl p-4 border border-white/10">
          <span className="text-[11px] font-semibold text-slate-400 uppercase">Active Coupons</span>
          <p className="text-2xl font-extrabold text-amber-300 mt-1">
            {couponsList.filter((c) => c.used < c.max_uses).length}
          </p>
        </div>
      </div>

      {/* 2-Columns Layout: Coupon Creator & Broadcast Tool */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Coupon Manager Card */}
        <div className="liquid-glass rounded-3xl p-6 border border-white/15 space-y-5">
          <div className="flex items-center gap-2 pb-3 border-b border-white/10">
            <Ticket className="w-5 h-5 text-amber-400" />
            <h2 className="font-extrabold text-base text-white">Coupon Management</h2>
          </div>

          <div className="space-y-4">
            {/* Quick 1-Click Auto Coupon Generator Button (As Requested!) */}
            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/25 flex items-center justify-between gap-3">
              <div>
                <p className="text-xs font-bold text-amber-200">Instant 1-Click Auto Generator</p>
                <p className="text-[11px] text-slate-400">Auto-generates a unique code without manual typing.</p>
              </div>
              <button
                type="button"
                onClick={() => handleCreateCoupon(true)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-amber-500 to-orange-500 hover:opacity-95 shadow-md shadow-amber-500/20 cursor-pointer flex-shrink-0"
              >
                🎲 Auto-Generate Code
              </button>
            </div>

            {/* Custom Coupon Form */}
            <div className="space-y-3">
              <div className="grid grid-cols-3 gap-2">
                <div className="col-span-1">
                  <label className="block text-[11px] text-slate-400 mb-1">Tokens/User</label>
                  <input
                    type="number"
                    value={couponTokens}
                    onChange={(e) => setCouponTokens(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-xl text-xs text-white liquid-glass-input"
                  />
                </div>
                <div className="col-span-1">
                  <label className="block text-[11px] text-slate-400 mb-1">Max Users</label>
                  <input
                    type="number"
                    value={couponMaxUses}
                    onChange={(e) => setCouponMaxUses(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-xl text-xs text-white liquid-glass-input"
                  />
                </div>
                <div className="col-span-1">
                  <label className="block text-[11px] text-slate-400 mb-1">Custom Code</label>
                  <input
                    type="text"
                    value={customCode}
                    onChange={(e) => setCustomCode(e.target.value.toUpperCase())}
                    placeholder="VIP2026"
                    className="w-full px-3 py-1.5 rounded-xl text-xs text-white liquid-glass-input uppercase font-mono"
                  />
                </div>
              </div>

              <button
                type="button"
                onClick={() => handleCreateCoupon(false)}
                className="w-full py-2.5 rounded-xl text-xs font-bold text-white liquid-btn-primary cursor-pointer"
              >
                Create Custom Coupon
              </button>
            </div>

            {/* Existing Coupons Mini-List */}
            <div className="pt-3 border-t border-white/10 space-y-2">
              <span className="text-xs font-bold text-slate-300 block">Existing Coupons:</span>
              <div className="max-h-40 overflow-y-auto space-y-1.5 pr-1">
                {couponsList.map((cp) => (
                  <div
                    key={cp.code}
                    className="p-2.5 rounded-xl bg-white/[0.02] border border-white/10 flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-mono font-bold text-amber-300">{cp.code}</span>
                      <span className="text-[11px] text-slate-400 ml-2">
                        {cp.tokens}🪙 • ({cp.used}/{cp.max_uses} used)
                      </span>
                    </div>
                    <button
                      onClick={() => handleDeleteCoupon(cp.code)}
                      className="text-rose-400 hover:text-rose-300 p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Broadcast Tool Card */}
        <div className="liquid-glass rounded-3xl p-6 border border-white/15 space-y-5">
          <div className="flex items-center gap-2 pb-3 border-b border-white/10">
            <Send className="w-5 h-5 text-cyan-400" />
            <h2 className="font-extrabold text-base text-white">Broadcast Message</h2>
          </div>

          <form onSubmit={handleBroadcast} className="space-y-3">
            <p className="text-xs text-slate-400">
              Send an instant announcement to all registered Telegram users connected to your panel.
            </p>

            <textarea
              rows={5}
              required
              value={broadcastMsg}
              onChange={(e) => setBroadcastMsg(e.target.value)}
              placeholder="📢 Important Update: New features and free tokens available now!"
              className="w-full p-3 rounded-2xl font-sans text-xs text-white bg-black/40 border border-white/15 focus:border-cyan-400 focus:outline-none"
            />

            <button
              type="submit"
              disabled={broadcasting}
              className="w-full py-2.5 rounded-xl text-xs font-bold text-white liquid-btn-primary flex items-center justify-center gap-2 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{broadcasting ? 'Sending Broadcast...' : 'Broadcast to All Users'}</span>
            </button>
          </form>
        </div>
      </div>

      {/* Users Management Table & Inspection Section */}
      <div className="liquid-glass rounded-3xl p-6 sm:p-8 border border-white/15 space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
          <div>
            <h2 className="font-extrabold text-lg text-white">Registered Users & Hosted Projects</h2>
            <p className="text-xs text-slate-400">
              Click on any user's Gmail to inspect their hosted bots and websites to ensure no illegal content.
            </p>
          </div>

          <div className="relative w-full sm:w-64">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search user, email, chat ID..."
              className="w-full px-3 py-1.5 pl-8 rounded-xl text-xs text-white liquid-glass-input placeholder-slate-500"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2" />
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-white/10 text-slate-400 uppercase text-[10px] tracking-wider">
                <th className="py-2.5 px-3">User & Email</th>
                <th className="py-2.5 px-3">Chat ID</th>
                <th className="py-2.5 px-3">Tokens</th>
                <th className="py-2.5 px-3">Bots</th>
                <th className="py-2.5 px-3">Websites</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredUsers.map((u) => (
                <tr key={u.id} className="hover:bg-white/[0.02] transition-colors">
                  <td className="py-3 px-3">
                    <button
                      onClick={() => handleInspectUser(u)}
                      className="text-left group cursor-pointer"
                    >
                      <span className="font-bold text-white group-hover:text-cyan-300 transition-colors block">
                        {u.first_name} {u.last_name || ''}
                      </span>
                      <span className="text-[11px] text-cyan-400 font-mono underline decoration-cyan-500/30">
                        {u.email}
                      </span>
                    </button>
                  </td>
                  <td className="py-3 px-3 font-mono text-slate-300">{u.chat_id}</td>
                  <td className="py-3 px-3 font-bold text-amber-300">{u.tokens} 🪙</td>
                  <td className="py-3 px-3 text-slate-300">{u.botsCount || 0}</td>
                  <td className="py-3 px-3 text-slate-300">{u.webCount || 0}</td>
                  <td className="py-3 px-3">
                    {u.banned ? (
                      <span className="px-2 py-0.5 rounded bg-red-500/20 text-red-300 text-[10px] font-bold">
                        BANNED
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">
                        ACTIVE
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-3 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => handleInspectUser(u)}
                        title="Inspect User Bots & Websites"
                        className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-cyan-300"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => handleToggleBan(u.id)}
                        title={u.banned ? 'Unban User' : 'Ban User'}
                        className={`p-1.5 rounded-lg ${
                          u.banned ? 'bg-emerald-500/15 text-emerald-300' : 'bg-red-500/15 text-red-400'
                        }`}
                      >
                        <Ban className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* User Deep Inspection Modal (Checks Bots, Bot Tokens, Websites, Links) */}
      {inspectUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div onClick={() => setInspectUser(null)} className="fixed inset-0 bg-black/80 backdrop-blur-md" />
          <div className="relative w-full max-w-4xl max-h-[85vh] overflow-y-auto liquid-glass border border-white/20 rounded-3xl p-6 sm:p-8 z-10 animate-scaleUp space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div>
                <h3 className="font-extrabold text-xl text-white">
                  User Audit: {inspectUser.first_name}
                </h3>
                <p className="text-xs text-slate-400">
                  Email: <b className="text-cyan-300">{inspectUser.email}</b> • Telegram Chat ID:{' '}
                  <code className="text-indigo-300">{inspectUser.chat_id}</code>
                </p>
              </div>

              <button
                onClick={() => setInspectUser(null)}
                className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/15 flex items-center justify-center text-slate-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Actions for this user */}
            <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/10 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-300 font-semibold">Token Balance:</span>
                <span className="font-bold text-amber-300">{inspectUser.tokens} 🪙</span>
                <button
                  onClick={() => handleAdjustTokens(inspectUser.id, 5)}
                  className="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 text-xs font-bold"
                >
                  +5 Tokens
                </button>
                <button
                  onClick={() => handleAdjustTokens(inspectUser.id, -1)}
                  className="px-2.5 py-1 rounded-lg bg-rose-500/20 text-rose-300 text-xs font-bold"
                >
                  -1 Token
                </button>
              </div>

              <button
                onClick={() => handleToggleBan(inspectUser.id)}
                className={`px-4 py-1.5 rounded-xl text-xs font-bold ${
                  inspectUser.banned
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'bg-red-500/20 text-red-300 border border-red-500/40'
                }`}
              >
                {inspectUser.banned ? 'Unban User' : 'Ban User & Terminate Bots'}
              </button>
            </div>

            {/* Hosted Bots Audit */}
            <div className="space-y-3">
              <h4 className="font-bold text-sm text-cyan-300 flex items-center gap-2">
                <Bot className="w-4 h-4" />
                <span>Hosted Telegram Bots ({inspectBots.length})</span>
              </h4>

              {inspectBots.length === 0 ? (
                <p className="text-xs text-slate-500 italic">No bots hosted by this user.</p>
              ) : (
                <div className="space-y-2">
                  {inspectBots.map((b) => (
                    <div key={b.id} className="p-3.5 rounded-2xl bg-black/40 border border-white/10 space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm text-white">{b.bot_title || b.name}</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/10 text-slate-300 uppercase">
                            {b.lang}
                          </span>
                        </div>
                        {b.bot_username && (
                          <a
                            href={`https://t.me/${b.bot_username}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-cyan-400 hover:underline flex items-center gap-1 font-mono"
                          >
                            @{b.bot_username} <ExternalLink className="w-3 h-3" />
                          </a>
                        )}
                      </div>

                      <div className="text-xs text-slate-400">
                        <span>Bot Token: </span>
                        <code className="text-amber-200 font-mono text-[11px] bg-black/50 px-2 py-0.5 rounded">
                          {b.bot_token || 'Token not saved'}
                        </code>
                      </div>

                      {b.code_snippet && (
                        <div className="mt-2 p-2.5 rounded-xl bg-slate-950 font-mono text-[11px] text-slate-400 max-h-24 overflow-y-auto">
                          {b.code_snippet}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Hosted Websites Audit */}
            <div className="space-y-3">
              <h4 className="font-bold text-sm text-emerald-300 flex items-center gap-2">
                <Globe className="w-4 h-4" />
                <span>Hosted Websites ({inspectWebsites.length})</span>
              </h4>

              {inspectWebsites.length === 0 ? (
                <p className="text-xs text-slate-500 italic">No websites hosted by this user.</p>
              ) : (
                <div className="space-y-2">
                  {inspectWebsites.map((s) => (
                    <div
                      key={s.id}
                      className="p-3.5 rounded-2xl bg-black/40 border border-white/10 flex items-center justify-between gap-3"
                    >
                      <div>
                        <span className="font-bold text-sm text-white block">{s.name}</span>
                        <code className="text-xs text-emerald-400 font-mono">
                          /sites/{s.slug}/
                        </code>
                      </div>

                      <a
                        href={`/sites/${s.slug}/`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center gap-1"
                      >
                        <span>Audit Live Website</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
