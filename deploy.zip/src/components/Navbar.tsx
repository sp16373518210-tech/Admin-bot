import React from 'react';
import { User, ViewType } from '../types.ts';
import { Bot, Globe, ShieldAlert, Sparkles, Coins, Menu, LogIn, ExternalLink } from 'lucide-react';

interface NavbarProps {
  user: User | null;
  currentView: ViewType;
  setCurrentView: (view: ViewType) => void;
  onOpenDrawer: () => void;
  onOpenAuth: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  currentView,
  setCurrentView,
  onOpenDrawer,
  onOpenAuth,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full px-4 sm:px-8 py-3.5 liquid-glass border-b border-white/10 backdrop-blur-2xl">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Brand / Logo */}
        <div
          onClick={() => setCurrentView('dashboard')}
          className="flex items-center gap-3 cursor-pointer group select-none"
        >
          <div className="relative w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 p-[1px] shadow-lg shadow-cyan-500/25 group-hover:shadow-cyan-400/40 transition-all duration-300 transform group-hover:scale-105">
            <div className="w-full h-full bg-[#0a0f24] rounded-2xl flex items-center justify-center backdrop-blur-md">
              <Bot className="w-5 h-5 text-cyan-400 group-hover:rotate-12 transition-transform duration-300" />
            </div>
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full border-2 border-[#0a0f24] animate-pulse"></span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-xl tracking-tight bg-gradient-to-r from-white via-slate-100 to-cyan-300 bg-clip-text text-transparent">
                TeleHost
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-cyan-500/15 text-cyan-400 border border-cyan-500/30 tracking-wider">
                3D CLOUD
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium hidden sm:block">
              Telegram Bots & Web Hosting Panel
            </p>
          </div>
        </div>

        {/* Desktop Quick Nav Links */}
        <nav className="hidden md:flex items-center gap-1.5 p-1 rounded-2xl bg-white/[0.03] border border-white/10 backdrop-blur-xl">
          <button
            onClick={() => setCurrentView('dashboard')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-all ${
              currentView === 'dashboard'
                ? 'bg-gradient-to-r from-cyan-500/30 to-blue-500/30 text-cyan-300 border border-cyan-500/40 shadow-sm shadow-cyan-500/20'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => setCurrentView('deploy_bot')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-all ${
              currentView === 'deploy_bot'
                ? 'bg-gradient-to-r from-cyan-500/30 to-blue-500/30 text-cyan-300 border border-cyan-500/40 shadow-sm shadow-cyan-500/20'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Bot className="w-3.5 h-3.5 text-cyan-400" />
            Bot Hosting
          </button>
          <button
            onClick={() => setCurrentView('deploy_web')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-all ${
              currentView === 'deploy_web'
                ? 'bg-gradient-to-r from-cyan-500/30 to-blue-500/30 text-cyan-300 border border-cyan-500/40 shadow-sm shadow-cyan-500/20'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Globe className="w-3.5 h-3.5 text-emerald-400" />
            Web Hosting
          </button>
          <button
            onClick={() => setCurrentView('claim_coupon')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl transition-all ${
              currentView === 'claim_coupon'
                ? 'bg-gradient-to-r from-amber-500/30 to-orange-500/30 text-amber-300 border border-amber-500/40 shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            Redeem Coupon
          </button>

          {user?.is_admin && (
            <button
              onClick={() => setCurrentView('admin')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl transition-all ${
                currentView === 'admin'
                  ? 'bg-gradient-to-r from-purple-500/40 to-pink-500/40 text-pink-300 border border-purple-500/50 shadow-md shadow-purple-500/20'
                  : 'text-purple-300 hover:text-white hover:bg-purple-500/10 border border-purple-500/20'
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5 text-pink-400" />
              Admin Panel
            </button>
          )}
        </nav>

        {/* Right Side: Tokens, Account, Hamburger */}
        <div className="flex items-center gap-3">
          {user ? (
            <>
              {/* Token Counter Badge */}
              <div
                onClick={() => setCurrentView('claim_coupon')}
                className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r from-amber-500/10 via-amber-400/15 to-yellow-500/10 border border-amber-400/30 text-amber-300 cursor-pointer hover:border-amber-400/60 hover:shadow-lg hover:shadow-amber-500/15 transition-all duration-300 select-none"
                title="Tokens available for hosting bots and websites"
              >
                <div className="w-5 h-5 rounded-full bg-amber-400/20 flex items-center justify-center text-xs">
                  🪙
                </div>
                <div className="flex items-baseline gap-1">
                  <span className="font-extrabold text-sm text-amber-200">
                    {user.is_admin ? '∞' : user.tokens}
                  </span>
                  <span className="text-[10px] text-amber-400/80 uppercase font-semibold hidden sm:inline">
                    Tokens
                  </span>
                </div>
                <span className="text-xs text-amber-400/60 font-bold hover:text-amber-200 transition-colors">
                  +
                </span>
              </div>

              {/* User Avatar Chip */}
              <div
                onClick={() => setCurrentView('account')}
                className="hidden sm:flex items-center gap-2 pl-2 pr-3 py-1 rounded-full bg-white/5 border border-white/10 hover:border-white/25 cursor-pointer transition-all"
              >
                <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-xs font-bold text-white shadow-sm">
                  {user.first_name ? user.first_name[0].toUpperCase() : 'U'}
                </div>
                <div className="text-left">
                  <span className="text-xs font-semibold text-slate-200 block truncate max-w-[100px]">
                    {user.first_name}
                  </span>
                </div>
              </div>
            </>
          ) : (
            <button
              onClick={onOpenAuth}
              className="flex items-center gap-2 px-4 py-1.5 rounded-xl text-xs font-bold text-white liquid-btn-primary"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Login / Sign Up</span>
            </button>
          )}

          {/* 3-Line Hamburger Menu Button (Top Right as requested) */}
          <button
            onClick={onOpenDrawer}
            aria-label="Open navigation menu"
            className="w-10 h-10 rounded-xl bg-white/5 border border-white/15 hover:border-cyan-400/50 hover:bg-white/10 flex flex-col items-center justify-center gap-1 transition-all duration-200 group focus:outline-none"
          >
            <span className="w-5 h-[2.5px] rounded-full bg-slate-300 group-hover:bg-cyan-400 group-hover:w-6 transition-all duration-200"></span>
            <span className="w-5 h-[2.5px] rounded-full bg-slate-300 group-hover:bg-cyan-400 transition-all duration-200"></span>
            <span className="w-5 h-[2.5px] rounded-full bg-slate-300 group-hover:bg-cyan-400 group-hover:w-4 transition-all duration-200"></span>
          </button>
        </div>
      </div>
    </header>
  );
};
