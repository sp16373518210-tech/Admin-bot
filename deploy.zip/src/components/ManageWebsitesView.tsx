import React, { useState } from 'react';
import { User, WebsiteRecord, ViewType } from '../types.ts';
import {
  Globe,
  ExternalLink,
  Share2,
  Copy,
  Check,
  Trash2,
  Eye,
  X,
  FileCode,
  Calendar,
  Layers,
} from 'lucide-react';

interface ManageWebsitesViewProps {
  user: User | null;
  websites: WebsiteRecord[];
  onDeleteWebsite: (siteId: number) => void;
  setCurrentView: (view: ViewType) => void;
}

export const ManageWebsitesView: React.FC<ManageWebsitesViewProps> = ({
  user,
  websites,
  onDeleteWebsite,
  setCurrentView,
}) => {
  const [previewSite, setPreviewSite] = useState<WebsiteRecord | null>(null);
  const [copiedId, setCopiedId] = useState<number | null>(null);

  const copyUrl = (site: WebsiteRecord) => {
    const url = `${window.location.origin}/sites/${site.slug}/`;
    navigator.clipboard.writeText(url);
    setCopiedId(site.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Title */}
      <div className="liquid-glass rounded-3xl p-6 sm:p-8 border border-white/15 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center text-white shadow-lg shadow-emerald-500/25">
              <Globe className="w-5 h-5" />
            </div>
            <h1 className="text-2xl font-extrabold text-white">Manage Hosted Websites</h1>
          </div>
          <p className="text-xs text-slate-400">
            Preview, share, and manage your live static websites hosted on TeleHost 3D.
          </p>
        </div>

        <button
          onClick={() => setCurrentView('deploy_web')}
          className="px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-emerald-500 to-teal-600 hover:opacity-95 shadow-lg shadow-emerald-500/25 cursor-pointer"
        >
          + Deploy New Website
        </button>
      </div>

      {/* Website Cards */}
      {websites.length === 0 ? (
        <div className="liquid-glass rounded-3xl p-12 text-center border border-white/10">
          <Globe className="w-16 h-16 text-slate-600 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-white mb-1">No websites hosted yet</h3>
          <p className="text-xs text-slate-400 mb-6 max-w-sm mx-auto">
            Upload an HTML file or ZIP archive to create your first online website.
          </p>
          <button
            onClick={() => setCurrentView('deploy_web')}
            className="px-5 py-2.5 rounded-xl text-xs font-bold text-white liquid-btn-primary"
          >
            Deploy Website Now
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {websites.map((site) => {
            const liveUrl = `${window.location.origin}/sites/${site.slug}/`;
            return (
              <div
                key={site.id}
                className="liquid-glass-card rounded-3xl p-6 border border-white/15 flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/25 flex items-center justify-center text-emerald-400">
                        <Globe className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="font-extrabold text-base text-white">{site.name}</h3>
                        <span className="text-[11px] text-slate-400 font-mono">
                          Slug: /sites/{site.slug}/
                        </span>
                      </div>
                    </div>

                    <span className="px-2.5 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[11px] font-bold">
                      LIVE 24/7
                    </span>
                  </div>

                  {/* URL Bar */}
                  <div className="p-3 rounded-2xl bg-black/40 border border-white/10 flex items-center justify-between gap-2 mb-4">
                    <code className="text-xs font-mono text-emerald-300 truncate">
                      {liveUrl}
                    </code>
                    <button
                      onClick={() => copyUrl(site)}
                      title="Copy URL"
                      className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-slate-300 transition-colors flex-shrink-0"
                    >
                      {copiedId === site.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs text-slate-400">
                    <div className="p-2 rounded-xl bg-white/[0.02] border border-white/10 flex items-center gap-2">
                      <FileCode className="w-3.5 h-3.5 text-slate-500" />
                      <span>Entry: {site.entry}</span>
                    </div>
                    <div className="p-2 rounded-xl bg-white/[0.02] border border-white/10 flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5 text-slate-500" />
                      <span>{new Date(site.created_at * 1000).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-4 border-t border-white/10 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setPreviewSite(site)}
                      className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-white liquid-btn-primary cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Interactive Preview</span>
                    </button>

                    <a
                      href={liveUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 rounded-xl bg-white/5 hover:bg-white/15 text-slate-300 transition-colors"
                      title="Open in New Tab"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </a>

                    <a
                      href={`https://t.me/share/url?url=${encodeURIComponent(liveUrl)}&text=${encodeURIComponent(
                        `Check out my website on TeleHost 3D: ${site.name}`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 rounded-xl bg-blue-500/10 hover:bg-blue-500/20 text-blue-300 border border-blue-500/30 transition-colors"
                      title="Share to Telegram"
                    >
                      <Share2 className="w-4 h-4" />
                    </a>
                  </div>

                  <button
                    onClick={() => {
                      if (confirm(`Delete website "${site.name}" and refund token?`)) {
                        onDeleteWebsite(site.id);
                      }
                    }}
                    title="Delete Website"
                    className="p-2 rounded-xl text-rose-400 hover:text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/25 transition-all cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Interactive Live Iframe Preview Modal */}
      {previewSite && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div onClick={() => setPreviewSite(null)} className="fixed inset-0 bg-black/80 backdrop-blur-md" />
          <div className="relative w-full max-w-5xl h-[85vh] liquid-glass border border-white/20 rounded-3xl p-6 z-10 flex flex-col shadow-2xl animate-scaleUp">
            {/* Modal Header Bar */}
            <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-3 flex-shrink-0">
              <div className="flex items-center gap-3">
                <Globe className="w-5 h-5 text-emerald-400" />
                <div>
                  <h3 className="font-extrabold text-base text-white">{previewSite.name}</h3>
                  <span className="text-[11px] text-slate-400 font-mono">
                    /sites/{previewSite.slug}/
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <a
                  href={`/sites/${previewSite.slug}/`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-white flex items-center gap-1.5"
                >
                  <span>Open Fullscreen</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
                <button
                  onClick={() => setPreviewSite(null)}
                  className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/15 flex items-center justify-center text-slate-300 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Iframe Viewport */}
            <div className="w-full flex-1 rounded-2xl overflow-hidden border border-white/15 bg-slate-950">
              <iframe
                src={`/sites/${previewSite.slug}/`}
                title={previewSite.name}
                className="w-full h-full border-0"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
