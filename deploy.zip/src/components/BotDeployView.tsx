import React, { useState, useEffect } from 'react';
import { User, BotRecord, ViewType } from '../types.ts';
import {
  Bot,
  Upload,
  Code2,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Loader2,
  ShieldCheck,
  FileCode,
  Sparkles,
} from 'lucide-react';

interface BotDeployViewProps {
  user: User | null;
  onDeploySuccess: (bot: BotRecord) => void;
  setCurrentView: (view: ViewType) => void;
  onOpenAuth: () => void;
}

export const BotDeployView: React.FC<BotDeployViewProps> = ({
  user,
  onDeploySuccess,
  setCurrentView,
  onOpenAuth,
}) => {
  const [botName, setBotName] = useState('');
  const [adminChatId, setAdminChatId] = useState(user?.chat_id ? String(user.chat_id) : '');
  const [botToken, setBotToken] = useState('');
  const [tokenChecking, setTokenChecking] = useState(false);
  const [tokenInfo, setTokenInfo] = useState<{ id: number; first_name: string; username: string } | null>(null);
  const [lang, setLang] = useState<'python' | 'node'>('python');
  const [entryFile, setEntryFile] = useState('bot.py');
  const [uploadMode, setUploadMode] = useState<'template' | 'file'>('template');
  const [fileBase64, setFileBase64] = useState<string | null>(null);
  const [fileName, setFileName] = useState('');
  const [codeSnippet, setCodeSnippet] = useState(
    `# 🚀 TeleHost 3D Python Bot Template
import os
import telebot

TOKEN = "YOUR_BOT_TOKEN_HERE"
bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    bot.reply_to(message, "👋 Hello! I am running 24/7 on TeleHost 3D Cloud!")

@bot.message_handler(func=lambda msg: True)
def echo_all(message):
    bot.reply_to(message, f"You said: {message.text}")

print("Bot is listening for messages...")
bot.infinity_polling()
`
  );

  const [deploying, setDeploying] = useState(false);
  const [deployStep, setDeployStep] = useState(0); // 1: Extract, 2: Auto-requirements, 3: Completed
  const [error, setError] = useState<string | null>(null);

  // Update entry file and template when language changes
  const handleLangChange = (newLang: 'python' | 'node') => {
    setLang(newLang);
    if (newLang === 'python') {
      setEntryFile('bot.py');
      setCodeSnippet(
        `# 🚀 TeleHost 3D Python Bot Template\nimport os\nimport telebot\n\nTOKEN = "${botToken || 'YOUR_BOT_TOKEN'}"\nbot = telebot.TeleBot(TOKEN)\n\n@bot.message_handler(commands=['start', 'help'])\ndef send_welcome(message):\n    bot.reply_to(message, "👋 Hello! I am running 24/7 on TeleHost 3D Cloud!")\n\nprint("Bot is listening for messages...")\nbot.infinity_polling()\n`
      );
    } else {
      setEntryFile('index.js');
      setCodeSnippet(
        `// 🚀 TeleHost 3D Node.js Bot Template\nconst { Telegraf } = require('telegraf');\n\nconst bot = new Telegraf("${botToken || 'YOUR_BOT_TOKEN'}");\n\nbot.start((ctx) => ctx.reply('👋 Hello! I am running 24/7 on TeleHost 3D Cloud!'));\nbot.on('text', (ctx) => ctx.reply(\`Echo: \${ctx.message.text}\`));\n\nconsole.log('Bot is online!');\nbot.launch();\n`
      );
    }
  };

  // Debounced Telegram Token Verification via getMe
  useEffect(() => {
    const cleanToken = botToken.trim();
    if (!cleanToken || !cleanToken.includes(':')) {
      setTokenInfo(null);
      return;
    }

    const timer = setTimeout(async () => {
      setTokenChecking(true);
      try {
        const res = await fetch('/api/bots/verify-token', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ token: cleanToken }),
        });
        const data = await res.json();
        if (data.valid && data.bot) {
          setTokenInfo(data.bot);
          if (!botName) {
            setBotName(data.bot.first_name);
          }
        } else {
          setTokenInfo(null);
        }
      } catch (e) {
        setTokenInfo(null);
      } finally {
        setTokenChecking(false);
      }
    }, 600);

    return () => clearTimeout(timer);
  }, [botToken]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    const reader = new FileReader();
    if (file.name.endsWith('.zip')) {
      reader.readAsDataURL(file);
      reader.onload = () => {
        const res = reader.result as string;
        const base64 = res.split(',')[1];
        setFileBase64(base64);
      };
    } else {
      reader.readAsText(file);
      reader.onload = () => {
        setCodeSnippet(reader.result as string);
        setEntryFile(file.name);
      };
    }
  };

  const handleDeploy = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      onOpenAuth();
      return;
    }

    if (!user.is_admin && user.tokens < 1) {
      setError('Not enough tokens! You need 1 token to deploy. Please claim a coupon.');
      return;
    }

    setError(null);
    setDeploying(true);
    setDeployStep(1);

    try {
      // Step 1: Upload & Extraction
      await new Promise((r) => setTimeout(r, 900));
      setDeployStep(2);

      // Step 2: Auto-requirements install simulation
      await new Promise((r) => setTimeout(r, 1200));

      const payload: any = {
        user_id: user.id,
        name: botName || (tokenInfo ? tokenInfo.first_name : 'My Telegram Bot'),
        lang,
        entry: entryFile,
        bot_token: botToken,
      };

      if (uploadMode === 'file' && fileBase64) {
        payload.zip_base64 = fileBase64;
      } else {
        payload.code_snippet = codeSnippet;
      }

      const res = await fetch('/api/bots/deploy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Deploy failed');
      }

      setDeployStep(3);
      await new Promise((r) => setTimeout(r, 800));

      onDeploySuccess(data.bot);
      setCurrentView('manage_bots');
    } catch (err: any) {
      setError(err.message || 'Deploy failed');
      setDeployStep(0);
    } finally {
      setDeploying(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-fadeIn">
      {/* Title Card */}
      <div className="liquid-glass rounded-3xl p-6 sm:p-8 border border-white/15">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/25">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-white">Deploy Telegram Bot</h1>
            <p className="text-xs text-slate-400">
              Host Python or Node.js Telegram bots 24/7 with background dependency auto-installation.
            </p>
          </div>
        </div>

        {/* Token Cost Notice */}
        <div className="mt-4 p-3 rounded-2xl bg-white/[0.03] border border-white/10 flex items-center justify-between text-xs">
          <span className="text-slate-300">
            Deployment Cost: <b className="text-amber-300">1 🪙 Token</b> per bot
          </span>
          <span className="text-slate-400">
            Your Balance:{' '}
            <b className="text-amber-300">{user?.is_admin ? 'Unlimited' : user ? user.tokens : 1}</b>
          </span>
        </div>
      </div>

      {/* Deploy Form */}
      <form onSubmit={handleDeploy} className="liquid-glass rounded-3xl p-6 sm:p-8 border border-white/15 space-y-6">
        {error && (
          <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/30 flex items-start gap-3 text-xs text-red-300">
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-red-400" />
            <div>
              <p className="font-bold">Deployment Error</p>
              <p>{error}</p>
            </div>
          </div>
        )}

        {/* 1. Bot Name & Admin Chat ID */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Bot Name / Title <span className="text-cyan-400">*</span>
            </label>
            <input
              type="text"
              required
              value={botName}
              onChange={(e) => setBotName(e.target.value)}
              placeholder="e.g. My Music Bot"
              className="w-full px-4 py-2.5 rounded-xl text-sm text-white liquid-glass-input placeholder-slate-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Admin Telegram Chat ID <span className="text-cyan-400">*</span>
            </label>
            <input
              type="number"
              required
              value={adminChatId}
              onChange={(e) => setAdminChatId(e.target.value)}
              placeholder="e.g. 5960319648"
              className="w-full px-4 py-2.5 rounded-xl text-sm text-white liquid-glass-input placeholder-slate-500"
            />
          </div>
        </div>

        {/* 2. Bot Token with Live getMe Verification */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-semibold text-slate-300">
              Bot Token <span className="text-slate-400 font-normal">(from @BotFather)</span>
            </label>
            {tokenChecking && (
              <span className="text-[11px] text-cyan-400 flex items-center gap-1 font-mono">
                <Loader2 className="w-3 h-3 animate-spin" /> Verifying token...
              </span>
            )}
          </div>
          <input
            type="text"
            value={botToken}
            onChange={(e) => setBotToken(e.target.value)}
            placeholder="e.g. 8604012968:AAG1tZe1ZbXhgRUyqWqNe03uQbnf-Ug-hS0"
            className="w-full px-4 py-2.5 rounded-xl text-sm text-white liquid-glass-input placeholder-slate-500 font-mono text-xs"
          />

          {/* Token Verified Card with Direct Telegram Link */}
          {tokenInfo && (
            <div className="mt-2.5 p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-between gap-3 animate-fadeIn">
              <div className="flex items-center gap-2.5 min-w-0">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                <div className="min-w-0">
                  <p className="text-xs font-bold text-white truncate">
                    Verified: {tokenInfo.first_name}
                  </p>
                  <p className="text-[11px] text-emerald-300 font-mono">@{tokenInfo.username}</p>
                </div>
              </div>

              <a
                href={`https://t.me/${tokenInfo.username}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/40 text-emerald-300 text-xs font-bold transition-colors flex-shrink-0"
              >
                <span>Open Bot</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          )}
        </div>

        {/* 3. Language Selection */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-2">
            Select Programming Language
          </label>
          <div className="grid grid-cols-2 gap-4">
            <button
              type="button"
              onClick={() => handleLangChange('python')}
              className={`p-4 rounded-2xl border text-left transition-all cursor-pointer ${
                lang === 'python'
                  ? 'bg-gradient-to-tr from-cyan-500/20 to-blue-500/20 border-cyan-400/60 shadow-lg shadow-cyan-500/15'
                  : 'bg-white/[0.02] border-white/10 hover:border-white/20'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-2xl">🐍</span>
                {lang === 'python' && <CheckCircle2 className="w-4 h-4 text-cyan-400" />}
              </div>
              <h3 className="font-extrabold text-sm text-white">Python</h3>
              <p className="text-[11px] text-slate-400 mt-0.5">telebot, aiogram, pyrogram, etc.</p>
            </button>

            <button
              type="button"
              onClick={() => handleLangChange('node')}
              className={`p-4 rounded-2xl border text-left transition-all cursor-pointer ${
                lang === 'node'
                  ? 'bg-gradient-to-tr from-amber-500/20 to-yellow-500/20 border-amber-400/60 shadow-lg shadow-amber-500/15'
                  : 'bg-white/[0.02] border-white/10 hover:border-white/20'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-2xl">🟨</span>
                {lang === 'node' && <CheckCircle2 className="w-4 h-4 text-amber-400" />}
              </div>
              <h3 className="font-extrabold text-sm text-white">Node.js (JavaScript)</h3>
              <p className="text-[11px] text-slate-400 mt-0.5">telegraf, node-telegram-bot-api, etc.</p>
            </button>
          </div>
        </div>

        {/* 4. Upload Mode Tabs */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-semibold text-slate-300">Code Source</label>
            <div className="flex items-center p-1 rounded-xl bg-white/5 border border-white/10 text-xs">
              <button
                type="button"
                onClick={() => setUploadMode('template')}
                className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                  uploadMode === 'template' ? 'bg-cyan-500/30 text-cyan-300' : 'text-slate-400'
                }`}
              >
                Code Editor / Template
              </button>
              <button
                type="button"
                onClick={() => setUploadMode('file')}
                className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                  uploadMode === 'file' ? 'bg-cyan-500/30 text-cyan-300' : 'text-slate-400'
                }`}
              >
                Upload ZIP or File (.py / .js)
              </button>
            </div>
          </div>

          {uploadMode === 'template' ? (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Entry File: <code>{entryFile}</code></span>
                <span className="text-[11px] text-cyan-400">Auto-installs imports on start</span>
              </div>
              <textarea
                rows={10}
                value={codeSnippet}
                onChange={(e) => setCodeSnippet(e.target.value)}
                className="w-full p-4 rounded-2xl font-mono text-xs text-cyan-100 bg-black/40 border border-white/15 focus:border-cyan-400 focus:outline-none"
              />
            </div>
          ) : (
            <div className="p-8 rounded-2xl border-2 border-dashed border-white/20 bg-white/[0.02] text-center hover:border-cyan-400/50 transition-colors">
              <input
                type="file"
                id="bot-file"
                accept={lang === 'python' ? '.zip,.py' : '.zip,.js'}
                onChange={handleFileUpload}
                className="hidden"
              />
              <label htmlFor="bot-file" className="cursor-pointer block">
                <Upload className="w-8 h-8 text-cyan-400 mx-auto mb-2" />
                <p className="text-sm font-bold text-white mb-1">
                  {fileName ? `Selected: ${fileName}` : 'Choose ZIP archive or Code File'}
                </p>
                <p className="text-xs text-slate-400">
                  {lang === 'python' ? 'Upload .zip or .py (requirements.txt auto-installed)' : 'Upload .zip or .js (package.json auto-installed)'}
                </p>
              </label>
            </div>
          )}
        </div>

        {/* Deploy Button */}
        <button
          type="submit"
          disabled={deploying}
          className="w-full py-3.5 rounded-2xl text-sm font-bold text-white liquid-btn-primary flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-cyan-500/25"
        >
          {deploying ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Deploying Bot (Step {deployStep}/3)...</span>
            </>
          ) : (
            <>
              <Bot className="w-4 h-4" />
              <span>🚀 Deploy & Start Bot 24/7</span>
            </>
          )}
        </button>

        {/* Step-by-Step Progress Overlay */}
        {deploying && (
          <div className="p-4 rounded-2xl bg-cyan-950/40 border border-cyan-500/30 space-y-2 text-xs">
            <div className={`flex items-center gap-2 ${deployStep >= 1 ? 'text-cyan-300 font-bold' : 'text-slate-500'}`}>
              <CheckCircle2 className={`w-4 h-4 ${deployStep >= 1 ? 'text-cyan-400' : 'text-slate-600'}`} />
              <span>Step 1/3: Extracting files & verifying Telegram API token...</span>
            </div>
            <div className={`flex items-center gap-2 ${deployStep >= 2 ? 'text-cyan-300 font-bold' : 'text-slate-500'}`}>
              <CheckCircle2 className={`w-4 h-4 ${deployStep >= 2 ? 'text-cyan-400' : 'text-slate-600'}`} />
              <span>Step 2/3: Installing requirements in background environment...</span>
            </div>
            <div className={`flex items-center gap-2 ${deployStep >= 3 ? 'text-emerald-300 font-bold' : 'text-slate-500'}`}>
              <CheckCircle2 className={`w-4 h-4 ${deployStep >= 3 ? 'text-emerald-400' : 'text-slate-600'}`} />
              <span>Step 3/3: Online & Connected 24/7!</span>
            </div>
          </div>
        )}
      </form>
    </div>
  );
};
