/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { User, BotRecord, WebsiteRecord, ViewType } from './types.ts';
import { Navbar } from './components/Navbar.tsx';
import { SidebarDrawer } from './components/SidebarDrawer.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import { DashboardView } from './components/DashboardView.tsx';
import { BotDeployView } from './components/BotDeployView.tsx';
import { WebDeployView } from './components/WebDeployView.tsx';
import { ManageBotsView } from './components/ManageBotsView.tsx';
import { ManageWebsitesView } from './components/ManageWebsitesView.tsx';
import { ClaimCouponView } from './components/ClaimCouponView.tsx';
import { MyAccountView } from './components/MyAccountView.tsx';
import { AdminPanelView } from './components/AdminPanelView.tsx';

const DEFAULT_ADMIN_USER: User = {
  id: 5960319648,
  email: 'sp16373518210@gmail.com',
  chat_id: 5960319648,
  first_name: 'Admin',
  last_name: 'Owner',
  tokens: 999999, // Unlimited tokens for admin
  is_admin: true,
};

export default function App() {
  const [user, setUser] = useState<User | null>(() => {
    try {
      const stored = localStorage.getItem('telehost_user');
      if (stored) return JSON.parse(stored);
    } catch (e) {}
    return DEFAULT_ADMIN_USER; // Default initial user session for instant seamless demo
  });

  const [currentView, setCurrentView] = useState<ViewType>('dashboard');
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);

  const [bots, setBots] = useState<BotRecord[]>([]);
  const [websites, setWebsites] = useState<WebsiteRecord[]>([]);

  // Fetch Bots and Websites
  const refreshData = async () => {
    if (!user) return;
    try {
      const [resBots, resSites] = await Promise.all([
        fetch(`/api/bots?user_id=${user.chat_id}`),
        fetch(`/api/websites?user_id=${user.chat_id}`),
      ]);
      const dataBots = await resBots.json();
      const dataSites = await resSites.json();
      setBots(dataBots.bots || []);
      setWebsites(dataSites.websites || []);
    } catch (e) {
      console.warn('Failed to fetch user data:', e);
    }
  };

  useEffect(() => {
    refreshData();
  }, [user]);

  const handleLoginSuccess = (loggedInUser: User) => {
    setUser(loggedInUser);
    try {
      localStorage.setItem('telehost_user', JSON.stringify(loggedInUser));
    } catch (e) {}
  };

  const handleLogout = () => {
    setUser(null);
    try {
      localStorage.removeItem('telehost_user');
    } catch (e) {}
    setCurrentView('dashboard');
  };

  const handleBotAction = async (botId: number, action: 'start' | 'stop' | 'restart') => {
    try {
      const res = await fetch(`/api/bots/${botId}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      });
      const data = await res.json();
      if (data.bot) {
        setBots((prev) => prev.map((b) => (b.id === botId ? data.bot : b)));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteBot = async (botId: number) => {
    try {
      await fetch(`/api/bots/${botId}`, { method: 'DELETE' });
      setBots((prev) => prev.filter((b) => b.id !== botId));
      if (user && !user.is_admin) {
        setUser({ ...user, tokens: user.tokens + 1 });
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleUpdateBot = async (
    botId: number,
    data: { name?: string; entry?: string; bot_token?: string }
  ) => {
    try {
      const res = await fetch(`/api/bots/${botId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      const resData = await res.json();
      if (resData.bot) {
        setBots((prev) => prev.map((b) => (b.id === botId ? resData.bot : b)));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteWebsite = async (siteId: number) => {
    try {
      await fetch(`/api/websites/${siteId}`, { method: 'DELETE' });
      setWebsites((prev) => prev.filter((s) => s.id !== siteId));
      if (user && !user.is_admin) {
        setUser({ ...user, tokens: user.tokens + 1 });
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleTokenUpdate = (newTokens: number) => {
    if (user) {
      const updated = { ...user, tokens: newTokens };
      setUser(updated);
      try {
        localStorage.setItem('telehost_user', JSON.stringify(updated));
      } catch (e) {}
    }
  };

  return (
    <div className="relative min-h-screen bg-[#070913] text-slate-100 flex flex-col selection:bg-cyan-500/30 selection:text-cyan-200 overflow-x-hidden">
      {/* 3D Liquid Animated Background Orbs */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute -top-32 left-1/4 w-[600px] h-[600px] rounded-full liquid-blob-1 opacity-70"></div>
        <div className="absolute top-1/2 -right-32 w-[500px] h-[500px] rounded-full liquid-blob-2 opacity-60"></div>
        <div className="absolute -bottom-32 left-10 w-[550px] h-[550px] rounded-full liquid-blob-3 opacity-60"></div>
        {/* Subtle grid pattern overlay */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:4rem_4rem]"></div>
      </div>

      {/* Top Navbar with 3-Line Hamburger Menu Button on Right */}
      <Navbar
        user={user}
        currentView={currentView}
        setCurrentView={setCurrentView}
        onOpenDrawer={() => setDrawerOpen(true)}
        onOpenAuth={() => setAuthModalOpen(true)}
      />

      {/* Main Content Viewport */}
      <main className="relative z-10 flex-1 max-w-7xl w-full mx-auto px-4 sm:px-8 py-8">
        {currentView === 'dashboard' && (
          <DashboardView
            user={user}
            bots={bots}
            websites={websites}
            setCurrentView={setCurrentView}
            onBotAction={handleBotAction}
            onOpenAuth={() => setAuthModalOpen(true)}
          />
        )}

        {currentView === 'deploy_bot' && (
          <BotDeployView
            user={user}
            onDeploySuccess={(newBot) => {
              setBots((prev) => [newBot, ...prev]);
              if (user && !user.is_admin) {
                setUser({ ...user, tokens: Math.max(0, user.tokens - 1) });
              }
            }}
            setCurrentView={setCurrentView}
            onOpenAuth={() => setAuthModalOpen(true)}
          />
        )}

        {currentView === 'deploy_web' && (
          <WebDeployView
            user={user}
            onDeploySuccess={(newSite) => {
              setWebsites((prev) => [newSite, ...prev]);
              if (user && !user.is_admin) {
                setUser({ ...user, tokens: Math.max(0, user.tokens - 1) });
              }
            }}
            setCurrentView={setCurrentView}
            onOpenAuth={() => setAuthModalOpen(true)}
          />
        )}

        {currentView === 'manage_bots' && (
          <ManageBotsView
            user={user}
            bots={bots}
            onBotAction={handleBotAction}
            onDeleteBot={handleDeleteBot}
            onUpdateBot={handleUpdateBot}
            setCurrentView={setCurrentView}
          />
        )}

        {currentView === 'manage_web' && (
          <ManageWebsitesView
            user={user}
            websites={websites}
            onDeleteWebsite={handleDeleteWebsite}
            setCurrentView={setCurrentView}
          />
        )}

        {currentView === 'claim_coupon' && (
          <ClaimCouponView
            user={user}
            onTokenUpdate={handleTokenUpdate}
            setCurrentView={setCurrentView}
            onOpenAuth={() => setAuthModalOpen(true)}
          />
        )}

        {currentView === 'account' && (
          <MyAccountView
            user={user}
            onLogout={handleLogout}
            onOpenAuth={() => setAuthModalOpen(true)}
            setCurrentView={setCurrentView}
          />
        )}

        {currentView === 'admin' && <AdminPanelView currentUser={user} />}
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-white/10 py-6 px-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>© 2026 TeleHost 3D. 24/7 Python & Node.js Telegram Bot & Static Web Hosting.</p>
          <div className="flex items-center gap-4 text-slate-400">
            <a href="https://t.me/modapkpro02" target="_blank" rel="noopener noreferrer" className="hover:text-cyan-400">
              Telegram Channel
            </a>
            <a href="/api/download/bot.py" download className="hover:text-cyan-400">
              bot.py Script
            </a>
            <button onClick={() => setCurrentView('claim_coupon')} className="hover:text-amber-400">
              Redeem Code
            </button>
          </div>
        </div>
      </footer>

      {/* Navigation Drawer from Right (3-line hamburger menu) */}
      <SidebarDrawer
        isOpen={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        user={user}
        currentView={currentView}
        setCurrentView={setCurrentView}
        onLogout={handleLogout}
        onOpenAuth={() => setAuthModalOpen(true)}
      />

      {/* Authentication Modal (Login / Sign Up / Forgot Password) */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onSuccess={handleLoginSuccess}
      />
    </div>
  );
}
