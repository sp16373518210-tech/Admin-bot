export interface User {
  id: number;
  email: string;
  chat_id: number;
  first_name: string;
  last_name?: string;
  tokens: number;
  is_admin: boolean;
  banned?: number;
  verified?: number;
  joined_at?: number;
  botsCount?: number;
  webCount?: number;
  bot_info?: {
    id: number;
    first_name: string;
    username: string;
  };
}

export interface BotRecord {
  id: number;
  owner_id: number;
  name: string;
  lang: 'python' | 'node';
  entry: string;
  path: string;
  bot_token?: string;
  bot_username?: string;
  bot_title?: string;
  ready: number;
  desired: number;
  pid: number;
  started_at: number;
  created_at: number;
  code_snippet?: string;
  logs?: string[];
}

export interface WebsiteRecord {
  id: number;
  owner_id: number;
  name: string;
  slug: string;
  path: string;
  entry: string;
  created_at: number;
  files_count?: number;
}

export interface CouponRecord {
  code: string;
  tokens: number;
  max_uses: number;
  used: number;
  created_at: number;
}

export interface AdminStats {
  totalUsers: number;
  verifiedUsers: number;
  totalBots: number;
  runningBots: number;
  totalWebsites: number;
  totalTokens: number;
  activeCoupons: number;
  serverTime: string;
  uptime: number;
}

export type ViewType =
  | 'dashboard'
  | 'deploy_bot'
  | 'deploy_web'
  | 'manage_bots'
  | 'manage_web'
  | 'claim_coupon'
  | 'account'
  | 'admin';
