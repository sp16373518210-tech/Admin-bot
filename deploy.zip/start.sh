#!/bin/sh
set -e

echo "🚀 Starting TeleHost 3D Multi-Service Runtime..."

# Run Telegram Bot in background if BOT_TOKEN is present
if [ -n "$BOT_TOKEN" ] || [ -f ".env" ] || grep -q "BOT_TOKEN" bot.py; then
    echo "🤖 Launching Telegram Bot in background (bot.py)..."
    python3 bot.py &
    BOT_PID=$!
    echo "✅ Telegram Bot running with PID $BOT_PID"
fi

# Run Express Web Server & Hosted Sites in foreground
echo "🌐 Launching Web Dashboard & Hosting API on port ${PORT:-3000}..."
exec npx tsx server.ts
